// C++20 | Premium V2 behavioral regressions. No live game data or process access.
#include "config/settings.hpp"
#include "config/ConfigManager.h"
#include "effects/ThemeManager.h"
#include "effects/RGBManager.h"
#include "effects/AnimationManager.h"
#include "effects/UIEffects.h"
#include "effects/ParticleSystem.h"
#include "esp/EspVisualEffects.h"
#include "imgui.h"
#include "nlohmann/json.hpp"
#include <algorithm>
#include <chrono>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <functional>
#include <iostream>
#include <limits>
#include <set>
#include <stdexcept>
#include <string>
#include <vector>

namespace {
using namespace fe;
using Json=nlohmann::json;
void require(bool condition,const char* text,int line) {
    if(!condition)throw std::runtime_error(std::string("line ")+std::to_string(line)+": "+text);
}
#define REQUIRE(value) require(static_cast<bool>(value),#value,__LINE__)
bool near(float a,float b,float tolerance=.0001f){return std::abs(a-b)<=tolerance;}
bool same_color(const Color& a,const Color& b,float tolerance=.0001f){
    for(std::size_t i=0;i<a.size();++i)if(!near(a[i],b[i],tolerance))return false;
    return true;
}
void valid_color(const Color& c){for(float v:c)REQUIRE(std::isfinite(v)&&v>=0&&v<=1);}
struct Scratch {
    std::filesystem::path path=std::filesystem::temp_directory_path()/("scarlet-premium-tests-"+
        std::to_string(std::chrono::steady_clock::now().time_since_epoch().count()));
    Scratch(){std::filesystem::create_directories(path);}
    ~Scratch(){std::error_code ec;std::filesystem::remove_all(path,ec);}
};
Json read_json(const std::filesystem::path& path){std::ifstream stream(path);return Json::parse(stream);}
void write(const std::filesystem::path& path,const std::string& payload){std::ofstream stream(path);stream<<payload;REQUIRE(static_cast<bool>(stream));}

void premium_json_roundtrip_and_facade(){
    Scratch temporary;Settings source;
    source.automation.enabled=true;
    auto& p=source.premium;
    p.appearance.theme=9;p.appearance.background_opacity=.37f;p.appearance.sidebar_opacity=.61f;
    p.appearance.card_opacity=.43f;p.appearance.header_opacity=.77f;p.appearance.border_opacity=.28f;p.appearance.ui_scale=1.2f;
    p.appearance.primary={.13f,.24f,.35f,.46f};p.appearance.secondary={.63f,.52f,.41f,.8f};
    p.appearance.background={.02f,.03f,.04f,.9f};p.appearance.text={.83f,.84f,.85f,1};
    p.appearance.border={.22f,.33f,.44f,.8f};p.appearance.accent={.61f,.72f,.83f,.94f};
    p.rgb.enabled=true;p.rgb.rainbow=false;p.rgb.sidebar=false;p.rgb.borders=false;p.rgb.logo=false;
    p.rgb.sliders=false;p.rgb.toggles=false;p.rgb.header_line=false;p.rgb.mode=4;p.rgb.speed=.72f;p.rgb.brightness=.63f;
    p.particles.enabled=false;p.particles.connections=false;p.particles.mouse_interaction=false;p.particles.count=89;
    p.particles.speed=.8f;p.particles.size=3.2f;p.particles.opacity=.43f;p.particles.color={.3f,.5f,.7f,.9f};
    p.animation.enabled=false;p.animation.disable_all=true;p.animation.smooth_transitions=false;
    p.animation.style=3;p.animation.duration_ms=360;p.animation.speed=1.5f;
    p.performance.low_performance=true;p.performance.disable_heavy_effects=true;p.performance.statistics=false;
    p.profile.name="Scarlet Test";p.profile.status="Cliente V2";
    p.esp.hat=true;p.esp.hat_rainbow=true;p.esp.hat_filled=true;p.esp.hat_radius=.7f;p.esp.hat_height=.6f;p.esp.hat_thickness=2.5f;
    p.esp.hat_color={.1f,.2f,.3f,.4f};p.esp.hoop=true;p.esp.hoop_rainbow=true;
    p.esp.hoop_radius=.9f;p.esp.hoop_thickness=2.4f;p.esp.hoop_speed=1.8f;p.esp.hoop_height_offset=-.2f;p.esp.hoop_direction=-1;
    p.esp.hoop_color={.4f,.5f,.6f,.7f};p.esp.box_3d=true;p.esp.corner_box=true;p.esp.gradient_box=true;p.esp.outline=true;
    p.esp.rgb_skeleton=true;p.esp.rgb_snaplines=true;p.esp.glow_outline=true;p.esp.distance_gradient=true;
    std::string error;
    REQUIRE(ConfigManager::save(temporary.path/"source.json",source,error));
    const Json saved=read_json(temporary.path/"source.json");
    REQUIRE(saved["format_version"]==1);
    const std::vector<std::string> paths={
        "/appearance/theme","/appearance/background_opacity","/appearance/sidebar_opacity","/appearance/card_opacity",
        "/appearance/header_opacity","/appearance/border_opacity","/appearance/ui_scale",
        "/rgb/enabled","/rgb/rainbow","/rgb/sidebar","/rgb/borders","/rgb/logo","/rgb/sliders","/rgb/toggles","/rgb/header_line","/rgb/mode","/rgb/speed","/rgb/brightness",
        "/particles/enabled","/particles/connections","/particles/mouse_interaction","/particles/count","/particles/speed","/particles/size","/particles/opacity",
        "/animation/enabled","/animation/disable_all","/animation/smooth_transitions","/animation/style","/animation/duration_ms","/animation/speed",
        "/performance/low_performance","/performance/disable_heavy_effects","/performance/statistics","/profile/name","/profile/status",
        "/esp/hat","/esp/hat_rainbow","/esp/hat_filled","/esp/hat_radius","/esp/hat_height","/esp/hat_thickness",
        "/esp/hoop","/esp/hoop_rainbow","/esp/hoop_radius","/esp/hoop_thickness","/esp/hoop_speed","/esp/hoop_height_offset","/esp/hoop_direction",
        "/esp/box_3d","/esp/corner_box","/esp/gradient_box","/esp/outline","/esp/rgb_skeleton","/esp/rgb_snaplines","/esp/glow_outline","/esp/distance_gradient"
    };
    const auto& premium=saved.at("premium");
    for(const auto& path:paths)REQUIRE(premium.contains(Json::json_pointer(path)));
    const std::vector<std::string> color_paths={"/appearance/primary","/appearance/secondary","/appearance/background","/appearance/text","/appearance/border","/appearance/accent","/particles/color","/esp/hat_color","/esp/hoop_color"};
    for(const auto& path:color_paths)for(const char* channel:{"r","g","b","a"})REQUIRE(premium.contains(Json::json_pointer(path+"/"+channel)));
    Settings loaded;REQUIRE(ConfigManager::load(temporary.path/"source.json",loaded,error));
    REQUIRE(!loaded.automation.enabled);REQUIRE(loaded.premium.profile.name==p.profile.name);
    REQUIRE(loaded.premium.esp.hoop_direction==-1);REQUIRE(near(loaded.premium.appearance.background_opacity,.37f));
    REQUIRE(ConfigManager::save(temporary.path/"again.json",loaded,error));
    REQUIRE(read_json(temporary.path/"again.json").at("premium")==premium);
}
void legacy_json_and_atomic_validation(){
    Scratch temporary;std::string error;Settings settings;
    write(temporary.path/"legacy.json",R"({"format_version":1,"visuals":{"players":false},"overlay":{"fps_limit":91}})");
    REQUIRE(ConfigManager::load(temporary.path/"legacy.json",settings,error));
    REQUIRE(!settings.visuals.players);REQUIRE(settings.overlay.fps_limit==91);
    REQUIRE(settings.premium.appearance.theme==0);REQUIRE(settings.premium.particles.count==50);
    REQUIRE(near(settings.premium.appearance.background_opacity,.85f));
    settings.premium.profile.name="Keep me";settings.premium.rgb.speed=.42f;
    std::vector<std::string> bad={
        R"({"format_version":1,"premium":{"rgb":{"mode":"Rainbow"}}})",
        R"({"format_version":1,"premium":{"rgb":{"enabled":1}}})",
        R"({"format_version":1,"premium":{"appearance":{"ui_scale":1e400}}})",
        R"({"format_version":1,"premium":{"rgb":{"mode":1,"mode":2}}})",
        R"({"format_version":1,"premium":{"unknown":true}})",
        R"({"format_version":1,"premium":{"profile":{"name":"bad\nname"}}})",
        std::string("{\"format_version\":1,\"premium\":{\"profile\":{\"name\":\"")+std::string(65,'a')+"\"}}}",
        std::string("{\"format_version\":1,\"premium\":{\"profile\":{\"status\":\"")+std::string(33,'b')+"\"}}}"
    };
    for(const auto& payload:bad){
        write(temporary.path/"invalid.json",payload);
        REQUIRE(!ConfigManager::load(temporary.path/"invalid.json",settings,error));
        REQUIRE(!error.empty());REQUIRE(settings.premium.profile.name=="Keep me");
        REQUIRE(near(settings.premium.rgb.speed,.42f));REQUIRE(settings.overlay.fps_limit==91);
    }
    // A valid multi-byte profile proves limits are not misapplied to UTF-8 byte length.
    Json unicode={{"format_version",1},{"premium",{{"profile",{{"name","Jo\xC3\xA3o Scarlet"},{"status","Cliente"}}}}}};
    write(temporary.path/"unicode.json",unicode.dump());
    REQUIRE(ConfigManager::load(temporary.path/"unicode.json",settings,error));
    REQUIRE(settings.premium.profile.name=="Jo\xC3\xA3o Scarlet");
}
void premium_normalization_bounds(){
    Settings settings;auto& p=settings.premium;
    p.particles.count=100000;p.particles.size=-2;p.particles.opacity=3;
    p.appearance.background_opacity=std::numeric_limits<float>::quiet_NaN();p.appearance.ui_scale=100;
    p.rgb.brightness=std::numeric_limits<float>::infinity();p.rgb.mode=900;p.rgb.speed=-3;
    p.animation.duration_ms=-200;p.animation.speed=99;p.animation.style=-10;
    p.esp.hat_radius=std::numeric_limits<float>::quiet_NaN();p.esp.hoop_direction=0;
    p.profile.name=std::string(200,'x');p.profile.status="";
    normalize_settings(settings);
    REQUIRE(p.particles.count==100);REQUIRE(p.particles.size>0);REQUIRE(p.particles.opacity<=1);
    REQUIRE(near(p.appearance.background_opacity,.85f));REQUIRE(p.appearance.ui_scale<=1.4f);
    REQUIRE(std::isfinite(p.rgb.brightness)&&p.rgb.brightness>=0&&p.rgb.brightness<=1);
    REQUIRE(p.rgb.mode>=0&&p.rgb.mode<=5);REQUIRE(p.rgb.speed>=0);
    REQUIRE(p.animation.duration_ms>=50&&p.animation.duration_ms<=1000);REQUIRE(p.animation.speed<=4);
    REQUIRE(std::isfinite(p.esp.hat_radius)&&p.esp.hat_radius>0);REQUIRE(std::abs(p.esp.hoop_direction)==1);
    REQUIRE(p.profile.name=="Scarlet User");REQUIRE(p.profile.status=="Cliente");
}
void themes_custom_and_time_interpolation(){
    AppearanceSettings appearance;appearance.primary={.21f,.32f,.43f,.8f};appearance.background={.08f,.03f,.11f,.7f};
    std::set<std::string> names;std::vector<Color> primary;
    for(int i=0;i<10;++i){
        const auto palette=ThemeManager::palette_for(i,appearance);
        for(const auto* color:{&palette.primary,&palette.secondary,&palette.background,&palette.text,&palette.border,&palette.accent,&palette.card,&palette.header,&palette.sidebar})valid_color(*color);
        REQUIRE(names.insert(ThemeManager::name(i)).second);primary.push_back(palette.primary);
    }
    REQUIRE(names.size()==10);REQUIRE(!same_color(primary[0],primary[4]));REQUIRE(!same_color(primary[4],primary[5]));
    const auto custom=ThemeManager::palette_for(9,appearance);
    REQUIRE(same_color(custom.primary,appearance.primary));REQUIRE(same_color(custom.background,appearance.background));
    auto transition=[&](int fps){ThemeManager manager;AppearanceSettings a;manager.update(a,0,false);a.theme=7;
        for(int i=0;i<fps;++i)manager.update(a,1.0f/fps,true);
        return manager.palette();};
    const auto slow=transition(30),fast=transition(144);
    REQUIRE(same_color(slow.primary,fast.primary,.00001f));REQUIRE(same_color(slow.background,fast.background,.00001f));
    ThemeManager manager;AppearanceSettings target;manager.update(target,0,false);const auto before=manager.palette().primary;
    target.theme=4;manager.update(target,.001f,true);REQUIRE(!same_color(manager.palette().primary,ThemeManager::palette_for(4,target).primary));
    REQUIRE(std::abs(manager.palette().primary[0]-before[0])<.02f);
    manager.update(target,0,false);REQUIRE(same_color(manager.palette().primary,ThemeManager::palette_for(4,target).primary));
}
void rgb_modes_periodicity_and_disabled_fallback(){
    RGBSettings rgb;const Color base{.9f,.2f,.1f,.7f};
    REQUIRE(same_color(RGBManager::sample(rgb,1,.3f,base),base));
    rgb.enabled=true;rgb.speed=.25f;rgb.brightness=.8f;
    std::vector<Color> modes;
    for(int mode=0;mode<6;++mode){rgb.mode=mode;
        const auto color=RGBManager::sample(rgb,1.7,.19f,base);valid_color(color);REQUIRE(near(color[3],base[3]));modes.push_back(color);
        for(double time:{-100.0,0.0,0.001,1000000.0,std::numeric_limits<double>::infinity(),std::numeric_limits<double>::quiet_NaN()})valid_color(RGBManager::sample(rgb,time,.2f,base));
        const auto a=RGBManager::sample(rgb,1,.2f,base),b=RGBManager::sample(rgb,1.001,.2f,base);
        for(int ch=0;ch<3;++ch)REQUIRE(std::abs(a[ch]-b[ch])<.01f);
    }
    int distinct=0;for(std::size_t i=0;i<modes.size();++i){bool unique=true;for(std::size_t j=0;j<i;++j)if(same_color(modes[i],modes[j],.001f))unique=false;if(unique)++distinct;}
    REQUIRE(distinct>=4);
    rgb.mode=0;REQUIRE(same_color(RGBManager::sample(rgb,1.2,.2f,base),RGBManager::sample(rgb,5.2,.2f,base),.00001f));
    rgb.mode=3;REQUIRE(same_color(RGBManager::sample(rgb,0,.1f,base),RGBManager::sample(rgb,30,.9f,base)));
    rgb.brightness=0;const auto black=RGBManager::sample(rgb,1,0,base);REQUIRE(near(black[0],0)&&near(black[1],0)&&near(black[2],0));
    rgb.enabled=false;REQUIRE(same_color(RGBManager::sample(rgb,100,1,base),base));
}
float open_for(float elapsed,int fps){
    AnimationManager manager;AnimationSettings settings;float time=0;
    while(time<elapsed){const float dt=std::min(1.0f/fps,elapsed-time);manager.update(true,dt,settings);time+=dt;}
    return manager.progress();
}
void menu_animation_duration_reversal_and_frame_rates(){
    REQUIRE(near(open_for(.11f,30),open_for(.11f,60),.00001f));
    REQUIRE(near(open_for(.11f,30),open_for(.11f,144),.00001f));
    REQUIRE(near(open_for(.22f,30),1));REQUIRE(near(open_for(.22f,144),1));
    AnimationManager manager;AnimationSettings settings;manager.update(true,.08f,settings);
    const auto before=manager.progress();manager.update(false,.001f,settings);
    REQUIRE(manager.progress()<before);REQUIRE(before-manager.progress()<.03f);REQUIRE(manager.active());
    manager.update(false,.2f,settings);REQUIRE(near(manager.progress(),0));REQUIRE(!manager.active());
    manager.update(true,.22f,settings);REQUIRE(near(manager.progress(),1));
    manager.update(false,.175f,settings);REQUIRE(manager.active());manager.update(false,.002f,settings);REQUIRE(!manager.active());
    settings.disable_all=true;manager.update(true,0,settings);REQUIRE(near(manager.progress(),1));
    manager.update(false,0,settings);REQUIRE(!manager.active());
    settings.disable_all=false;settings.enabled=false;manager.update(true,0,settings);REQUIRE(near(manager.progress(),1));
}
void widget_microanimation_cache_is_bounded(){
    UIEffects effects;effects.begin_frame(.016f,true);REQUIRE(near(effects.scalar(10,0),0));
    effects.begin_frame(.016f,true);const float first=effects.scalar(10,1);REQUIRE(first>0&&first<1);
    effects.begin_frame(.016f,true);const float next=effects.scalar(10,1);REQUIRE(next>first&&next<1);
    effects.begin_frame(0,true);REQUIRE(near(effects.scalar(10,1),next));
    effects.begin_frame(.016f,false);REQUIRE(near(effects.scalar(10,0),0));
    for(ImGuiID id=100;id<100+static_cast<ImGuiID>(UIEffects::capacity)+64;++id){effects.begin_frame(.016f,true);REQUIRE(std::isfinite(effects.scalar(id,.5f)));}
    REQUIRE(effects.size()<=UIEffects::capacity);
}
void particle_budget_time_and_resize(){
    ParticleSettings settings;settings.count=1000;ParticleSystem particles;
    particles.update(.016f,1000,700,settings,0,{0,0},false,false);REQUIRE(particles.count()==100);
    REQUIRE(particles.update_count()==1);
    for(std::size_t i=0;i<particles.count();++i){const auto p=particles.particles()[i].position;REQUIRE(std::isfinite(p.x)&&p.x>=0&&p.x<1000);REQUIRE(std::isfinite(p.y)&&p.y>=0&&p.y<700);}
    particles.update(.016f,500,350,settings,0,{0,0},false,true);REQUIRE(particles.count()==25);
    for(std::size_t i=0;i<particles.count();++i){const auto p=particles.particles()[i].position;REQUIRE(p.x>=0&&p.x<500&&p.y>=0&&p.y<350);}
    const auto updates=particles.update_count();settings.enabled=false;particles.update(.1f,500,350,settings,0,{0,0},false,false);
    REQUIRE(particles.count()==0);REQUIRE(particles.update_count()==updates);
    settings.enabled=true;particles.update(0,500,350,settings,0,{0,0},false,false);REQUIRE(particles.update_count()==updates);
    auto simulate=[&](int fps){ParticleSystem result;ParticleSettings config;config.count=50;config.mouse_interaction=false;
        result.update(0,1000,700,config,0,{0,0},false,false);for(int i=0;i<fps;++i)result.update(1.0f/fps,1000,700,config,0,{0,0},false,false);return result;};
    const auto slow=simulate(30),fast=simulate(144);
    for(std::size_t i=0;i<slow.count();++i){const auto a=slow.particles()[i].position,b=fast.particles()[i].position;REQUIRE(near(a.x,b.x,.03f)&&near(a.y,b.y,.03f));}
}
struct GuiContext {
    GuiContext(){ImGui::CreateContext();auto& io=ImGui::GetIO();io.IniFilename=nullptr;io.DisplaySize={1920,1080};io.DeltaTime=1.0f/60;io.Fonts->AddFontDefault();unsigned char* pixels{};int w{},h{};io.Fonts->GetTexDataAsRGBA32(&pixels,&w,&h);io.Fonts->SetTexID(static_cast<ImTextureID>(1));}
    ~GuiContext(){ImGui::DestroyContext();}
};
template<class F> auto frame(F&& draw){ImGui::NewFrame();auto value=draw();ImGui::Render();return value;}
void particles_render_alpha_and_bounded_geometry(){
    GuiContext context;ParticleSystem particles;ParticleSettings settings;settings.count=100;settings.opacity=.4f;
    settings.connections=true;RGBSettings rgb;AppearanceSettings appearance;
    particles.update(0,900,600,settings,0,{0,0},false,false);
    const auto vertices=frame([&](){particles.draw(ImGui::GetBackgroundDrawList(),{10,20},rgb,0,appearance,1);return 0;});(void)vertices;
    const auto* data=ImGui::GetDrawData();REQUIRE(data->TotalVtxCount>0&&data->TotalVtxCount<30000);
    for(const auto* list:data->CmdLists){
        for(const auto& vertex:list->VtxBuffer){REQUIRE(std::isfinite(vertex.pos.x)&&std::isfinite(vertex.pos.y));REQUIRE(((vertex.col>>24)&255)<=103);}
        for(const auto& command:list->CmdBuffer)if(command.ElemCount)REQUIRE(command.ClipRect.x>=10&&command.ClipRect.y>=20&&command.ClipRect.z<=910&&command.ClipRect.w<=620);
    }
    settings.opacity=0;particles.update(0,900,600,settings,0,{0,0},false,false);
    frame([&](){particles.draw(ImGui::GetBackgroundDrawList(),{10,20},rgb,0,appearance,1);return 0;});
    REQUIRE(ImGui::GetDrawData()->TotalVtxCount==0);
}
void esp_geometry_follows_observed_anchors(){
    PremiumSettings color_settings;color_settings.rgb.speed=0;
    const Color base{1,.2f,.1f,1};
    const auto static_a=player_effect_color(base,color_settings,0,.3f),static_b=player_effect_color(base,color_settings,25,.3f);
    for(int i=0;i<4;++i)REQUIRE(near(static_a[i],static_b[i]));
    color_settings.rgb.brightness=0;const auto black=player_effect_color(base,color_settings,25);
    REQUIRE(near(black[0],0)&&near(black[1],0)&&near(black[2],0));
    const Vec3 head{2,1.8f,7};const auto cone=make_cone(head,.4f,.3f);REQUIRE(cone);
    REQUIRE(distance(cone->apex,head+Vec3{0,.3f,0})<.00001f);
    for(const auto point:cone->rim){REQUIRE(near(point.y,head.y));REQUIRE(near(distance(point,head),.4f));}
    REQUIRE(!make_cone(head,-1,.3f));REQUIRE(!make_cone({0,std::numeric_limits<float>::quiet_NaN(),0},.4f,.3f));
    const Vec3 waist{2,.9f,7};const auto positive=make_hoop(waist,.6f,.1f,.7,1,1),negative=make_hoop(waist,.6f,.1f,.7,1,-1);
    REQUIRE(positive&&negative);const Vec3 center=waist+Vec3{0,.1f,0};
    for(const auto point:*positive)REQUIRE(near(distance(point,center),.6f));
    REQUIRE(distance((*positive)[0],(*negative)[0])>.1f);
    REQUIRE(near((*positive)[0].z-waist.z,-((*negative)[0].z-waist.z)));
    const Vec3 offset{3,2,1};const auto shifted=make_hoop(waist+offset,.6f,.1f,.7,1,1);REQUIRE(shifted);
    for(std::size_t i=0;i<positive->size();++i)REQUIRE(distance((*shifted)[i],(*positive)[i]+offset)<.00001f);
    REQUIRE(make_hoop(waist,.6f,0,1e308,2,1));
    REQUIRE(!make_hoop(waist,.6f,0,0,1,0));REQUIRE(!make_hoop(waist,.6f,0,std::numeric_limits<double>::infinity(),1,1));
}
GameSnapshot visual_snapshot(){
    GameSnapshot snapshot;snapshot.connected=true;snapshot.local_position=Vec3{0,0,0};snapshot.local_team=1;
    snapshot.camera=make_camera({0,2,-6},{0,1,8},1920.0f/1080);
    Player player;player.id=1;player.position=Vec3{0,0,5};player.team=2;player.available=true;
    snapshot.players.push_back(player);return snapshot;
}
void supply_bounds(Player& player){
    const Vec3 p=*player.position;
    player.bounds=std::array<Vec3,8>{p+Vec3{-.5f,0,-.3f},p+Vec3{.5f,0,-.3f},p+Vec3{.5f,0,.3f},p+Vec3{-.5f,0,.3f},
        p+Vec3{-.5f,1.8f,-.3f},p+Vec3{.5f,1.8f,-.3f},p+Vec3{.5f,1.8f,.3f},p+Vec3{-.5f,1.8f,.3f}};
}
void special_esp_requires_fields_and_respects_filters(){
    GuiContext context;VisualSettings visuals;PremiumSettings premium;
    premium.esp.hat=true;premium.esp.hoop=true;premium.esp.box_3d=true;
    auto snapshot=visual_snapshot();
    auto render=[&](){return frame([&](){return render_special_esp(snapshot,visuals,premium,1920,1080,.7);});};
    auto stats=render();REQUIRE(stats.hats==0&&stats.hoops==0&&stats.boxes3d==0);
    snapshot.players[0].waist=Vec3{0,.9f,5};stats=render();REQUIRE(stats.hats==0&&stats.hoops==1&&stats.boxes3d==0);
    snapshot.players[0].head=Vec3{0,1.8f,5};stats=render();REQUIRE(stats.hats==1&&stats.hoops==1&&stats.boxes3d==0);
    supply_bounds(snapshot.players[0]);stats=render();REQUIRE(stats.hats==1&&stats.hoops==1&&stats.boxes3d==1);
    snapshot.players[0].team=1;stats=render();REQUIRE(stats.hats==0&&stats.hoops==0&&stats.boxes3d==0);
    snapshot.players[0].team=2;snapshot.players[0].available=false;stats=render();REQUIRE(stats.hats==0&&stats.hoops==0);
    snapshot.players[0].available=true;visuals.max_player_distance_m=50;snapshot.local_position=Vec3{0,0,-100};stats=render();REQUIRE(stats.hats==0&&stats.hoops==0);
    snapshot.local_position=Vec3{0,0,0};snapshot.players[0].head=Vec3{0,std::numeric_limits<float>::quiet_NaN(),5};stats=render();REQUIRE(stats.hats==0&&stats.hoops==1);
    snapshot.local_position.reset();stats=render();REQUIRE(stats.hats==0&&stats.hoops==0&&stats.boxes3d==0);
    snapshot.local_position=Vec3{0,0,0};snapshot.connected=false;stats=render();REQUIRE(stats.hats==0&&stats.hoops==0);
}
void special_esp_performance_mode_reduces_draw_budget(){
    GuiContext context;auto snapshot=visual_snapshot();auto& player=snapshot.players[0];
    player.head=Vec3{0,1.8f,5};player.waist=Vec3{0,.9f,5};supply_bounds(player);
    VisualSettings visuals;PremiumSettings premium;premium.esp.hat=true;premium.esp.hoop=true;premium.esp.hat_filled=true;premium.esp.glow_outline=true;
    auto render=[&](){return frame([&](){return render_special_esp(snapshot,visuals,premium,1920,1080,.7);});};
    const auto full=render();const int full_vertices=ImGui::GetDrawData()->TotalVtxCount;
    premium.performance.low_performance=true;const auto light=render();const int light_vertices=ImGui::GetDrawData()->TotalVtxCount;
    REQUIRE(full.hats==1&&full.hoops==1&&light.hats==1&&light.hoops==1);
    REQUIRE(light_vertices>0&&light_vertices<full_vertices);
    for(const auto* list:ImGui::GetDrawData()->CmdLists)for(const auto& vertex:list->VtxBuffer)REQUIRE(std::isfinite(vertex.pos.x)&&std::isfinite(vertex.pos.y));
}
}
int main(){
    const std::vector<std::pair<const char*,std::function<void()>>> tests={
        {"premium_json_roundtrip_and_facade",premium_json_roundtrip_and_facade},
        {"legacy_json_and_atomic_validation",legacy_json_and_atomic_validation},
        {"premium_normalization_bounds",premium_normalization_bounds},
        {"themes_custom_and_time_interpolation",themes_custom_and_time_interpolation},
        {"rgb_modes_periodicity_and_disabled_fallback",rgb_modes_periodicity_and_disabled_fallback},
        {"menu_animation_duration_reversal_and_frame_rates",menu_animation_duration_reversal_and_frame_rates},
        {"widget_microanimation_cache_is_bounded",widget_microanimation_cache_is_bounded},
        {"particle_budget_time_and_resize",particle_budget_time_and_resize},
        {"particles_render_alpha_and_bounded_geometry",particles_render_alpha_and_bounded_geometry},
        {"esp_geometry_follows_observed_anchors",esp_geometry_follows_observed_anchors},
        {"special_esp_requires_fields_and_respects_filters",special_esp_requires_fields_and_respects_filters},
        {"special_esp_performance_mode_reduces_draw_budget",special_esp_performance_mode_reduces_draw_budget}
    };
    int failures=0;for(const auto& [name,test]:tests){try{test();std::cout<<"PASS "<<name<<'\n';}catch(const std::exception& e){++failures;std::cerr<<"FAIL "<<name<<": "<<e.what()<<'\n';}}
    std::cout<<"RESULT "<<tests.size()-static_cast<std::size_t>(failures)<<'/'<<tests.size()<<" premium groups passed\n";
    return failures?1:0;
}
