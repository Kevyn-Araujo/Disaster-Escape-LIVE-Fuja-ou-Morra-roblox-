#include "overlay/window_tracker.hpp"
#include <cwchar>
#include <iostream>
#include <stdexcept>
namespace {void check(bool value,const char* message){if(!value)throw std::runtime_error(message);}}
int main(){
    HWND window{};HINSTANCE instance=GetModuleHandleW(nullptr);const wchar_t* name=L"ScarletTrackingRegression";
    try {
        SetProcessDPIAware();
        wchar_t executable[32768]{};check(GetModuleFileNameW(nullptr,executable,32768)!=0,"executable path");
        const wchar_t* basename=std::wcsrchr(executable,L'\\');basename=basename?basename+1:executable;
        WNDCLASSW wc{};wc.lpfnWndProc=DefWindowProcW;wc.hInstance=instance;wc.lpszClassName=name;
        check(RegisterClassW(&wc)!=0,"register test class");
        window=CreateWindowExW(0,name,L"Scarlet tracking controlled target",WS_OVERLAPPEDWINDOW,90,120,800,600,nullptr,nullptr,instance,nullptr);
        check(window!=nullptr,"create controlled target");ShowWindow(window,SW_SHOW);UpdateWindow(window);
        fe::WindowTracker tracker(basename);auto state=tracker.poll();
        check(state.handle==window&&state.visible,"discover matching executable window");
        RECT client{};POINT origin{};GetClientRect(window,&client);ClientToScreen(window,&origin);
        check(state.client.left==origin.x&&state.client.top==origin.y,"client screen origin");
        check(state.client.right-state.client.left==client.right,"client width");
        check(state.client.bottom-state.client.top==client.bottom,"client height");
        MoveWindow(window,210,170,1000,700,TRUE);state=tracker.poll();
        GetClientRect(window,&client);ClientToScreen(window,&origin);
        check(state.client.left==origin.x&&state.client.right-state.client.left==client.right,"follow move and resize");
        ShowWindow(window,SW_MINIMIZE);state=tracker.poll();check(state.minimized&&!state.visible,"hide on minimize");
        ShowWindow(window,SW_RESTORE);state=tracker.poll();check(!state.minimized&&state.visible,"restore target");
        ShowWindow(window,SW_HIDE);check(!tracker.poll().visible,"hide invisible target");
        ShowWindow(window,SW_SHOW);DestroyWindow(window);window=nullptr;
        check(!tracker.poll().handle,"invalidate destroyed HWND");UnregisterClassW(name,instance);
        std::cout<<"PASS Windows tracking: executable, client origin, move/resize, minimize, restore, hide, destroy\n";return 0;
    }catch(const std::exception& error){if(window)DestroyWindow(window);UnregisterClassW(name,instance);std::cerr<<error.what()<<'\n';return 1;}
}
