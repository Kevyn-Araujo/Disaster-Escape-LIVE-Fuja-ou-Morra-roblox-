# Arquitetura Scarlet

## Fluxo e separação

`IGameDataProvider → GameSnapshot → PlayerESP / ChestESP / AutoChestMachine → IControlSink`.

A janela e o renderizador não adquirem telemetria por conta própria. `WindowTracker` descobre a janela alvo por nome de executável e calcula a área cliente com GetClientRect + ClientToScreen. Isso mantém o posicionamento do overlay separado da fonte de entidades.

- `src/core`: coordenadas em metros, câmera, matriz row-major e WorldToScreen.
- `src/data`: contratos, `UnavailableGameDataProvider` e mock reproduzível.
- `src/esp`: filtros, `PlayerESP` e `ChestESP`.
- `src/navigation`: A* planar XZ, células bloqueadas e validação de segmentos.
- `src/automation`: sete estados, progresso, limites, retry, confirmação e emergência.
- `src/overlay`: Win32, rastreador, DirectX11, DWM, atalhos e bandeja.
- `src/ui`: layout Scarlet e controles customizados ImGui/ImDrawList.
- `src/config`: JSON, validação e substituição transacional.
- `src/utils`: logs limitados e sincronizados.
- `tools/menu_preview.cpp`: rasterizador CPU para os draw lists reais do menu.
- `tests`: núcleo, controles ImGui e rastreador Windows.

## Modo padrão e demo

O modo padrão instancia `UnavailableGameDataProvider`. Seus snapshots estão desconectados, sem posição local, câmera válida, jogadores ou baús. Nenhum comando de movimento/interação é aceito. O overlay pode ser posicionado sem uma origem de dados reais; essas são capacidades independentes.

Somente o argumento explícito `--demo` instancia `MockGameDataProvider`. O banner identifica os dados simulados. Um futuro provider e sink autorizados podem ser passados a `Dx11Overlay::run` sem reescrever a UI, os filtros ou a navegação.

O mock sincroniza snapshots com shared_mutex. Aquisição, atualização de automação e desenho atualmente ocorrem em sequência no mesmo thread. Cada consumidor recebe uma cópia coerente; não mantém referências a vetores mutáveis de outra thread.

## Contrato espacial

Posições em metros; Y vertical; navegação no plano XZ. Matriz row-major de 16 elementos: `clip = M × vetor_coluna`. Clipping DirectX: -w≤x,y≤w e 0≤z≤w. A câmera deve estar válida e não degenerada.

Nome, vida, máximo de vida, escudo, máximo de escudo, equipe, visibilidade, cabeça e ossos só são desenhados se fornecidos e válidos. Não há aproximação de cabeça/esqueleto quando o provider não a fornece. Team Check só compara equipes conhecidas.

## Estados de baús

Unknown, Closed, Open, Destroyed e Unavailable são explícitos. O filtro exige Closed + disponível + posição finita + posição local válida + distância inclusiva dentro de 50–1.000m. A lista é recalculada a cada snapshot consumido. Posições potenciais de spawn não contam como baús observados.

## Automação

IDLE → SEARCHING → SELECTING_CHEST → NAVIGATING → INTERACTING → VERIFYING. RECOVERING trata falhas.

A seleção compara o comprimento das rotas calculadas entre candidatos dentro do alcance direto; desempate por ID. A* impede corte de cantos e todos os segmentos são verificados. A malha é explícita; o overlay não deduz obstáculos de pixels. O mock publica a abertura após 0,45s; aceitar o pedido não significa sucesso.

Auto Retry=false esgota cada alvo após a primeira falha. Ativado, usa max_retries e cooldown. Stuck Recovery=false transforma a falta de progresso em parada de emergência travada; ativado, tenta replanejar/selecionar novamente. AFK=false para após uma abertura confirmada. Parada e coleta única exigem observar desligamento e nova habilitação para rearmar.

Dados repetidos suspendem controles. Desconexão ou alvo inválido interrompem o fluxo. A navegação é planar, limitada a 1.048.576 células por planejamento; não modela rampas, salto, portas ou andares. O mock aceita passos de até0,25s; a aplicação limita o passo de frame a0,1s.

## Janela e entrada

Overlay live V2: WS_POPUP, WS_EX_NOREDIRECTIONBITMAP e DirectComposition. A swapchain BGRA usa DXGI_ALPHA_MODE_PREMULTIPLIED com clear transparente; o alpha dos backgrounds é separado do texto. Menu fechado adiciona WS_EX_TRANSPARENT, WS_EX_NOACTIVATE e layered alpha255 para liberar o mouse. O modo interativo remove essas flags; a animação de saída pode continuar sem capturar entrada.

O alvo é ocultado do overlay quando minimizado, invisível, destruído ou fora de primeiro plano. Geometria e recursos DX11 acompanham o tamanho físico da área cliente com DPI por monitor. A detecção de alvos ausentes é limitada a uma tentativa por segundo. Atalhos são registrados globalmente; falhas não são repetidas a cada frame. A bandeja oferece saída e recuperação.

Recursos são liberados na ordem ImGui → D3D → janela/atalhos/bandeja. Falhas de criação, resize e Present são registradas e encerram a aplicação com código de erro.

## Módulos visuais V2

ThemeManager, RGBManager, ParticleSystem, AnimationManager e UIEffects ficam em src/effects; EspVisualEffects em src/esp; ConfigManager é uma fachada do serializador existente, sem sistema JSON duplicado. PremiumSettings pertence à configuração original.

ThemeManager interpola paletas. RGBManager converte HSV e implementa seis modos. ParticleSystem usa array fixo100 e até seis vizinhos por partícula, no máximo600 verificações. UIEffects usa cache fixo1024. Animações são baseadas em DeltaTime; fontes só são carregadas na inicialização.

Player::waist e Player::bounds são opcionais e explícitos. Só os corpos definidos no mock recebem esses campos. Anéis/cones usam32 segmentos pré-calculados, reduzidos a16 no modo leve; dados ausentes são omitidos. Nenhuma fonte de Fortnite foi adicionada.
