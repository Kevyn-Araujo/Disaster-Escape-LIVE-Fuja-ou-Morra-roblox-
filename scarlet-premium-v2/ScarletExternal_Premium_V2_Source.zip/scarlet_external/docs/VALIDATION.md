> Relatório histórico da versão anterior. A atualização Premium V2 está em [V2_VALIDATION.md](V2_VALIDATION.md).

# Relatório de validação — Scarlet External

## Evidências executadas

| Verificação | Resultado |
|---|---|
| C++20 nativo, GCC14.2, núcleo e ImGui | Build passou |
| Núcleo: filtros, distâncias, câmera, A*, máquina, configuração JSON | **19/19 grupos passaram** |
| Cenário baseline, 2.000 passos de0,05s | **3 aberturas confirmadas, zero avisos e erros** |
| Controles Scarlet via eventos de mouse ImGui | Passaram: switches, sidebar, recusa de automação sem provider, AFK, hotkey, slider, Save/Load JSON e menu fechado |
| CTest portátil | **3/3 suites passaram** |
| ASan/UBSan e detecção de vazamentos | Suites passaram sem diagnóstico; controles Save/Load JSON também reexecutados com sanitizadores |
| Build/link Windows x64: ScarletExternal.exe | Passou; PE32+ GUI x86-64 |
| Build/link Windows x64: testes, preview e headless | Passou |
| Rastreamento Win32 em runtime | Teste controlado incluído e compilado; **não executado em Windows** |
| DirectX11/DWM, mouse, hotkeys, minimize, resize e foco no Windows | Implementados e compilados; **não executados em Windows** |
| Overlay sobre Fortnite real | **Não executado neste ambiente Linux** |
| ESP/coleta com dados reais de Fortnite | **Sem provider real: não disponíveis nesta entrega** |

Não há Windows ou Wine instalado no ambiente de execução utilizado. A compilação cruzada não demonstra compatibilidade de execução com uma instalação específica de Fortnite. Os passos de validação Windows abaixo permanecem necessários.

## Inspeção visual

As imagens em `docs/preview/` foram geradas pelos draw lists do **mesmo código Dear ImGui da aplicação**, usando o rasterizador CPU `ScarletPreview`. A inspeção verificou logo vermelho, fundo escuro, proporções sidebar/topo/cards/rail, marcador ativo, controles arredondados e sliders com bolinha branca. Não é uma captura de uma partida nem um segundo menu implementado em HTML.

A referência não forneceu fonte original ou arquivo vetorial do logo. Fontes substitutas de licença aberta foram incluídas. A aparência segue a referência, mas não foi medida como reprodução pixel a pixel.

## Cobertura do núcleo

- Provider indisponível publica zero entidades e recusa comandos.
- Auto Retry altera o limite por alvo; Stuck Recovery desligado trava a máquina ao detectar falta de progresso.
- Closed exige confirmação, disponibilidade e posição válida; Unknown/Open/Destroyed/Unavailable são excluídos.
- Distâncias em metros, bordas inclusivas, clamp50–1.000m e desempate estável.
- Dados opcionais de jogadores e equipes desconhecidas não são inventados.
- WorldToScreen rejeita câmera/matriz/coordenadas inválidas e objetos fora do volume DirectX.
- A* valida obstáculos, limites e cantos; a seleção considera rotas acessíveis.
- AFK, coleta única, emergência, rearme, desconexão, dados repetidos e alvo invalidado.
- Aceitação de interação não conta como abertura; somente confirmação Open.
- JSON: roundtrip, duplicatas, chaves desconhecidas, tipos incorretos, versão, rejeição atômica e carga desativada.

Logs em `docs/test-results/` preservam a saída dos testes efetivamente executados.

## Ferramentas

GCC14.2.0, CMake4.4.4, Ninja1.13.2. Windows: LLVM-MinGW20240619 / Clang18.1.8, alvo x86_64-w64-windows-gnu, link estático do runtime C++. A inspeção de imports encontrou somente bibliotecas de sistema Windows/UCRT/DirectX; não há DLL C++ do toolchain a distribuir. Essas ferramentas não integram os pacotes.

## Reproduzir

```sh
cmake --preset portable
cmake --build --preset portable --parallel
ctest --preset portable
cmake --preset sanitizers
cmake --build --preset sanitizers --parallel
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 UBSAN_OPTIONS=halt_on_error=1 ctest --preset sanitizers
```

Compilação cruzada executada com os binários LLVM-MinGW no PATH:

```sh
cmake -S . -B build/windows-cross -G Ninja \
  -DCMAKE_TOOLCHAIN_FILE=cmake/mingw-toolchain.cmake \
  -DCMAKE_BUILD_TYPE=Release -DFE_BUILD_OVERLAY=ON \
  -DCMAKE_EXE_LINKER_FLAGS=-static
cmake --build build/windows-cross --parallel
```

## Verificação pendente no Windows

1. Compile com o preset VS2022 e rode `ctest --preset vs2022-release`.
2. Confirme que `ScarletWindowTests` encontra a janela controlada, acompanha client rect/movimento/resize e reconhece minimizar/restaurar/ocultar/destruir.
3. Rode `ScarletExternal.exe --demo`; verifique fontes, abas, sliders, JSON, F6/F8 e três aberturas simuladas.
4. Rode o modo padrão com Fortnite em janela/borderless; pressione INSERT, mova/redimensione a janela, minimize e restaure, feche o menu e confira mouse/teclado no jogo.
5. Confirme **No data source**, zero entidades reais e recusa de Auto Chest sem uma integração autorizada.
6. Consulte `%LOCALAPPDATA%\ScarletExternal\scarlet.log` em caso de falha de identificação, backend ou hotkey.
