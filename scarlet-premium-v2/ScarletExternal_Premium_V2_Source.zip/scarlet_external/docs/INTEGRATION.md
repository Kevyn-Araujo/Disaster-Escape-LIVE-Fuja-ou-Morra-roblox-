# Integração e disponibilidade real

## O que a detecção de janela fornece

WindowTracker usa EnumWindows, GetWindowThreadProcessId, PROCESS_QUERY_LIMITED_INFORMATION e QueryFullProcessImageNameW. Compara o nome do executável a `FortniteClient-Win64-Shipping.exe`. Não lê memória de entidades. Sem permissão para consultar o nome, a janela não é identificada; não há contorno de proteção. ClientToScreen/GetClientRect fornecem a geometria para posicionar a janela de overlay.

Isso não fornece posições, vida, visibilidade, malha ou estado de baús. Nenhum desses dados é deduzido da existência da janela.

## Provider real não incluído

Esta entrega não inclui nem valida uma API autorizada que exponha o estado espacial de uma partida real de Fortnite. Não afirma uma auditoria atual de todos os SDKs/APIs da Epic. APIs de conta, catálogo ou estatísticas não bastam para o contrato de entidades ao vivo. Um replay autorizado também não deve ser apresentado como telemetria ao vivo.

Para integrar uma origem, implemente IGameDataProvider e forneça snapshots coerentes:

1. Conexão, sequência/tempo de atualização e posição local válida em metros.
2. IDs estáveis e posições observadas dos jogadores e baús realmente existentes.
3. Estado explícito de cada baú. Sem confirmação, use Unknown.
4. Câmera e matriz conforme a convenção do núcleo.
5. Campos opcionais somente quando fornecidos; não invente visibilidade ou vida.
6. Malha de navegação que represente o ambiente onde haverá movimento.

Implemente IControlSink para um canal de controle autorizado. move_towards/interact precisam reportar aceitação real, e stop deve liberar controles. A confirmação Open precisa vir de um novo snapshot. Passe ambos a Dx11Overlay::run em lugar de UnavailableGameDataProvider.

## Evidências distintas

- Testes do mock demonstram lógica sobre a simulação.
- Prévia CPU demonstra desenho e interação do menu ImGui.
- Compilação Windows demonstra consistência do código e link para esse alvo.
- Execução Windows é necessária para verificar DWM, foco, atalhos, resize e renderização DX11.
- Uma integração com Fortnite ainda exige validar a origem e os comandos naquele ambiente.

Os três primeiros foram executados nesta entrega; execução Windows/Fortnite não foi realizada neste ambiente Linux. O teste Windows de rastreamento foi compilado e está incluído para execução local. Consulte VALIDATION.md.

Tela cheia exclusiva não é atendida. O overlay foi projetado para janela e janela sem bordas; nomes de executáveis diferentes exigem adaptar a configuração do WindowTracker no código. Não há injeção, drivers, offsets, evasão ou desativação de proteções.
