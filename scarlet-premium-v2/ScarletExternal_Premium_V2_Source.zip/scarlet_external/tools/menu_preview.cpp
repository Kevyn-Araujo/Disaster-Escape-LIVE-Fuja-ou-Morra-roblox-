// Actual ImGui draw data rendered on the CPU; this does not emulate DirectX or a Fortnite connection.
#include "ui/menu.hpp"
#include "config/settings.hpp"
#include "data/unavailable_game_data_provider.hpp"
#include "data/mock_game_data_provider.hpp"
#include "esp/esp_renderer.hpp"
#include "automation/auto_chest.hpp"
#include "utils/logger.hpp"
#include "imgui.h"
#include <algorithm>
#include <cmath>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <vector>
#include <chrono>
namespace {
void require(bool condition,const char* message){if(!condition)throw std::runtime_error(message);}
struct Renderer {
    int width{1247},height{860},tw{},th{};unsigned char* tex{};
    std::vector<unsigned char> pixels=std::vector<unsigned char>(static_cast<std::size_t>(width)*height*3,20);
    void rasterize(ImDrawData* data){
        for(const auto* list:data->CmdLists)for(const auto& command:list->CmdBuffer){
            if(command.UserCallback)continue;
            const int left=std::max(0,static_cast<int>(std::floor(command.ClipRect.x)));
            const int top=std::max(0,static_cast<int>(std::floor(command.ClipRect.y)));
            const int right=std::min(width,static_cast<int>(std::ceil(command.ClipRect.z)));
            const int bottom=std::min(height,static_cast<int>(std::ceil(command.ClipRect.w)));
            for(unsigned int i=0;i+2<command.ElemCount;i+=3){
                const auto& a=list->VtxBuffer[list->IdxBuffer[command.IdxOffset+i]+command.VtxOffset];
                const auto& b=list->VtxBuffer[list->IdxBuffer[command.IdxOffset+i+1]+command.VtxOffset];
                const auto& c=list->VtxBuffer[list->IdxBuffer[command.IdxOffset+i+2]+command.VtxOffset];
                const float denominator=(b.pos.y-c.pos.y)*(a.pos.x-c.pos.x)+(c.pos.x-b.pos.x)*(a.pos.y-c.pos.y);
                if(std::abs(denominator)<1e-8f)continue;
                const int x0=std::max(left,static_cast<int>(std::floor(std::min({a.pos.x,b.pos.x,c.pos.x}))));
                const int x1=std::min(right,static_cast<int>(std::ceil(std::max({a.pos.x,b.pos.x,c.pos.x}))));
                const int y0=std::max(top,static_cast<int>(std::floor(std::min({a.pos.y,b.pos.y,c.pos.y}))));
                const int y1=std::min(bottom,static_cast<int>(std::ceil(std::max({a.pos.y,b.pos.y,c.pos.y}))));
                for(int y=y0;y<y1;++y)for(int x=x0;x<x1;++x){
                    const float px=x+.5f,py=y+.5f;
                    const float u=((b.pos.y-c.pos.y)*(px-c.pos.x)+(c.pos.x-b.pos.x)*(py-c.pos.y))/denominator;
                    const float v=((c.pos.y-a.pos.y)*(px-c.pos.x)+(a.pos.x-c.pos.x)*(py-c.pos.y))/denominator;
                    const float w=1-u-v;if(u<0||v<0||w<0)continue;
                    const float tu=u*a.uv.x+v*b.uv.x+w*c.uv.x,tv=u*a.uv.y+v*b.uv.y+w*c.uv.y;
                    const int tx=std::clamp(static_cast<int>(tu*tw),0,tw-1),ty=std::clamp(static_cast<int>(tv*th),0,th-1);
                    const auto ti=(static_cast<std::size_t>(ty)*tw+tx)*4;
                    auto channel=[&](int shift){return u*((a.col>>shift)&255)+v*((b.col>>shift)&255)+w*((c.col>>shift)&255);};
                    const float alpha=channel(24)/255.0f*tex[ti+3]/255.0f;
                    const auto target=(static_cast<std::size_t>(y)*width+x)*3;
                    for(int ch=0;ch<3;++ch){const float color=channel(ch*8)*tex[ti+ch]/255.0f;
                        pixels[target+ch]=static_cast<unsigned char>(std::clamp(color*alpha+pixels[target+ch]*(1-alpha),0.0f,255.0f));}
                }
            }
        }
    }
    void write(const std::filesystem::path& path){std::ofstream out(path,std::ios::binary);out<<"P6\n"<<width<<' '<<height<<"\n255\n";out.write(reinterpret_cast<const char*>(pixels.data()),static_cast<std::streamsize>(pixels.size()));require(static_cast<bool>(out),"write preview");}
};
}
int main(int argc,char** argv){
    try{
        const bool test=argc>1&&std::string(argv[1])=="--test";
        const bool esp=argc>1&&std::string(argv[1])=="--esp";
        const std::filesystem::path assets=esp?(argc>3?argv[3]:"assets"):(argc>2?argv[2]:"assets");
        ImGui::CreateContext();auto& io=ImGui::GetIO();io.IniFilename=nullptr;io.DisplaySize={1247,860};io.DeltaTime=1.0f/60;
        require(fe::load_scarlet_fonts(assets),"bundled fonts load");fe::apply_scarlet_style();
        Renderer renderer;io.Fonts->GetTexDataAsRGBA32(&renderer.tex,&renderer.tw,&renderer.th);io.Fonts->SetTexID(static_cast<ImTextureID>(1));
        fe::Settings settings;if(test)settings.premium.animation.disable_all=true;fe::UnavailableGameDataProvider provider;fe::Logger logger;fe::AutoChestMachine machine(logger);
        fe::MenuState menu;menu.visible=!esp;fe::RuntimeStatus runtime;
        fe::MockGameDataProvider mock;auto esp_data=mock.snapshot();
        if(esp){
            auto& e=settings.premium.esp;e.hat=true;e.hat_filled=true;e.hoop=true;e.hoop_rainbow=true;e.box_3d=true;e.outline=true;
            const auto found=std::find_if(esp_data.players.begin(),esp_data.players.end(),[](const fe::Player& p){return p.position&&p.head;});
            require(found!=esp_data.players.end(),"explicit mock body available");
            esp_data.camera=fe::make_camera(*found->position+fe::Vec3{0,1.1f,-4},*found->position+fe::Vec3{0,1,0},1247.0f/860);
        }else if(!test){
            if(argc>3)menu.page=std::clamp(std::stoi(argv[3]),0,3);
            if(argc>4)settings.premium.appearance.theme=std::clamp(std::stoi(argv[4]),0,9);
            if(argc>5)menu.settings_section=std::clamp(std::stoi(argv[5]),0,5);
            if(argc>6)settings.premium.rgb.enabled=std::string(argv[6])=="rgb";
        }
        const auto config_path=std::filesystem::temp_directory_path()/("scarlet-ui-"+std::to_string(std::chrono::steady_clock::now().time_since_epoch().count())+".json");
        auto frame=[&](){ImGui::NewFrame();if(esp)fe::draw_scene(esp_data,settings.visuals,{},1247,860,true,&settings.premium,ImGui::GetTime());fe::draw_menu(menu,settings,provider,machine,logger,config_path,runtime);ImGui::Render();};
        auto click=[&](float x,float y){io.AddMousePosEvent(x,y);frame();io.AddMouseButtonEvent(0,true);frame();io.AddMouseButtonEvent(0,false);frame();};
        frame();frame();
        if(test){
            require(settings.visuals.boxes,"initial box state");click(608,210);require(!settings.visuals.boxes,"custom player switch changes model");
            click(110,250);require(menu.page==1,"sidebar chest navigation");
            click(110,400);require(menu.page==2,"sidebar auto navigation");
            click(608,175);require(!settings.automation.enabled,"no provider cannot activate auto chest");
            click(608,210);require(!settings.automation.afk_mode,"AFK switch changes model");
            click(110,580);require(menu.page==3,"sidebar settings navigation");
            click(585,183);require(settings.overlay.menu_key==0x24,"menu hotkey selector changes model");
            const int old=settings.overlay.fps_limit;click(530,263);require(settings.overlay.fps_limit!=old,"red slider changes FPS setting");
            const int saved_fps=settings.overlay.fps_limit;click(370,374);require(std::filesystem::exists(config_path),"save button writes JSON");
            settings.overlay.fps_limit=30;click(550,374);require(settings.overlay.fps_limit==saved_fps,"load button restores JSON");
            require(!settings.automation.enabled,"load leaves automation off");std::filesystem::remove(config_path);
            menu.visible=false;frame();require(ImGui::GetDrawData()->TotalVtxCount==0,"closed menu renders no UI");
            menu.visible=true;menu.page=3;menu.settings_section=0;frame();
            click(955,179);require(settings.premium.appearance.theme==1,"theme selection changes model");
            require(std::filesystem::exists(config_path),"theme autosave writes JSON");
            click(405,198);require(settings.premium.appearance.background_opacity<.8f,"opacity slider changes model");
            click(1160,390);require(menu.settings_section==1,"RGB settings navigation");
            click(610,175);require(settings.premium.rgb.enabled,"RGB switch is connected");
            click(1160,440);require(menu.settings_section==2,"particle settings navigation");
            click(610,175);require(!settings.premium.particles.enabled,"particle switch is connected");
            click(110,180);click(1160,380);require(menu.visual_section==1,"special ESP navigation");
            click(610,175);require(settings.premium.esp.hat,"hat switch is connected");
            click(1000,175);require(settings.premium.esp.hoop,"hoop switch is connected");
            click(1160,428);click(610,175);require(settings.premium.esp.box_3d,"3D box switch is connected");
            settings.premium.animation.disable_all=false;for(int i=0;i<40;++i)frame();
            menu.visible=false;frame();require(ImGui::GetDrawData()->TotalVtxCount>0,"closing transition remains visible");
            for(int i=0;i<40;++i)frame();require(!fe::menu_rendering(menu),"close transition completes");
            const auto updates=menu.particles.update_count();for(int i=0;i<10;++i)frame();
            require(menu.particles.update_count()==updates,"fully closed UI does not update particles");
            require(ImGui::GetDrawData()->TotalVtxCount==0,"fully closed UI draws nothing");
            std::filesystem::remove(config_path);
            std::cout<<"PASS V2 controls: theme autosave, alpha, RGB, particles, hat, hoop, bounds, closing fade, hidden updates\n";
            std::cout<<"PASS Scarlet controls: fonts, switch, sidebar, provider availability, AFK, hotkey, slider, JSON save/load, hidden menu\n";
        }else{
            for(int i=0;i<40;++i)frame();
            renderer.rasterize(ImGui::GetDrawData());renderer.write(esp?(argc>2?argv[2]:"esp-preview.ppm"):(argc>1?argv[1]:"scarlet-preview.ppm"));
            std::cout<<"Rendered actual ImGui menu: "<<ImGui::GetDrawData()->TotalVtxCount<<" vertices\n";
        }
        ImGui::DestroyContext();return 0;
    }catch(const std::exception& error){if(ImGui::GetCurrentContext())ImGui::DestroyContext();std::cerr<<error.what()<<'\n';return 1;}
}
