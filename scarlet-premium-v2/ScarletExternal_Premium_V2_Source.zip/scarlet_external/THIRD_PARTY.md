# Dependências e proveniência

- **Dear ImGui v1.91.9b**, commit f5befd2d29e66809cd1110a152e375a7f1981f06. https://github.com/ocornut/imgui . Licença MIT preservada em vendor/imgui/LICENSE.txt.
- **nlohmann/json v3.11.3**: https://github.com/nlohmann/json/tree/v3.11.3 . Header oficial e MIT em vendor/nlohmann/.
- **Kaushan Script Regular**, de google/fonts/ofl/kaushanscript: https://github.com/google/fonts/tree/main/ofl/kaushanscript . OFL preservada em assets/fonts/KaushanScript-OFL.txt. Usada como aproximação do lettering Scarlet da referência, não como arquivo original do logo.
- **Barlow SemiBold**, de google/fonts/ofl/barlow: https://github.com/google/fonts/tree/main/ofl/barlow . OFL preservada em assets/fonts/Barlow-OFL.txt.
- Ícones geométricos e controles Scarlet desenhados pelo código deste projeto, sem copiar arquivos gráficos da referência.
- Win32, DWM e DirectX11 são bibliotecas do Windows SDK. Toolchain de verificação cruzada: LLVM-MinGW20240619/Clang18.1.8, não incluído no pacote fonte.

As fontes estão vendorizadas: o build não depende de downloads. Os hashes dos arquivos de fonte e headers de terceiros estão em docs/dependency-hashes.txt.
