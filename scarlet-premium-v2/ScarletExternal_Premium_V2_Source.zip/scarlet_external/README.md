# Scarlet External — Premium UI V2

Aplicativo Windows x64 em C++20, Dear ImGui, DirectX 11 e Win32. Interface customizada a partir da referência visual fornecida: vermelho **#FF3528**, logo Scarlet em fonte manuscrita, sidebar, breadcrumb, duas colunas de cards, rail de ícones, switches e sliders próprios.

**A detecção da janela do Fortnite fornece posição e tamanho, não telemetria. Esta entrega não inclui uma fonte autorizada de posições/estados reais de Fortnite.** O modo padrão publica zero entidades. A automação não é habilitada sem dados válidos. O modo `--demo` é separado, explicitamente identificado como simulação.

![Interface real ImGui, renderizada em software para inspeção](docs/preview/v2/classic.png)

## Novidades V2 e acesso aos controles

A atualização foi feita diretamente no projeto existente. Chest ESP e Auto Chest mantêm suas lógicas.

- **Settings → Appearance**: dez temas, prévias, cores Custom, opacidade de fundo/sidebar/cards/header/bordas, UI Scale e nome/status do perfil local. A escolha de tema é salva automaticamente; use General → Save Config para persistir as outras personalizações.
- **Settings → RGB Effects**: Rainbow, Breathing, Color Wave, Static Color, Gradient e Pulse; velocidade/brilho e seleção dos elementos afetados. Desligar RGB restaura o tema.
- **Settings → Particles**: até100 partículas (padrão50), cor, tamanho, velocidade, opacidade, conexões e reação ao mouse. Christmas usa neve; Sakura, pétalas; Easter, tons pastel; Halloween, pequenos losangos.
- **Settings → Animations**: Fade/Scale/Slide/Ease Out e combinação Premium. Padrão220ms, fechamento inverso mais curto, microanimações e opção Disable Animations.
- **Settings → Performance**: Performance Mode, Disable Heavy Effects e estatísticas do UI. Modo leve limita a25 partículas e reduz a geometria ESP; fill/glow e conexões são suprimidos.
- **Settings → General** preserva atalhos, FPS, JSON, diagnóstico do overlay e logs.
- **Player ESP → Hat / Hoop**: chapéu cônico e bambolê animado com controles individuais. **Extra ESP**: boxes3D/cantos/gradiente, outline/glow, cores por distância, RGB de skeleton/snaplines.
- **Player ESP → Visual Test** salva a configuração atual e abre uma janela de teste independente com dados mock explícitos. Não se conecta à partida.

Os seletores de seção ficam na coluna estreita à direita. O perfil continua no canto inferior esquerdo. O rótulo Cliente é um texto local configurável, não uma verificação de conta/licença.

### Preview independente de ESP

```powershell
.\ScarletExternal.exe --esp-preview
```

Ou execute `Testar-ESP.bat` do pacote Windows. A instância de teste usa **TAB** para menu, **ESC** para parada e **F4** para iniciar/parar. São atalhos locais e não disputam INSERT/F6/F8 com o overlay principal. A câmera aproxima um jogador real do cenário mock, com cabeça, cintura e bounds fornecidos explicitamente por esse provider.

Sem cabeça, não há chapéu; sem cintura, não há bambolê; sem bounds, não há box3D. Esses dados nunca são inferidos de uma posição genérica no modo padrão.

### Alpha e composição

O modo live usa DirectComposition com swapchain BGRA premultiplicado; não usa chave de cor para simular transparência. As superfícies são desenhadas sem um painel opaco escondido atrás dos cards. Valores padrão: fundo85%, sidebar90%, cards88%, cabeçalhos92%. Textos e ícones mantêm alpha legível após o fade de abertura.

O fechamento libera o mouse imediatamente, enquanto a animação termina. Quando o menu fica totalmente fechado, partículas, temas e controles deixam de ser atualizados. ESP habilitado com dados válidos continua sendo desenhado, como antes.

Limites de otimização e resultados: [docs/V2_VALIDATION.md](docs/V2_VALIDATION.md).

## Abrir sobre o Fortnite

1. Extraia **todo** o pacote Windows. Preserve a pasta `assets` junto de `ScarletExternal.exe`.
2. Abra Fortnite em **janela ou janela sem bordas**.
3. Execute `ScarletExternal.exe`. O processo aguarda a janela cujo executável é `FortniteClient-Win64-Shipping.exe`.
4. Com o Fortnite em primeiro plano, pressione **INSERT** para abrir o menu. O mouse interage com os controles.
5. Pressione INSERT novamente para fechar: a janela torna-se click-through e deixa de ativar o foco.
6. Ao minimizar o jogo ou trocar para outro aplicativo, o overlay é ocultado. Ele acompanha a área cliente quando a janela é movida ou redimensionada.
7. Há um ícone na bandeja do Windows. Clique com o botão direito para mostrar/ocultar ou **Sair**, inclusive enquanto aguarda Fortnite.

Atalhos padrão: **INSERT** menu, **F6** iniciar/parar Auto Chest, **F8** parada de emergência. São configuráveis; conflitos de registro são registrados no log. Sem o atalho do menu disponível, ele permanece visível para permitir recuperação. Se houver uma fonte de controle real no futuro, perder o foco do jogo também desativa a automação e libera o sink.

Tela cheia exclusiva não é suportada por este overlay desktop. Não há garantia de funcionamento sobre Fortnite sem execução e validação nesse ambiente; a compilação cruzada não substitui esse teste.

## Funcionalidades e disponibilidade

| Módulo | Implementação | No modo padrão desta entrega |
|---|---|---|
| Interface Scarlet | ImGuiStyle, ImDrawList, fontes e controles próprios; quatro categorias | Disponível quando a janela alvo é detectada |
| Overlay | Janela transparente Win32/DWM, DirectX 11, rastreamento de área cliente, ocultação e click-through | Implementado; execução Windows ainda a validar |
| PlayerESP | Box2D, skeleton, nomes, distância, vida, escudo, snaplines e cores a partir de campos disponíveis | Sem entidades: provider real não incluído |
| ChestESP | Estado Closed confirmado, disponibilidade, distância 50–1.000m, marcador, contador e destaque | Sem entidades: provider real não incluído |
| AutoChest | Estados, A*, verificação de obstáculos, interação, confirmação Open, retry, recuperação e emergência | Indisponível sem telemetria/controle autorizados |
| Configuração | JSON validado, save/load, normalização e carga atômica | Disponível; carga sempre desativa automação |

Os switches de ESP configuram módulos reais. Configurar um módulo não significa que uma fonte real esteja conectada. O menu informa **No data source / Waiting for authorized data** quando apropriado. Campos ausentes não são inventados; baús Unknown nunca são classificados como Closed.

## Testar o ambiente controlado

Para abrir o mesmo menu com uma simulação independente de Fortnite:

```powershell
.\ScarletExternal.exe --demo
```

O modo DEMO usa `MockGameDataProvider` e exibe `SCARLET / DEMO - MOCK DATA ONLY`. Em Auto Chest AFK, ative Enable Auto Chest ou pressione F6. O personagem simulado navega até os baús e só contabiliza abertura quando o provider confirma `Open`. AFK continua para o próximo; desativá-lo limita a uma coleta. Auto Retry e Stuck Recovery alteram o comportamento da máquina. Sem recuperação, a falta de progresso aciona a parada travada.

O executável sem interface oferece os cinco cenários reproduzíveis:

```powershell
.\fe_headless.exe --scenario baseline --steps 2000 --dt 0.05
.\fe_headless.exe --scenario blocked --steps 2000 --dt 0.05
.\fe_headless.exe --scenario stuck --steps 2000 --dt 0.05
.\fe_headless.exe --scenario timeout --steps 2000 --dt 0.05
.\fe_headless.exe --scenario unknown --steps 2000 --dt 0.05
```

## Compilar com Visual Studio 2022

Instale Desenvolvimento para desktop com C++, MSVC v143, Windows SDK e CMake >=3.25. Dependências de código e fontes já estão incluídas; o build não baixa pacotes.

No Developer PowerShell do VS2022, dentro da pasta do código-fonte:

```powershell
cmake --preset vs2022
cmake --build --preset vs2022-release --parallel
ctest --preset vs2022-release
.\build\vs2022\Release\ScarletExternal.exe
```

Para abrir a solução gerada:

```powershell
cmake --open build/vs2022
```

O pós-build copia `assets` para a pasta do executável. `ScarletWindowTests.exe` testa rastreamento de uma janela controlada no Windows; não usa Fortnite e não fornece dados do jogo.

## Configuração JSON

Por padrão, configuração e log ficam em `%LOCALAPPDATA%\ScarletExternal\config.json` e `scarlet.log`. Para usar outro arquivo:

```powershell
.\ScarletExternal.exe --config "C:\MinhaPasta\scarlet.json"
```

Save Config grava todas as opções. Load Config rejeita JSON malformado, chaves duplicadas/desconhecidas, tipos incorretos ou versão incompatível sem aplicar alterações parciais. Os limites são normalizados. Uma carga nunca inicia a automação automaticamente.

## Testes portáveis e prévia real do ImGui

Linux, GCC/Clang C++20, CMake e Ninja:

```sh
cmake --preset portable
cmake --build --preset portable --parallel
ctest --preset portable
./build/portable/ScarletPreview visuals.ppm assets 0
```

`ScarletPreview` usa o **mesmo menu C++/Dear ImGui**. Rasteriza os draw lists em CPU para uma imagem PPM; não é uma implementação web nem uma captura do Fortnite. Páginas: 0 Player ESP, 1 Chest ESP, 2 Auto Chest AFK, 3 Settings. Argumentos opcionais adicionais: índice de tema0–9 e seção Settings0–5. Exemplo: `ScarletPreview rgb.ppm assets 3 5 1 rgb`. `ScarletPreview --esp esp.ppm assets` gera uma prévia dos efeitos sobre o mock. `ScarletPreview --test assets` exercita os controles por eventos reais de mouse no ImGui.

```sh
cmake --preset sanitizers
cmake --build --preset sanitizers --parallel
ctest --preset sanitizers
```

Resultados atuais: [docs/V2_VALIDATION.md](docs/V2_VALIDATION.md). O relatório V1 permanece em docs/VALIDATION.md como histórico.
Arquitetura e requisitos para uma origem de dados autorizada: [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md), [docs/INTEGRATION.md](docs/INTEGRATION.md).

## Referência visual e limites

Layout, paleta e hierarquia seguem a imagem fornecida. Os ícones são vetoriais próprios para as novas funções. A referência não fornece o arquivo da fonte/logo original; Kaushan Script e Barlow foram incluídas como aproximações visuais. Não se afirma equivalência pixel a pixel nem validação visual sobre uma partida real.

Não há injeção de DLL, leitura da memória de Fortnite, offsets, driver, bypass ou desativação de proteções. O rastreador consulta somente metadados do processo para identificar a janela. Se essa consulta não for permitida pelo Windows, o alvo não é identificado.

Licenças e proveniência: [THIRD_PARTY.md](THIRD_PARTY.md).
