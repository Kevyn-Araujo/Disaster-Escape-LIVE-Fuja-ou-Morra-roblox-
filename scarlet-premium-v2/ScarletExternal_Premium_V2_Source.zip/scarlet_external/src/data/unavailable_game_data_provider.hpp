#pragma once
#include "data/game_data_provider.hpp"
namespace fe {
// Window detection is not a telemetry source. Default live mode publishes no entities.
class UnavailableGameDataProvider final : public IGameDataProvider, public IControlSink {
public:
    void tick(double) override {}
    GameSnapshot snapshot() const override { GameSnapshot value;value.connected=false;return value; }
    bool move_towards(Vec3,float,double) override { return false; }
    bool interact(EntityId) override { return false; }
    void stop() noexcept override {}
};
}
