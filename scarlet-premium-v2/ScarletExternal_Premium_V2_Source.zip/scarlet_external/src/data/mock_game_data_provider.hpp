#pragma once
#include "data/game_data_provider.hpp"
#include <shared_mutex>
namespace fe {
enum class MockScenario { Baseline, UnknownStates, Blocked, Stuck, InteractionTimeout };
class MockGameDataProvider final : public IGameDataProvider, public IControlSink {
public:
    explicit MockGameDataProvider(MockScenario scenario=MockScenario::Baseline);
    void tick(double seconds) override;
    GameSnapshot snapshot() const override;
    bool move_towards(Vec3 waypoint, float speed_mps, double seconds) override;
    bool interact(EntityId chest_id) override;
    void stop() noexcept override;
    void set_scenario(MockScenario scenario);
    void set_aspect_ratio(float aspect);
private:
    void reset_unlocked(MockScenario scenario);
    void update_camera_unlocked();
    mutable std::shared_mutex mutex_;
    GameSnapshot snapshot_;
    MockScenario scenario_{MockScenario::Baseline};
    std::optional<EntityId> pending_chest_;
    double opening_at_{};
    float aspect_{16.0f/9.0f};
};
} // namespace fe
