#pragma once
#include "core/types.hpp"
namespace fe {
class IGameDataProvider {
public:
    virtual ~IGameDataProvider() = default;
    virtual void tick(double seconds) = 0;
    virtual GameSnapshot snapshot() const = 0; // An owned, coherent snapshot.
};
class IControlSink {
public:
    virtual ~IControlSink() = default;
    virtual bool move_towards(Vec3 waypoint, float speed_mps, double seconds) = 0;
    virtual bool interact(EntityId chest_id) = 0;
    virtual void stop() noexcept = 0;
};
} // namespace fe
