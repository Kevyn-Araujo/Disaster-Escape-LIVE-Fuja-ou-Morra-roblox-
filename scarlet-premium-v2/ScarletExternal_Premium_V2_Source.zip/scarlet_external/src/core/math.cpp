#include "core/types.hpp"
#include <algorithm>
#include <cmath>
#include <limits>

namespace fe {
namespace {
Vec3 cross(Vec3 a, Vec3 b) {
    return {a.y*b.z-a.z*b.y, a.z*b.x-a.x*b.z, a.x*b.y-a.y*b.x};
}

std::optional<Vec3> normalized(Vec3 value) {
    if (!finite(value)) return std::nullopt;
    const double magnitude = std::hypot(
        static_cast<double>(value.x), static_cast<double>(value.y),
        static_cast<double>(value.z));
    if (!std::isfinite(magnitude) || magnitude <= 1.0e-8) return std::nullopt;
    return Vec3{static_cast<float>(value.x/magnitude),
                static_cast<float>(value.y/magnitude),
                static_cast<float>(value.z/magnitude)};
}

// Scaled pivoting rejects rank-deficient matrices without treating a large
// camera translation as a singularity. A valid provider may use perspective
// or orthographic projection; no particular last-row pattern is assumed.
bool usable_matrix(const Mat4& matrix) {
    double work[4][4]{};
    double scales[4]{};
    for (int row=0; row<4; ++row) {
        for (int col=0; col<4; ++col) {
            const float value = matrix.values[static_cast<std::size_t>(row*4+col)];
            if (!std::isfinite(value)) return false;
            work[row][col] = value;
            scales[row] = std::max(scales[row], std::abs(work[row][col]));
        }
        if (scales[row] == 0.0) return false;
    }
    for (int col=0; col<4; ++col) {
        int pivot = col;
        for (int row=col+1; row<4; ++row) {
            if (std::abs(work[row][col])/scales[row] >
                std::abs(work[pivot][col])/scales[pivot]) pivot = row;
        }
        if (std::abs(work[pivot][col])/scales[pivot] <= 1.0e-12) return false;
        if (pivot != col) {
            for (int i=0; i<4; ++i) std::swap(work[pivot][i], work[col][i]);
            std::swap(scales[pivot], scales[col]);
        }
        for (int row=col+1; row<4; ++row) {
            const double factor = work[row][col]/work[col][col];
            for (int i=col; i<4; ++i) work[row][i] -= factor*work[col][i];
        }
    }
    return true;
}

Mat4 multiply(const Mat4& left, const Mat4& right) {
    Mat4 result;
    for (std::size_t row=0; row<4; ++row) {
        for (std::size_t col=0; col<4; ++col) {
            double sum = 0;
            for (std::size_t i=0; i<4; ++i)
                sum += static_cast<double>(left.values[row*4+i])*right.values[i*4+col];
            result.values[row*4+col] = static_cast<float>(sum);
        }
    }
    return result;
}
} // namespace

Camera make_camera(Vec3 position, Vec3 target, float aspect, float vertical_fov_radians) {
    Camera camera;
    camera.position = position;
    constexpr float pi = 3.14159265358979323846f;
    if (!finite(position) || !finite(target) || !std::isfinite(aspect) || aspect<=0
        || !std::isfinite(vertical_fov_radians)
        || vertical_fov_radians<=0 || vertical_fov_radians>=pi) return camera;

    const auto forward = normalized(target-position);
    if (!forward) return camera;
    const auto right = normalized(cross({0,1,0}, *forward));
    if (!right) return camera;
    const auto up = normalized(cross(*forward, *right));
    if (!up) return camera;

    camera.forward = *forward;
    camera.up = *up;
    const Mat4 view{{
        right->x, right->y, right->z, -dot(*right,position),
        up->x, up->y, up->z, -dot(*up,position),
        forward->x, forward->y, forward->z, -dot(*forward,position),
        0,0,0,1
    }};
    constexpr float near_plane = 0.05f;
    constexpr float far_plane = 5000.0f;
    const float y_scale = 1.0f/std::tan(vertical_fov_radians*0.5f);
    const float depth_scale = far_plane/(far_plane-near_plane);
    const Mat4 projection{{
        y_scale/aspect,0,0,0,
        0,y_scale,0,0,
        0,0,depth_scale,-near_plane*depth_scale,
        0,0,1,0
    }};
    camera.view_projection = multiply(projection,view);
    camera.valid = usable_matrix(camera.view_projection);
    return camera;
}

std::optional<Vec2> world_to_screen(Vec3 world, const Camera& camera, float width, float height) {
    if (!camera.valid || !finite(world) || !finite(camera.position)
        || !finite(camera.forward) || !finite(camera.up)
        || !normalized(camera.forward) || !normalized(camera.up)
        || !normalized(cross(camera.forward,camera.up))
        || !std::isfinite(width) || !std::isfinite(height) || width<=0 || height<=0
        || !usable_matrix(camera.view_projection)) return std::nullopt;

    const auto& m = camera.view_projection.values;
    const double x = static_cast<double>(m[0])*world.x + static_cast<double>(m[1])*world.y
                   + static_cast<double>(m[2])*world.z + m[3];
    const double y = static_cast<double>(m[4])*world.x + static_cast<double>(m[5])*world.y
                   + static_cast<double>(m[6])*world.z + m[7];
    const double z = static_cast<double>(m[8])*world.x + static_cast<double>(m[9])*world.y
                   + static_cast<double>(m[10])*world.z + m[11];
    const double w = static_cast<double>(m[12])*world.x + static_cast<double>(m[13])*world.y
                   + static_cast<double>(m[14])*world.z + m[15];
    if (!std::isfinite(x) || !std::isfinite(y) || !std::isfinite(z)
        || !std::isfinite(w) || w<=1.0e-6) return std::nullopt;

    // DirectX clip volume: -w <= x,y <= w and 0 <= z <= w.
    const double tolerance = w*1.0e-7;
    if (x < -w-tolerance || x > w+tolerance || y < -w-tolerance || y > w+tolerance
        || z < -tolerance || z > w+tolerance) return std::nullopt;
    const double ndc_x = std::clamp(x/w,-1.0,1.0);
    const double ndc_y = std::clamp(y/w,-1.0,1.0);
    return Vec2{static_cast<float>((ndc_x+1.0)*0.5*width),
                static_cast<float>((1.0-ndc_y)*0.5*height)};
}
} // namespace fe
