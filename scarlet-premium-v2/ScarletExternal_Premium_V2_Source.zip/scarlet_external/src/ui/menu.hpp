#pragma once
#include "core/types.hpp"
#include "effects/ThemeManager.h"
#include "effects/AnimationManager.h"
#include "effects/ParticleSystem.h"
#include "effects/UIEffects.h"
#include <filesystem>
#include <string>
namespace fe {
struct Settings;
class IControlSink;
class AutoChestMachine;
class Logger;
struct MenuState {
    bool visible{false};
    int page{};
    Vec2 offset{};
    AnimationManager opening;ThemeManager theme_manager;ParticleSystem particles;UIEffects widgets;
    int settings_section{5},visual_section{0};
    double visual_time{};
    bool request_esp_preview{};
    std::string config_status;
};
struct RuntimeStatus {
    bool demo{}, attached{}, data_available{}, esp_preview{};
    std::string provider_name{"Sem provider autorizado"};
    std::string window_status{"Aguardando Fortnite"};
    GameSnapshot snapshot;
};
bool menu_rendering(const MenuState&) noexcept;
bool load_scarlet_fonts(const std::filesystem::path& assets);
void apply_scarlet_style();
void draw_menu(MenuState&,Settings&,IControlSink&,AutoChestMachine&,Logger&,
               const std::filesystem::path&,const RuntimeStatus&);
}
