#include "ui/menu.hpp"
#include "automation/auto_chest.hpp"
#include "config/settings.hpp"
#include "esp/filters.hpp"
#include "utils/logger.hpp"
#include "imgui.h"
#include "effects/RGBManager.h"
#include "config/ConfigManager.h"
#include <cstring>
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <string>

namespace fe {
namespace {
ImFont* text_font{};
ImFont* logo_font{};
constexpr ImU32 red=IM_COL32(255,53,40,255),white=IM_COL32(242,242,242,255);
constexpr ImU32 muted=IM_COL32(107,107,107,255),edge=IM_COL32(28,28,28,255);
constexpr ImU32 bg=IM_COL32(15,15,15,255),body=IM_COL32(18,18,18,255),header=IM_COL32(25,25,25,255);
struct Canvas {
    ImDrawList* d;
    ImVec2 origin;
    float scale;
    MenuState& menu;const PremiumSettings& premium;float opacity;
    ImU32 ink(ImU32 source,float alpha=1) const {
        const auto& p=menu.theme_manager.palette();Color color;
        if(source==red)color=p.primary;else if(source==white)color=p.text;
        else if(source==muted){color=p.text;for(int i=0;i<3;++i)color[i]*=.48f;}
        else if(source==edge)color=p.border;else if(source==bg)color=p.background;
        else if(source==body)color=p.card;else if(source==header)color=p.header;
        else if(source==IM_COL32(184,184,184,255)){color=p.text;for(int i=0;i<3;++i)color[i]*=.77f;}
        else {ImVec4 v=ImGui::ColorConvertU32ToFloat4(source);color={v.x,v.y,v.z,v.w};}
        if(source==edge)alpha*=premium.appearance.border_opacity;
        return ImGui::ColorConvertFloat4ToU32({color[0],color[1],color[2],color[3]*opacity*alpha});
    }
    ImU32 accent(bool use_rgb,float phase=0) const {
        RGBSettings rgb=premium.rgb;if(!use_rgb)rgb.enabled=false;
        if(premium.animation.disable_all||premium.performance.low_performance)rgb.speed=0;
        auto color=RGBManager::sample(rgb,menu.visual_time,phase,menu.theme_manager.palette().primary);
        return ImGui::ColorConvertFloat4ToU32({color[0],color[1],color[2],color[3]});
    }
    float smooth(const char* id,float target) const {return menu.widgets.scalar(ImGui::GetID(id),target);}
    void outline(float x,float y,float w,float h,float alpha=1) const {
        ImU32 color=premium.rgb.enabled&&premium.rgb.borders?ink(accent(true,y/850),premium.appearance.border_opacity):ink(edge);
        const ImVec4 v=ImGui::ColorConvertU32ToFloat4(color);
        color=ImGui::ColorConvertFloat4ToU32({v.x,v.y,v.z,v.w*alpha*stage(x,y)});
        d->AddRect(p(x,y),p(x+w,y+h),color,8*scale,0,scale);
        if((premium.appearance.theme==4||premium.appearance.theme==5)&&!premium.performance.low_performance&&!premium.performance.disable_heavy_effects){
            for(int i=1;i<=2;++i){const float pad=i*.7f;const ImU32 glow=ImGui::ColorConvertFloat4ToU32({v.x,v.y,v.z,v.w*.10f*alpha});
                d->AddRect(p(x-pad,y-pad),p(x+w+pad,y+h+pad),glow,(8+pad)*scale,0,(2+i)*scale);}
        }
    }
    float stage(float x,float y) const {
        if(!premium.animation.enabled||premium.animation.disable_all)return 1;
        const float progress=menu.opening.progress();
        const float delay=x<245?.05f:(x<1095&&y>=97?.10f:0);
        return std::clamp((progress-delay)/(1-delay),0.0f,1.0f);
    }
    ImVec2 p(float x,float y) const {return {origin.x+x*scale,origin.y+y*scale};}
    void rect(float x,float y,float w,float h,ImU32 color,float rounding=0) const {
        float alpha=1;
        if(color==bg)alpha=premium.appearance.background_opacity;
        else if(color==body)alpha=premium.appearance.card_opacity;
        else if(color==header)alpha=premium.appearance.header_opacity;
        d->AddRectFilled(p(x,y),p(x+w,y+h),ink(color,alpha*stage(x,y)),rounding*scale);
    }
    void text(float x,float y,const std::string& value,ImU32 color=white,float size=21,ImFont* font=nullptr) const {
        d->AddText(font?font:text_font,size*scale,p(x,y),ink(color,stage(x,y)),value.c_str());
    }
    void line(float x,float y,float x2,float y2,ImU32 color,float weight=1) const {
        d->AddLine(p(x,y),p(x2,y2),ink(color,stage(x,y)),weight*scale);
    }
    bool hit(const std::string& id,float x,float y,float w,float h) const {
        ImGui::SetCursorScreenPos(p(x,y));
        ImGui::InvisibleButton(id.c_str(),{w*scale,h*scale});
        return menu.visible&&ImGui::IsItemClicked();
    }
    void icon(int kind,float x,float y,ImU32 color,float size=24) const {
        const float k=size/24;
        auto l=[&](float a,float b,float c,float e,float t=2){line(x+a*k,y+b*k,x+c*k,y+e*k,color,t);};
        auto circle=[&](float a,float b,float radius,bool filled){
            if(filled)d->AddCircleFilled(p(x+a*k,y+b*k),radius*k*scale,ink(color),20);
            else d->AddCircle(p(x+a*k,y+b*k),radius*k*scale,ink(color),20,2*scale);
        };
        if(kind==0) {circle(12,4,3,true);l(12,9,12,16);l(12,10,6,14);l(12,10,18,14);l(12,16,7,23);l(12,16,17,23);}
        else if(kind==1) {
            d->AddRect(p(x+2*k,y+7*k),p(x+22*k,y+22*k),ink(color),2*scale,0,2*scale);
            l(2,13,22,13);l(9,10,9,16);l(15,10,15,16);l(5,7,7,2);l(7,2,17,2);l(17,2,19,7);
        } else if(kind==2) {
            circle(4,20,3,false);circle(20,4,3,false);l(7,20,16,20);l(16,20,17,18);l(17,18,17,13);l(17,13,7,13);l(7,13,7,5);l(7,5,16,5);
        } else if(kind==3) {
            circle(12,12,7,false);circle(12,12,2,true);
            for(int i=0;i<8;++i){float a=static_cast<float>(i)*.785398f;l(12+8*std::cos(a),12+8*std::sin(a),12+11*std::cos(a),12+11*std::sin(a),3);}
        } else if(kind==4) {
            d->AddBezierCubic(p(x,y+12*k),p(x+8*k,y-2*k),p(x+16*k,y-2*k),p(x+24*k,y+12*k),ink(color),2*scale);
            d->AddBezierCubic(p(x,y+12*k),p(x+8*k,y+26*k),p(x+16*k,y+26*k),p(x+24*k,y+12*k),ink(color),2*scale);
            circle(12,12,4,true);
        } else {circle(12,12,10,false);l(12,6,12,13);circle(12,18,1,true);}
    }
};
void card(const Canvas& c,const char* title,int icon,float x,float y,float w,float h) {
    c.d->AddRectFilled(c.p(x,y+46),c.p(x+w,y+h),c.ink(body,c.premium.appearance.card_opacity*c.stage(x,y)),8*c.scale,ImDrawFlags_RoundCornersBottom);
    c.d->AddRectFilled(c.p(x,y),c.p(x+w,y+46),c.ink(header,c.premium.appearance.header_opacity*c.stage(x,y)),8*c.scale,ImDrawFlags_RoundCornersTop);
    const ImVec2 mouse=ImGui::GetIO().MousePos;const bool hover=mouse.x>=c.p(x,y).x&&mouse.x<=c.p(x+w,y).x&&mouse.y>=c.p(x,y).y&&mouse.y<=c.p(x,y+h).y;
    ImGui::PushID(title);const float hlight=c.smooth("card_hover",hover?1.0f:0.0f);ImGui::PopID();
    c.outline(x,y,w,h,.25f+hlight*.6f);
    if(c.premium.rgb.header_line)c.line(x+10,y+45,x+w-10,y+45,c.accent(c.premium.rgb.enabled,y/850),1);
    c.icon(icon,x+16,y+11,red,23);c.text(x+50,y+10,title,white,24);
}
void toggle(const Canvas& c,const char* label,bool& value,float x,float y,float w,bool locked=false) {
    const bool pressed=c.hit(label,x,y,w,34);
    if(pressed&&!locked)value=!value;
    const bool hover=ImGui::IsItemHovered();
    if(hover&&!locked)c.rect(x-4,y,w+8,34,IM_COL32(24,24,24,255),4);
    c.text(x,y+4,label,locked?muted:IM_COL32(184,184,184,255),20);
    const float sx=x+w-44;
    const float transition=c.smooth(label,value?1.0f:0.0f);
    const ImU32 track=value?(locked?IM_COL32(105,39,34,255):c.accent(c.premium.rgb.toggles,y/850)):IM_COL32(32,32,32,255);
    c.rect(sx,y+8,44,21,track,11);
    c.d->AddCircleFilled(c.p(sx+(11+22*transition),y+18.5f),8*c.scale,
                        c.ink(value?white:IM_COL32(67,67,67,255)),24);
    if(locked&&hover)ImGui::SetTooltip("Regra obrigatoria; este filtro nao pode ser desativado.");
}
void slider(const Canvas& c,const char* label,float& value,float lo,float hi,float x,float y,float w,const char* unit) {
    c.text(x,y,label,IM_COL32(184,184,184,255),20);
    char number[48];std::snprintf(number,sizeof(number),hi-lo<=10?"%.2f%s":"%.0f%s",value,unit);
    const float tw=text_font->CalcTextSizeA(18*c.scale,1000,0,number).x/c.scale;
    c.text(x+w-tw,y+2,number,muted,18);
    const float tx=x+8,ty=y+38,track=w-16;
    c.hit(std::string(label)+"##slider",x,y+23,w,30);
    if(ImGui::IsItemActive()) {
        const float position=(ImGui::GetIO().MousePos.x-c.p(tx,ty).x)/(track*c.scale);
        value=lo+std::clamp(position,0.0f,1.0f)*(hi-lo);
    }
    const float raw=std::clamp((value-lo)/(hi-lo),0.0f,1.0f);
    const float t=c.smooth(label,raw);
    c.rect(tx,ty-5,track,10,IM_COL32(58,58,58,255),5);
    if(t>0)c.rect(tx,ty-5,track*t,10,c.accent(c.premium.rgb.sliders,y/850),5);
    c.d->AddCircleFilled(c.p(tx+track*t,ty),9*c.scale,c.ink(white),24);
}
bool button(const Canvas& c,const char* label,float x,float y,float w,float h=36,bool accent=false) {
    const bool clicked=c.hit(label,x,y,w,h);
    const float hover=c.smooth(label,ImGui::IsItemHovered()?1.0f:0.0f);
    c.outline(x-1,y-1,w+2,h+2,.15f+hover*.5f);
    c.rect(x,y,w,h,accent?red:(ImGui::IsItemHovered()?IM_COL32(42,42,42,255):IM_COL32(29,29,29,255)),5);
    const float size=19*c.scale;
    const auto dim=text_font->CalcTextSizeA(size,1000,0,label);
    c.d->AddText(text_font,size,{c.p(x+w*.5f,y).x-dim.x*.5f,c.p(x,y+h*.5f).y-dim.y*.5f},c.ink(white),label);
    return clicked;
}
const char* key_name(int value) {
    switch(value){case 0x2D:return "INSERT";case 0x24:return "HOME";case 0x74:return "F5";case 0x75:return "F6";case 0x76:return "F7";case 0x77:return "F8";case 0x78:return "F9";case 0x79:return "F10";default:return "F11";}
}
void key_row(const Canvas& c,const char* label,int& key,const int* choices,int count,float x,float y,float w) {
    c.text(x,y+7,label,IM_COL32(184,184,184,255),20);
    if(button(c,key_name(key),x+w-88,y,88)) {
        int index=0;for(int i=0;i<count;++i)if(choices[i]==key)index=i;
        key=choices[(index+1)%count];
    }
}
void color_row(const Canvas& c,const char* label,Color& color,float x,float y,float w) {
    c.text(x,y+5,label,IM_COL32(184,184,184,255),20);
    if(c.hit(std::string(label)+"##color",x+w-38,y+5,38,22))ImGui::OpenPopup(label);
    const float hover=c.smooth(label,ImGui::IsItemHovered()?1.0f:0.0f);c.outline(x+w-40,y+4,42,25,.3f+hover*.6f);
    c.rect(x+w-38,y+6,38,21,ImGui::ColorConvertFloat4ToU32({color[0],color[1],color[2],color[3]}),4);
    if(ImGui::BeginPopup(label)){ImGui::ColorPicker4(label,color.data(),ImGuiColorEditFlags_AlphaBar);ImGui::EndPopup();}
}
void automation(const Canvas& c,Settings& settings,const RuntimeStatus& runtime,float x,float y,float w) {
    auto& a=settings.automation;
    const bool before=a.enabled;toggle(c,"Enable Auto Chest",a.enabled,x,y,w);
    if(!before&&a.enabled&&!runtime.data_available)a.enabled=false;
    toggle(c,"AFK Mode",a.afk_mode,x,y+35,w);
    toggle(c,"Auto Navigate",a.auto_navigate,x,y+70,w);
    toggle(c,"Auto Interact",a.auto_interact,x,y+105,w);
    toggle(c,"Auto Retry",a.auto_retry,x,y+140,w);
    toggle(c,"Stuck Recovery",a.stuck_recovery,x,y+175,w);
}
void choose_mode(const Canvas& c,const char* const* names,int count,int& selected,float x,float y,float w,int columns=2){
    for(int i=0;i<count;++i){ImGui::PushID(i);if(button(c,names[i],x+(i%columns)*(w/columns+5),y+(i/columns)*44,w/columns-5,35,selected==i))selected=i;ImGui::PopID();}
}
void draw_special_settings(const Canvas& c,Settings& settings){
    auto& e=settings.premium.esp;constexpr float lx=260,rx=664,cw=398;
    if(c.menu.visual_section==1){
        card(c,"Chinese Hat ESP",0,lx,97,cw,728);
        toggle(c,"Enable Chinese Hat",e.hat,lx+20,155,cw-50);
        slider(c,"Hat Radius",e.hat_radius,.05f,2,lx+20,210,cw-50," m");
        slider(c,"Hat Height",e.hat_height,.05f,2,lx+20,282,cw-50," m");
        slider(c,"Hat Thickness",e.hat_thickness,.5f,6,lx+20,354,cw-50," px");
        color_row(c,"Hat Color",e.hat_color,lx+20,430,cw-50);
        toggle(c,"Rainbow Hat",e.hat_rainbow,lx+20,477,cw-50);
        toggle(c,"Filled / Wireframe",e.hat_filled,lx+20,519,cw-50);
        c.text(lx+20,600,"Requires a valid head anchor",muted,18);
        c.text(lx+20,635,"Fixed cached cone geometry",muted,18);
        card(c,"Hula Hoop ESP",2,rx,97,cw,728);
        toggle(c,"Enable Hula Hoop",e.hoop,rx+20,155,cw-50);
        slider(c,"Hoop Radius",e.hoop_radius,.05f,3,rx+20,210,cw-50," m");
        slider(c,"Hoop Thickness",e.hoop_thickness,.5f,6,rx+20,282,cw-50," px");
        slider(c,"Rotation Speed",e.hoop_speed,0,6,rx+20,354,cw-50," rad/s");
        slider(c,"Height Offset",e.hoop_height_offset,-2,2,rx+20,426,cw-50," m");
        color_row(c,"Hoop Color",e.hoop_color,rx+20,503,cw-50);
        toggle(c,"Rainbow Hoop",e.hoop_rainbow,rx+20,550,cw-50);
        if(button(c,e.hoop_direction==1?"Direction: Clockwise":"Direction: Counterclockwise",rx+20,605,cw-40,38))e.hoop_direction=-e.hoop_direction;
        c.text(rx+20,682,"Requires a valid waist anchor",muted,18);
        c.text(rx+20,717,"Visual Test opens a separate demo",muted,17);
    }else{
        card(c,"Special ESP Effects",4,lx,97,cw,400);
        toggle(c,"3D Box ESP",e.box_3d,lx+20,155,cw-50);
        toggle(c,"Corner Box ESP",e.corner_box,lx+20,198,cw-50);
        toggle(c,"Gradient Box",e.gradient_box,lx+20,241,cw-50);
        toggle(c,"Outline ESP",e.outline,lx+20,284,cw-50);
        toggle(c,"Player Glow Outline",e.glow_outline,lx+20,327,cw-50);
        card(c,"RGB ESP",0,rx,97,cw,400);
        toggle(c,"RGB Skeleton",e.rgb_skeleton,rx+20,155,cw-50);
        toggle(c,"RGB Snaplines",e.rgb_snaplines,rx+20,198,cw-50);
        toggle(c,"Distance Color Gradient",e.distance_gradient,rx+20,241,cw-50);
        c.text(rx+20,319,"Colors share RGB speed / brightness",muted,17);
        card(c,"Provider Data",5,lx,503,802,322);
        c.text(lx+20,565,"3D boxes require observed body bounds. Hoops require an observed waist.",muted,20);
        c.text(lx+20,606,"Missing anchors are omitted. No live entities or bones are inferred.",muted,20);
        c.text(lx+20,652,"Visual Test: explicit mock data, separate camera, no game input.",white,20);
        c.text(lx+20,700,"Performance Mode reduces geometry and disables fill / glow.",muted,20);
    }
}
void draw_premium_settings(const Canvas& c,Settings& settings){
    auto& p=settings.premium;constexpr float lx=260,rx=664,cw=398;
    if(c.menu.settings_section==0){
        card(c,"Appearance",3,lx,97,cw,728);
        slider(c,"Background Transparency",p.appearance.background_opacity,0,1,lx+20,155,cw-50," opacity");
        slider(c,"Sidebar Transparency",p.appearance.sidebar_opacity,0,1,lx+20,221,cw-50," opacity");
        slider(c,"Card Transparency",p.appearance.card_opacity,0,1,lx+20,287,cw-50," opacity");
        slider(c,"Header Transparency",p.appearance.header_opacity,0,1,lx+20,353,cw-50," opacity");
        slider(c,"Border Opacity",p.appearance.border_opacity,0,1,lx+20,419,cw-50,"");
        slider(c,"UI Scale",p.appearance.ui_scale,.75f,1.4f,lx+20,485,cw-50," x");
        ImGui::SetCursorScreenPos(c.p(lx+20,580));ImGui::SetNextItemWidth(345*c.scale);
        char name[257]{};std::snprintf(name,sizeof(name),"%s",p.profile.name.c_str());
        if(ImGui::InputText("##ProfileName",name,sizeof(name)))p.profile.name=name;
        c.text(lx+20,553,"Profile Name",muted,19);
        ImGui::SetCursorScreenPos(c.p(lx+20,660));ImGui::SetNextItemWidth(345*c.scale);
        char status[129]{};std::snprintf(status,sizeof(status),"%s",p.profile.status.c_str());
        if(ImGui::InputText("##ProfileStatus",status,sizeof(status)))p.profile.status=status;
        c.text(lx+20,633,"Profile Status",muted,19);
        c.text(lx+20,744,"Theme choice saves automatically",muted,18);
        card(c,"Theme Manager",3,rx,97,cw,728);
        for(int i=0;i<10;++i){
            ImGui::PushID(i);const float x=rx+20+(i%2)*181,y=156+(i/2)*44.0f;
            if(button(c,ThemeManager::name(i),x,y,172,36,p.appearance.theme==i))p.appearance.theme=i;
            const auto palette=ThemeManager::palette_for(i,p.appearance);
            c.rect(x+5,y+29,50,3,ImGui::ColorConvertFloat4ToU32({palette.primary[0],palette.primary[1],palette.primary[2],1}),1);
            c.rect(x+55,y+29,50,3,ImGui::ColorConvertFloat4ToU32({palette.accent[0],palette.accent[1],palette.accent[2],1}),1);ImGui::PopID();
        }
        c.text(rx+20,397,"Custom Colors",white,21);
        color_row(c,"Primary Color",p.appearance.primary,rx+20,435,cw-50);
        color_row(c,"Secondary Color",p.appearance.secondary,rx+20,477,cw-50);
        color_row(c,"Background Color",p.appearance.background,rx+20,519,cw-50);
        color_row(c,"Text Color",p.appearance.text,rx+20,561,cw-50);
        color_row(c,"Border Color",p.appearance.border,rx+20,603,cw-50);
        color_row(c,"Accent Color",p.appearance.accent,rx+20,645,cw-50);
        c.text(rx+20,725,"Select Custom to apply custom colors",muted,18);
    }else if(c.menu.settings_section==1){
        card(c,"RGB Effects",4,lx,97,cw,728);
        toggle(c,"Enable Menu RGB",p.rgb.enabled,lx+20,155,cw-50);
        toggle(c,"Rainbow Mode",p.rgb.rainbow,lx+20,192,cw-50);
        toggle(c,"RGB Sidebar",p.rgb.sidebar,lx+20,229,cw-50);
        toggle(c,"RGB Borders",p.rgb.borders,lx+20,266,cw-50);
        toggle(c,"RGB Logo",p.rgb.logo,lx+20,303,cw-50);
        toggle(c,"RGB Sliders",p.rgb.sliders,lx+20,340,cw-50);
        toggle(c,"RGB Toggle Effects",p.rgb.toggles,lx+20,377,cw-50);
        toggle(c,"RGB Header Line",p.rgb.header_line,lx+20,414,cw-50);
        slider(c,"RGB Speed",p.rgb.speed,0,2,lx+20,482,cw-50," cycles/s");
        slider(c,"RGB Brightness",p.rgb.brightness,0,1,lx+20,562,cw-50,"");
        card(c,"Color Modes",3,rx,97,cw,728);
        const char* modes[]={"Rainbow","Breathing","Color Wave","Static Color","Gradient","Pulse"};choose_mode(c,modes,6,p.rgb.mode,rx+20,156,cw-42);
        c.text(rx+20,330,"Live HSV Preview",muted,20);
        for(int row=0;row<3;++row)for(int i=0;i<40;++i){
            RGBSettings rgb=p.rgb;rgb.enabled=true;
            const auto col=RGBManager::sample(rgb,c.menu.visual_time,static_cast<float>(i)/40+row*.17f,c.menu.theme_manager.palette().primary);
            c.rect(rx+20+i*8.8f,382+row*54,9,28,ImGui::ColorConvertFloat4ToU32({col[0],col[1],col[2],1}),0);
        }
        c.text(rx+20,610,"Smooth transitions; no hard flashing",muted,18);
        c.text(rx+20,651,"Off restores the selected theme",muted,18);
    }else if(c.menu.settings_section==2){
        card(c,"Particles",4,lx,97,cw,728);
        toggle(c,"Enable RGB Particles",p.particles.enabled,lx+20,155,cw-50);
        toggle(c,"Particle Connections",p.particles.connections,lx+20,195,cw-50);
        toggle(c,"Mouse Interaction",p.particles.mouse_interaction,lx+20,235,cw-50);
        float count=static_cast<float>(p.particles.count);slider(c,"Particle Count",count,0,100,lx+20,292,cw-50,"");p.particles.count=static_cast<int>(std::round(count));
        slider(c,"Particle Speed",p.particles.speed,0,3,lx+20,366,cw-50,"");
        slider(c,"Particle Size",p.particles.size,.25f,6,lx+20,440,cw-50," px");
        slider(c,"Particle Opacity",p.particles.opacity,0,1,lx+20,514,cw-50,"");
        color_row(c,"Particle Color",p.particles.color,lx+20,601,cw-50);
        card(c,"Background Effects",2,rx,97,cw,728);
        c.text(rx+20,162,"Active Particles",muted,20);c.text(rx+20,199,std::to_string(c.menu.particles.count()),white,34);
        c.text(rx+20,280,"Seasonal motion follows your theme",muted,19);
        c.text(rx+20,328,"Christmas: snow / Sakura: petals",muted,18);
        c.text(rx+20,376,"Connections use bounded neighbors",muted,18);
        c.text(rx+20,424,"Performance Mode caps count at 25",muted,18);
        c.text(rx+20,472,"All particles stay behind the controls",muted,18);
    }else if(c.menu.settings_section==3){
        card(c,"Animations",2,lx,97,cw,728);
        toggle(c,"Menu Open Animation",p.animation.enabled,lx+20,155,cw-50);
        toggle(c,"Disable Animations",p.animation.disable_all,lx+20,198,cw-50);
        toggle(c,"Smooth Transitions",p.animation.smooth_transitions,lx+20,241,cw-50);
        slider(c,"Animation Speed",p.animation.speed,.25f,4,lx+20,308,cw-50," x");
        slider(c,"Duration",p.animation.duration_ms,50,1000,lx+20,389,cw-50," ms");
        const char* styles[]={"Premium","Fade In","Smooth Scale","Slide In","Ease Out"};choose_mode(c,styles,5,p.animation.style,lx+20,490,cw-42);
        if(button(c,"Replay Opening",lx+20,680,cw-40,42,true))c.menu.opening=AnimationManager{};
        card(c,"Motion Preview",4,rx,97,cw,728);
        c.text(rx+20,162,"DeltaTime Based",white,25);
        c.text(rx+20,224,"Open: 220 ms by default",muted,20);
        c.text(rx+20,267,"Close: short inverse transition",muted,20);
        c.text(rx+20,310,"Mouse input is released immediately",muted,18);
        const float hover=c.smooth("motion_preview",ImGui::IsMouseHoveringRect(c.p(rx+20,410),c.p(rx+370,570))?1.0f:0.0f);
        c.rect(rx+20,410,350,160,body,10);c.outline(rx+20,410,350,160,.2f+hover*.8f);
        c.rect(rx+40,470,50+260*hover,12,c.accent(true),6);c.text(rx+40,430,"Hover to preview interpolation",muted,18);
    }else{
        card(c,"Performance",3,lx,97,cw,728);
        float fps=static_cast<float>(settings.overlay.fps_limit);slider(c,"FPS Limit",fps,15,240,lx+20,155,cw-50," FPS");settings.overlay.fps_limit=static_cast<int>(std::round(fps));
        toggle(c,"Vertical Sync",settings.overlay.vsync,lx+20,235,cw-50);
        toggle(c,"Low Performance Mode",p.performance.low_performance,lx+20,285,cw-50);
        toggle(c,"Disable Heavy Effects",p.performance.disable_heavy_effects,lx+20,335,cw-50);
        toggle(c,"Performance Statistics",p.performance.statistics,lx+20,385,cw-50);
        c.text(lx+20,475,"Low Mode: 25 particles, no links",muted,18);
        c.text(lx+20,518,"ESP geometry reduced; no fill/glow",muted,18);
        c.text(lx+20,561,"No visual updates after close finishes",muted,18);
        card(c,"Statistics",4,rx,97,cw,728);
        if(p.performance.statistics){char line[100];
            std::snprintf(line,sizeof(line),"UI FPS: %.1f",ImGui::GetIO().Framerate);c.text(rx+20,163,line,white,26);
            std::snprintf(line,sizeof(line),"Frame interval: %.2f ms",ImGui::GetIO().DeltaTime*1000);c.text(rx+20,219,line,muted,20);
            c.text(rx+20,275,"Particles: "+std::to_string(c.menu.particles.count()),muted,20);
            c.text(rx+20,331,"Animation cache: "+std::to_string(c.menu.widgets.size())+" / 1024",muted,20);
            c.text(rx+20,387,"Draw vertices: "+std::to_string(ImGui::GetIO().MetricsRenderVertices),muted,20);
        }else c.text(rx+20,163,"Statistics disabled",muted,20);
        c.text(rx+20,520,"No game-impact benchmark claimed",muted,18);
        c.text(rx+20,564,"No realtime blur / no font reloads",muted,18);
    }
}
}

bool menu_rendering(const MenuState& menu) noexcept {return menu.visible||menu.opening.active();}

bool load_scarlet_fonts(const std::filesystem::path& assets) {
    auto& io=ImGui::GetIO();ImFontConfig config;config.OversampleH=3;config.OversampleV=2;
    const auto regular=assets/"fonts/Barlow-SemiBold.ttf",logo=assets/"fonts/KaushanScript-Regular.ttf";
    bool ok=std::filesystem::exists(regular)&&std::filesystem::exists(logo);
    if(std::filesystem::exists(regular))text_font=io.Fonts->AddFontFromFileTTF(regular.string().c_str(),24,&config);
    if(!text_font)text_font=io.Fonts->AddFontDefault();
    if(std::filesystem::exists(logo))logo_font=io.Fonts->AddFontFromFileTTF(logo.string().c_str(),76,&config);
    if(!logo_font){logo_font=text_font;ok=false;}io.FontDefault=text_font;
    return ok;
}
void apply_scarlet_style() {
    auto& s=ImGui::GetStyle();s.WindowPadding={0,0};s.WindowBorderSize=0;s.WindowRounding=10;
    s.FrameRounding=5;s.PopupRounding=6;s.ScrollbarSize=5;s.ScrollbarRounding=4;s.ItemSpacing={8,8};
    for(auto& color:s.Colors)color=ImVec4(.12f,.12f,.12f,1);
    s.Colors[ImGuiCol_Text]={.94f,.94f,.94f,1};s.Colors[ImGuiCol_WindowBg]={.059f,.059f,.059f,1};
    s.Colors[ImGuiCol_PopupBg]={.08f,.08f,.08f,1};s.Colors[ImGuiCol_Border]={.15f,.15f,.15f,1};
    s.Colors[ImGuiCol_FrameBg]={.15f,.15f,.15f,1};s.Colors[ImGuiCol_FrameBgHovered]={.2f,.2f,.2f,1};
    s.Colors[ImGuiCol_FrameBgActive]={.25f,.25f,.25f,1};s.Colors[ImGuiCol_SliderGrab]={1,.208f,.157f,1};
    s.Colors[ImGuiCol_SliderGrabActive]={1,.208f,.157f,1};s.Colors[ImGuiCol_CheckMark]={1,.208f,.157f,1};
    s.Colors[ImGuiCol_Button]={.14f,.14f,.14f,1};s.Colors[ImGuiCol_ButtonHovered]={.22f,.22f,.22f,1};
    s.Colors[ImGuiCol_Header]={.2f,.1f,.1f,1};s.Colors[ImGuiCol_HeaderHovered]={.3f,.12f,.1f,1};
    s.Colors[ImGuiCol_NavCursor]={1,.208f,.157f,1};
}
void draw_menu(MenuState& menu,Settings& settings,IControlSink& controls,AutoChestMachine& machine,
               Logger& logger,const std::filesystem::path& config_path,const RuntimeStatus& runtime) {
    auto& premium=settings.premium;
    float dt=std::clamp(ImGui::GetIO().DeltaTime,0.0f,.25f);
    if(menu.visible&&!menu.was_visible)dt=std::min(dt,1.0f/60);
    menu.was_visible=menu.visible;
    menu.opening.update(menu.visible,dt,premium.animation);
    if(!menu_rendering(menu))return;
    const bool smooth=premium.animation.smooth_transitions&&!premium.animation.disable_all&&!premium.performance.low_performance;
    menu.widgets.begin_frame(dt,smooth);
    menu.visual_time+=premium.animation.disable_all?0:dt;
    menu.theme_manager.update(premium.appearance,dt,smooth);
    // Native text fields, logs and color-picker popups follow the same palette.
    const auto& palette=menu.theme_manager.palette();
    auto vec=[](const Color& c){return ImVec4(c[0],c[1],c[2],c[3]);};
    auto& native=ImGui::GetStyle();native.Colors[ImGuiCol_Text]=vec(palette.text);
    native.Colors[ImGuiCol_PopupBg]=vec(palette.card);native.Colors[ImGuiCol_FrameBg]=vec(palette.header);
    native.Colors[ImGuiCol_Border]=vec(palette.border);native.Colors[ImGuiCol_CheckMark]=vec(palette.primary);
    native.Colors[ImGuiCol_SliderGrab]=vec(palette.primary);native.Colors[ImGuiCol_SliderGrabActive]=vec(palette.accent);
    const int original_theme=premium.appearance.theme;
    const float progress=menu.opening.progress();
    const auto display=ImGui::GetIO().DisplaySize;
    const float fit=std::min((display.x-10)/1237.0f,(display.y-10)/850.0f);
    float scale=std::min(premium.appearance.ui_scale,fit);
    if(premium.animation.style==0||premium.animation.style==2)scale*=.94f+.06f*progress;
    if(scale<=0)return;
    const ImVec2 size{1237*scale,850*scale};
    const float ox=std::clamp((display.x-size.x)*.5f+menu.offset.x,0.0f,std::max(0.0f,display.x-size.x));
    float oy=std::clamp((display.y-size.y)*.5f+menu.offset.y,0.0f,std::max(0.0f,display.y-size.y));
    if(premium.animation.style==0||premium.animation.style==3)oy+=(1-progress)*18*scale;
    const float fade=(premium.animation.style==0||premium.animation.style==1||premium.animation.style==4)?progress:1;
    ImGui::PushStyleVar(ImGuiStyleVar_Alpha,fade);
    ImGui::SetNextWindowPos({ox,oy});ImGui::SetNextWindowSize(size);
    constexpr auto flags=ImGuiWindowFlags_NoBackground|ImGuiWindowFlags_NoDecoration|ImGuiWindowFlags_NoSavedSettings|ImGuiWindowFlags_NoMove|ImGuiWindowFlags_NoScrollWithMouse|ImGuiWindowFlags_NoScrollbar;
    ImGui::Begin("Scarlet##root",nullptr,flags);
    ImGui::BeginDisabled(!menu.visible);
    Canvas c{ImGui::GetWindowDrawList(),{ox,oy},scale,menu,premium,fade};
    // Paint disjoint surfaces: opacity sliders are not multiplied by a hidden opaque panel.
    c.rect(245,0,850,97,bg);c.rect(1095,0,142,850,bg,10);c.rect(245,825,850,25,bg);
    c.rect(245,97,15,728,bg);c.rect(1062,97,33,728,bg);
    const bool wide_bottom=(menu.page==3&&menu.settings_section==5)||(menu.page==0&&menu.visual_section==2);
    const bool full_columns=(menu.page==3&&menu.settings_section!=5)||(menu.page==0&&menu.visual_section==1);
    c.rect(658,97,6,wide_bottom?400:728,bg);
    if(wide_bottom)c.rect(260,497,802,6,bg);
    else if(!full_columns){c.rect(260,497,398,6,bg);c.rect(664,531,398,5,bg);}
    const auto& sidebar=menu.theme_manager.palette().sidebar;
    c.rect(0,0,245,850,ImGui::ColorConvertFloat4ToU32({sidebar[0],sidebar[1],sidebar[2],premium.appearance.sidebar_opacity}),10);
    ParticleSettings ps=premium.particles;ps.size*=scale;
    if(premium.animation.disable_all)ps.speed=0;
    if(premium.performance.disable_heavy_effects)ps.connections=false;
    const auto mouse=ImGui::GetIO().MousePos;
    menu.particles.update(premium.animation.disable_all?0:dt,size.x,size.y,ps,premium.appearance.theme,{mouse.x-ox,mouse.y-oy},menu.visible,premium.performance.low_performance);
    menu.particles.draw(c.d,c.origin,premium.rgb,menu.visual_time,premium.appearance,fade);
    c.outline(0,0,1237,850);
    c.line(245,0,245,850,edge,2);c.line(1095,0,1095,850,edge,2);c.line(245,81,1095,81,edge,2);
    c.text(25,16,"Scarlet",c.accent(premium.rgb.logo),90,logo_font);
    c.text(27,124,"Visuals",muted,20);
    if(runtime.esp_preview)c.text(270,835,"ESP TEST / MOCK - TAB menu | ESC stop | F4 start/stop",muted,13);
    const char* pages[]={"Player ESP","Chest ESP","Auto Chest AFK","Settings"};
    const float nav_y[]={157,220,374,554};
    c.text(27,340,"Automation",muted,20);c.text(27,520,"Configuration",muted,20);
    for(int i=0;i<4;++i){
        const bool clicked=c.hit(std::string("nav_")+pages[i],18,nav_y[i],209,48);
        const bool selected=menu.page==i;
        if(selected||ImGui::IsItemHovered()){
            const auto secondary=menu.theme_manager.palette().secondary;
            c.rect(18,nav_y[i],192,48,selected?ImGui::ColorConvertFloat4ToU32({secondary[0],secondary[1],secondary[2],.13f}):IM_COL32(21,21,21,255),5);
        }
        c.icon(i,29,nav_y[i]+11,selected?c.accent(premium.rgb.sidebar,nav_y[i]/850):muted,26);
        c.text(74,nav_y[i]+12,pages[i],selected?white:muted,i==2?18.0f:22.0f);

        if(clicked)menu.page=i;
    }
    const float marker=menu.widgets.scalar(ImGui::GetID("sidebar_marker"),nav_y[menu.page],18);
    c.rect(191,marker+10,10,28,c.accent(premium.rgb.sidebar,marker/850),6);
    // Header is the only draggable region; controls never drag the panel.
    c.hit("panel_drag",247,0,845,80);
    if(ImGui::IsItemActive()&&ImGui::IsMouseDragging(ImGuiMouseButton_Left)){
        menu.offset.x+=ImGui::GetIO().MouseDelta.x;menu.offset.y+=ImGui::GetIO().MouseDelta.y;
    }
    c.text(261,36,"Scarlet",muted,23);c.text(338,36,">",muted,23);
    c.icon(menu.page,357,37,red,22);c.text(385,36,pages[menu.page],red,23);
    const float end_x=385+text_font->CalcTextSizeA(23*scale,2000,0,pages[menu.page]).x/scale;
    c.text(end_x+15,36,">",muted,23);c.text(end_x+40,36,menu.page==3?"Preferences":"Overview",muted,23);
    // Narrow right-hand rail, retained from the supplied visual reference.
    for(int i=0;i<3;++i){const float y=44+i*76.0f;
        const int page=i==0?0:i==1?1:3;
        if(c.hit(std::string("rail_")+std::to_string(i),1124,y,64,64))menu.page=page;
        c.d->AddRect(c.p(1124,y),c.p(1188,y+64),c.ink(edge),10*scale,0,2*scale);
        c.icon(i==0?0:i==1?1:3,1143,y+18,menu.page==page?red:muted,27);
    }
    const bool profile_hover=c.hit("profile_hover",20,708,215,95);
    (void)profile_hover;
    const float ph=c.smooth("profile_motion",ImGui::IsItemHovered()?1.0f:0.0f);
    c.rect(20,708,215,95,body,8);c.outline(20,708,215,95,.12f+ph*.7f);
    c.d->AddCircleFilled(c.p(61,752),(35+ph)*scale,c.ink(IM_COL32(30,30,30,255)),40);
    c.text(43,720,"S",c.accent(premium.rgb.logo),47,logo_font);
    c.d->PushClipRect(c.p(108,713),c.p(235,802),true);
    c.text(110,732,premium.profile.name,white,20);
    const auto profile_accent=menu.theme_manager.palette().accent;
    c.text(110,756,premium.profile.status,premium.rgb.enabled&&premium.rgb.sidebar?c.accent(true):ImGui::ColorConvertFloat4ToU32({profile_accent[0],profile_accent[1],profile_accent[2],1}),17);
    c.text(110,781,runtime.demo?"MOCK / DEMO":runtime.data_available?"Data connected":"No data source",muted,13);
    c.d->PopClipRect();
    constexpr float lx=260,rx=664,cw=398;
    auto& v=settings.visuals;auto& a=settings.automation;
    if(menu.page==0){
        if(button(c,"Overview",1108,315,114,34))menu.visual_section=0;
        if(button(c,"Hat / Hoop",1108,360,114,34))menu.visual_section=1;
        if(button(c,"Extra ESP",1108,405,114,34))menu.visual_section=2;
        if(button(c,"Visual Test",1108,450,114,34)){
            std::string error;if(ConfigManager::save(config_path,settings,error))menu.request_esp_preview=true;else logger.error(error);
        }
    }
    if(menu.page==3){
        const char* sections[]={"Appearance","RGB Effects","Particles","Animations","Performance","General"};
        for(int i=0;i<6;++i)if(button(c,sections[i],1108,315+i*52.0f,114,38,menu.settings_section==i))menu.settings_section=i;
    }
    if(menu.page==0&&menu.visual_section>0){
        draw_special_settings(c,settings);
    }else if(menu.page<=1){
        card(c,"Player ESP",0,lx,97,cw,400);
        toggle(c,"Enable Player ESP",v.players,lx+19,153,cw-50);
        toggle(c,"Box ESP 2D",v.boxes,lx+19,190,cw-50);
        toggle(c,"Skeleton ESP",v.skeleton,lx+19,227,cw-50);
        toggle(c,"Player Names",v.names,lx+19,264,cw-50);
        toggle(c,"Distance ESP",v.distance,lx+19,301,cw-50);
        toggle(c,"Health Bar",v.health,lx+19,338,cw-50);
        toggle(c,"Shield Bar",v.shield,lx+19,375,cw-50);
        toggle(c,"Snaplines",v.snaplines,lx+19,412,cw-50);
        card(c,"ESP Colors",4,lx,503,cw,322);
        slider(c,"Max Player Distance",v.max_player_distance_m,50,1000,lx+19,562,cw-50," m");
        color_row(c,"Player Color",v.player_color,lx+19,622,cw-50);
        color_row(c,"Skeleton Color",v.skeleton_color,lx+19,660,cw-50);
        color_row(c,"Chest Color",v.chest_color,lx+19,698,cw-50);
        color_row(c,"Nearest Chest Color",v.nearest_color,lx+19,736,cw-50);
        card(c,"Chest ESP",1,rx,97,cw,434);
        toggle(c,"Enable Chest ESP",v.chests,rx+20,153,cw-50);
        bool closed=true;toggle(c,"Closed Chests Only",closed,rx+20,190,cw-50,true);
        toggle(c,"Chest Markers",v.chest_marker,rx+20,227,cw-50);
        toggle(c,"Chest Distance",v.chest_distance,rx+20,264,cw-50);
        toggle(c,"Nearest Chest Highlight",v.nearest_highlight,rx+20,301,cw-50);
        toggle(c,"Chest Counter",v.chest_counter,rx+20,338,cw-50);
        slider(c,"Max Chest Distance",v.max_chest_distance_m,50,1000,rx+20,389,cw-50," m");
        c.text(rx+20,477,runtime.data_available?"Provider data available":"Waiting for authorized data",muted,17);
        card(c,"Auto Chest AFK",2,rx,536,cw,289);
        automation(c,settings,runtime,rx+20,590,cw-50);
    } else if(menu.page==2){
        card(c,"Auto Chest AFK",2,lx,97,cw,400);
        automation(c,settings,runtime,lx+20,153,cw-50);
        bool nearest=true;toggle(c,"Nearest Chest Selection",nearest,lx+20,368,cw-50,true);
        slider(c,"Search Distance",a.max_distance_m,50,1000,lx+20,415,cw-50," m");
        card(c,"Recovery",2,lx,503,cw,322);
        slider(c,"Movement Speed",a.speed_mps,.5f,20,lx+20,560,cw-50," m/s");
        slider(c,"Stuck Timeout",a.stuck_timeout_s,.25f,15,lx+20,632,cw-50," s");
        slider(c,"Verification Timeout",a.verification_timeout_s,.25f,15,lx+20,704,cw-50," s");
        card(c,"Session",4,rx,97,cw,434);
        c.text(rx+20,160,"Provider",muted,19);c.text(rx+20,191,runtime.demo?"MockGameDataProvider":"Unavailable",white,22);
        c.text(rx+20,242,"Automation State",muted,19);c.text(rx+20,274,state_name(machine.state()),red,23);
        c.text(rx+20,328,"Confirmed Openings",muted,19);c.text(rx+20,358,std::to_string(machine.completed_count()),white,28);
        const auto target=machine.target();c.text(rx+20,415,target?"Target: "+std::to_string(*target):"Target: none",muted,19);
        if(button(c,"STOP",rx+20,471,cw-40,37,true)){machine.emergency_stop(controls);a.enabled=false;}
        card(c,"Hotkeys",3,rx,536,cw,289);
        constexpr int starts[]={0x74,0x75,0x78};constexpr int stops[]={0x77,0x79,0x7A};
        key_row(c,"Start / Stop",settings.overlay.start_stop_key,starts,3,rx+20,599,cw-50);
        key_row(c,"Emergency Stop",settings.overlay.emergency_key,stops,3,rx+20,650,cw-50);
        c.text(rx+20,725,runtime.data_available?"Control sink available":"No live control sink connected",muted,17);
    } else if(menu.settings_section!=5){
        draw_premium_settings(c,settings);
    } else {
        card(c,"Settings",3,lx,97,cw,400);
        constexpr int menus[]={0x2D,0x24,0x76};key_row(c,"Menu Hotkey",settings.overlay.menu_key,menus,3,lx+20,160,cw-50);
        float fps=static_cast<float>(settings.overlay.fps_limit);slider(c,"FPS Limit",fps,15,240,lx+20,220,cw-50," FPS");settings.overlay.fps_limit=static_cast<int>(std::round(fps));
        toggle(c,"Vertical Sync",settings.overlay.vsync,lx+20,291,cw-50);
        if(button(c,"Save Config",lx+20,350,166,39)){std::string error;bool ok=save_settings(config_path,settings,error);menu.config_status=ok?"JSON configuration saved":error;logger.log(ok?LogLevel::Info:LogLevel::Error,menu.config_status);}
        if(button(c,"Load Config",lx+204,350,166,39)){std::string error;bool ok=load_settings(config_path,settings,error);if(ok)machine.emergency_stop(controls);menu.config_status=ok?"JSON loaded; automation stopped":error;logger.log(ok?LogLevel::Info:LogLevel::Error,menu.config_status);}
        c.text(lx+20,430,"Configuration format: JSON",muted,18);
        card(c,"Overlay",4,rx,97,cw,400);
        c.text(rx+20,159,"Window",muted,19);c.text(rx+20,191,runtime.attached?"Fortnite window detected":runtime.demo?"Standalone demo":"Waiting for Fortnite",white,21);
        c.text(rx+20,254,"Rendering",muted,19);c.text(rx+20,286,"Win32 / DirectX 11 / ImGui",white,21);
        c.text(rx+20,349,"Input",muted,19);c.text(rx+20,381,"Click-through when menu closes",white,20);
        c.text(rx+20,453,"Windowed / Borderless",muted,18);
        card(c,"Debug Logs",5,lx,503,802,322);
        ImGui::SetCursorScreenPos(c.p(lx+20,560));
        ImGui::BeginChild("logs",{762*scale,240*scale},false);
        ImGui::PushFont(text_font);ImGui::SetWindowFontScale(.72f*scale);
        for(const auto& entry:logger.entries())ImGui::TextWrapped("%s  %s",entry.time.c_str(),entry.message.c_str());
        if(!menu.config_status.empty())ImGui::TextWrapped("%s",menu.config_status.c_str());
        ImGui::SetWindowFontScale(1);ImGui::PopFont();ImGui::EndChild();
    }
    normalize_settings(settings);
    if(original_theme!=premium.appearance.theme){std::string error;if(!ConfigManager::save(config_path,settings,error))logger.error(error);else menu.config_status="Theme saved automatically";}
    ImGui::EndDisabled();ImGui::End();ImGui::PopStyleVar();
}
} // namespace fe
