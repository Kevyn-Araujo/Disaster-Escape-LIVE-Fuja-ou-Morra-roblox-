#pragma once
#include <deque>
#include <fstream>
#include <mutex>
#include <string>
#include <vector>
namespace fe {
enum class LogLevel { Info, Warning, Error };
struct LogEntry { std::string time; LogLevel level; std::string message; };
class Logger {
public:
    explicit Logger(const std::string& path="");
    void log(LogLevel level, const std::string& message);
    void info(const std::string& message) { log(LogLevel::Info,message); }
    void warn(const std::string& message) { log(LogLevel::Warning,message); }
    void error(const std::string& message) { log(LogLevel::Error,message); }
    std::vector<LogEntry> entries() const;
private:
    mutable std::mutex mutex_;
    std::deque<LogEntry> entries_;
    std::ofstream file_;
};
} // namespace fe
