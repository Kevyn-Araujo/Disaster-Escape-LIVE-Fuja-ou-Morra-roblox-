#include "utils/logger.hpp"
#include <chrono>
#include <ctime>
#include <iomanip>
#include <sstream>

namespace fe {
Logger::Logger(const std::string& path) {
    if (!path.empty()) {
        file_.open(path, std::ios::app);
        if (!file_) log(LogLevel::Error,"Nao foi possivel abrir o arquivo de log: "+path);
    }
}
void Logger::log(LogLevel level, const std::string& message) {
    const auto now = std::chrono::system_clock::to_time_t(std::chrono::system_clock::now());
    std::tm utc{};
#ifdef _WIN32
    gmtime_s(&utc,&now);
#else
    gmtime_r(&now,&utc);
#endif
    std::ostringstream clock;
    clock << std::put_time(&utc,"%Y-%m-%d %H:%M:%S UTC");
    std::lock_guard lock(mutex_);
    entries_.push_back({clock.str(),level,message.substr(0,4096)});
    if (entries_.size()>512) entries_.pop_front();
    if (file_) {
        const char* label = level==LogLevel::Info?"INFO":level==LogLevel::Warning?"WARN":"ERROR";
        file_ << clock.str() << " [" << label << "] " << entries_.back().message << '\n';
        file_.flush();
    }
}
std::vector<LogEntry> Logger::entries() const {
    std::lock_guard lock(mutex_);
    return {entries_.begin(),entries_.end()};
}
} // namespace fe
