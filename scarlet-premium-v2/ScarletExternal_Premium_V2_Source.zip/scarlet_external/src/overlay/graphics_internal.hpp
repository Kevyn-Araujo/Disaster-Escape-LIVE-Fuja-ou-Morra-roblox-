#pragma once
#include <d3d11.h>
#include <dxgi1_2.h>
#include <dcomp.h>
#include "utils/logger.hpp"

namespace fe::detail {
template<class T> void release(T*& object) {
    if (object) { object->Release(); object=nullptr; }
}
struct Graphics {
    ID3D11Device* device{};
    ID3D11DeviceContext* context{};
    IDXGISwapChain1* swap_chain{};
    ID3D11RenderTargetView* target{};
    IDCompositionDevice* composition{};
    IDCompositionTarget* composition_target{};
    IDCompositionVisual* composition_visual{};
    bool per_pixel_alpha{};
    ~Graphics() {
        // Detach the visual tree before releasing its swap chain and D3D device.
        if (composition_visual) composition_visual->SetContent(nullptr);
        if (composition_target) composition_target->SetRoot(nullptr);
        if (composition) composition->Commit();
        release(composition_visual);release(composition_target);release(composition);
        if (context) context->ClearState();
        release(target);release(swap_chain);release(context);release(device);
    }
    bool create_target() {
        ID3D11Texture2D* back_buffer{};
        HRESULT result=swap_chain->GetBuffer(0,__uuidof(ID3D11Texture2D),
                                             reinterpret_cast<void**>(&back_buffer));
        if (FAILED(result)) return false;
        result=device->CreateRenderTargetView(back_buffer,nullptr,&target);
        release(back_buffer);
        return SUCCEEDED(result);
    }
    bool initialize(HWND window,Logger& logger,bool composed) {
        constexpr D3D_FEATURE_LEVEL levels[]{D3D_FEATURE_LEVEL_11_0,D3D_FEATURE_LEVEL_10_0};
        D3D_FEATURE_LEVEL selected{};
        HRESULT result=D3D11CreateDevice(nullptr,D3D_DRIVER_TYPE_HARDWARE,nullptr,
            D3D11_CREATE_DEVICE_BGRA_SUPPORT,levels,2,D3D11_SDK_VERSION,&device,&selected,&context);
        if (FAILED(result)) {
            release(context);release(device);
            logger.warn("Hardware DirectX initialization failed; trying WARP software rendering.");
            result=D3D11CreateDevice(nullptr,D3D_DRIVER_TYPE_WARP,nullptr,
                D3D11_CREATE_DEVICE_BGRA_SUPPORT,levels,2,D3D11_SDK_VERSION,&device,&selected,&context);
        }
        if (FAILED(result)) return false;
        IDXGIDevice* dxgi_device{};
        IDXGIAdapter* adapter{};
        IDXGIFactory2* factory{};
        result=device->QueryInterface(__uuidof(IDXGIDevice),reinterpret_cast<void**>(&dxgi_device));
        if (SUCCEEDED(result)) result=dxgi_device->GetAdapter(&adapter);
        if (SUCCEEDED(result)) result=adapter->GetParent(__uuidof(IDXGIFactory2),reinterpret_cast<void**>(&factory));
        if (FAILED(result)) {release(factory);release(adapter);release(dxgi_device);return false;}
        RECT client{};GetClientRect(window,&client);
        DXGI_SWAP_CHAIN_DESC1 description{};
        description.Width=static_cast<UINT>(client.right>0?client.right:1);
        description.Height=static_cast<UINT>(client.bottom>0?client.bottom:1);
        description.Format=DXGI_FORMAT_B8G8R8A8_UNORM;
        description.SampleDesc.Count=1;
        description.BufferUsage=DXGI_USAGE_RENDER_TARGET_OUTPUT;
        description.BufferCount=2;
        description.Scaling=DXGI_SCALING_STRETCH;
        description.SwapEffect=DXGI_SWAP_EFFECT_FLIP_SEQUENTIAL;
        description.AlphaMode=composed?DXGI_ALPHA_MODE_PREMULTIPLIED:DXGI_ALPHA_MODE_IGNORE;
        if (composed) {
            result=factory->CreateSwapChainForComposition(device,&description,nullptr,&swap_chain);
            if (SUCCEEDED(result)) result=DCompositionCreateDevice(dxgi_device,__uuidof(IDCompositionDevice),reinterpret_cast<void**>(&composition));
            if (SUCCEEDED(result)) result=composition->CreateTargetForHwnd(window,TRUE,&composition_target);
            if (SUCCEEDED(result)) result=composition->CreateVisual(&composition_visual);
            if (SUCCEEDED(result)) result=composition_visual->SetContent(swap_chain);
            if (SUCCEEDED(result)) result=composition_target->SetRoot(composition_visual);
            if (SUCCEEDED(result)) result=composition->Commit();
            per_pixel_alpha=SUCCEEDED(result);
        } else {
            result=factory->CreateSwapChainForHwnd(device,window,&description,nullptr,nullptr,&swap_chain);
        }
        // The app never changes the game's swap chain or exclusive-fullscreen state.
        if (SUCCEEDED(result)) factory->MakeWindowAssociation(window,DXGI_MWA_NO_ALT_ENTER);
        release(factory);release(adapter);release(dxgi_device);
        if (FAILED(result)) {
            logger.error("DXGI/DirectComposition initialization failed, HRESULT="+std::to_string(static_cast<unsigned long>(result)));
            return false;
        }
        if (composed) logger.info("DirectComposition: BGRA flip swap chain, premultiplied per-pixel alpha; no color key or global text opacity.");
        return create_target();
    }
    bool resize(UINT width,UINT height) {
        if (!width||!height) return true;
        context->OMSetRenderTargets(0,nullptr,nullptr);
        release(target);
        if (FAILED(swap_chain->ResizeBuffers(0,width,height,DXGI_FORMAT_UNKNOWN,0))) return false;
        return create_target();
    }
};
}
