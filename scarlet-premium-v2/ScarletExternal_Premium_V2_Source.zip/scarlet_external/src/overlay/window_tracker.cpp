#include "overlay/window_tracker.hpp"
#include <cwchar>
namespace fe {
bool WindowTracker::matches(HWND window) const {
    if(!IsWindowVisible(window)||GetWindow(window,GW_OWNER))return false;
    DWORD pid{};GetWindowThreadProcessId(window,&pid);
    if(!pid)return false;
    HANDLE process=OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION,FALSE,pid);
    if(!process)return false;
    wchar_t path[32768]{};DWORD size=32768;
    const BOOL result=QueryFullProcessImageNameW(process,0,path,&size);
    CloseHandle(process);
    if(!result)return false;
    const wchar_t* name=std::wcsrchr(path,L'\\');name=name?name+1:path;
    return _wcsicmp(name,executable_.c_str())==0;
}
BOOL CALLBACK WindowTracker::enumerate(HWND window,LPARAM data) {
    auto& self=*reinterpret_cast<WindowTracker*>(data);
    if(self.matches(window)) {self.window_=window;GetWindowThreadProcessId(window,&self.owner_pid_);return FALSE;}
    return TRUE;
}
TrackedWindow WindowTracker::poll() {
    DWORD pid{};
    if(window_)GetWindowThreadProcessId(window_,&pid);
    if(window_&&(!IsWindow(window_)||!IsWindowVisible(window_)||pid!=owner_pid_))window_=nullptr;
    const auto now=GetTickCount64();
    if(!window_&&(last_search_==0||now-last_search_>=1000)) {
        EnumWindows(enumerate,reinterpret_cast<LPARAM>(this));last_search_=now;
    }
    TrackedWindow tracked;tracked.handle=window_;
    if(!window_)return tracked;
    tracked.minimized=IsIconic(window_)!=FALSE;
    tracked.visible=IsWindowVisible(window_)&&!tracked.minimized;
    RECT client{};POINT origin{};
    if(!GetClientRect(window_,&client)||!ClientToScreen(window_,&origin))tracked.visible=false;
    tracked.client={origin.x,origin.y,origin.x+client.right,origin.y+client.bottom};
    if(client.right<=0||client.bottom<=0)tracked.visible=false;
    return tracked;
}
}
