#pragma once
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#include <string>
#include <utility>
namespace fe {
struct TrackedWindow {
    HWND handle{};
    RECT client{};
    bool visible{},minimized{};
};
class WindowTracker {
public:
    explicit WindowTracker(std::wstring executable=L"FortniteClient-Win64-Shipping.exe") : executable_(std::move(executable)) {}
    TrackedWindow poll();
private:
    static BOOL CALLBACK enumerate(HWND,LPARAM);
    bool matches(HWND) const;
    std::wstring executable_;
    HWND window_{};
    DWORD owner_pid_{};
    ULONGLONG last_search_{};
};
}
