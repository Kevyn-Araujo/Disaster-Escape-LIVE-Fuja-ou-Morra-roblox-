#include "overlay/dx11_overlay.hpp"
#include "overlay/window_tracker.hpp"
#include "automation/auto_chest.hpp"
#include "data/game_data_provider.hpp"
#include "data/mock_game_data_provider.hpp"
#include "config/settings.hpp"
#include "esp/esp_renderer.hpp"
#include "ui/menu.hpp"
#include "utils/logger.hpp"
#include <d3d11.h>
#include <dxgi.h>
#include <dwmapi.h>
#include <shellapi.h>
#include "imgui.h"
#include "backends/imgui_impl_dx11.h"
#include "backends/imgui_impl_win32.h"
#include <algorithm>
#include <chrono>
#include <thread>
#include "overlay/graphics_internal.hpp"
extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND,UINT,WPARAM,LPARAM);
namespace fe {
namespace {
constexpr wchar_t class_name[]=L"ScarletExternalOverlay";
constexpr UINT tray_message=WM_APP+11;
struct WindowState {
    UINT width{1280},height{850};bool resize{},toggle{},stop{},start{},quit{},interactive{};
    int keys[3]{0x2D,0x77,0x75};bool registered[3]{};
};
LRESULT CALLBACK window_proc(HWND window,UINT message,WPARAM wp,LPARAM lp) {
    auto* state=reinterpret_cast<WindowState*>(GetWindowLongPtrW(window,GWLP_USERDATA));
    if(message==WM_NCCREATE){state=static_cast<WindowState*>(reinterpret_cast<CREATESTRUCTW*>(lp)->lpCreateParams);SetWindowLongPtrW(window,GWLP_USERDATA,reinterpret_cast<LONG_PTR>(state));}
    if(state) {
        // Closed menus must not retain activation or hit-test ownership during their fade.
        if(message==WM_NCHITTEST&&!state->interactive)return HTTRANSPARENT;
        if(message==WM_MOUSEACTIVATE&&!state->interactive)return MA_NOACTIVATE;
        auto action=[&](int id){if(id==1)state->toggle=true;if(id==2)state->stop=true;if(id==3)state->start=true;};
        if(message==WM_HOTKEY){action(static_cast<int>(wp));return 0;}
        if(message==WM_KEYDOWN&&(lp&(1LL<<30))==0)
            for(int i=0;i<3;++i)if(!state->registered[i]&&wp==static_cast<WPARAM>(state->keys[i]))action(i+1);
        if(message==tray_message){
            if(lp==WM_LBUTTONUP)state->toggle=true;
            if(lp==WM_RBUTTONUP){
                POINT pos{};GetCursorPos(&pos);HMENU menu=CreatePopupMenu();
                if(menu){AppendMenuW(menu,MF_STRING,1,L"Mostrar / ocultar Scarlet");AppendMenuW(menu,MF_STRING,2,L"Sair");
                    SetForegroundWindow(window);const UINT choice=TrackPopupMenu(menu,TPM_RETURNCMD|TPM_NONOTIFY,pos.x,pos.y,0,window,nullptr);
                    DestroyMenu(menu);if(choice==1)state->toggle=true;if(choice==2)state->quit=true;PostMessageW(window,WM_NULL,0,0);}
            }return 0;
        }
    }
    if(ImGui::GetCurrentContext()&&ImGui_ImplWin32_WndProcHandler(window,message,wp,lp))return 1;
    switch(message){
    case WM_SIZE:
        if(state&&wp!=SIZE_MINIMIZED&&LOWORD(lp)&&HIWORD(lp)){
            const UINT width=LOWORD(lp),height=HIWORD(lp);
            if(state->width!=width||state->height!=height){state->width=width;state->height=height;state->resize=true;}
        }
        return 0;
    case WM_ERASEBKGND:return 1;
    case WM_SYSCOMMAND:if((wp&0xFFF0)==SC_KEYMENU)return 0;break;
    case WM_CLOSE:if(state)state->quit=true;return 0;
    case WM_DESTROY:PostQuitMessage(0);return 0;
    }
    return DefWindowProcW(window,message,wp,lp);
}
struct NativeWindow {
    HINSTANCE instance{GetModuleHandleW(nullptr)};HWND handle{};bool registered{};NOTIFYICONDATAW tray{};
    ~NativeWindow(){if(tray.hWnd)Shell_NotifyIconW(NIM_DELETE,&tray);if(handle){for(int i=1;i<=3;++i)UnregisterHotKey(handle,i);if(IsWindow(handle))DestroyWindow(handle);}if(registered)UnregisterClassW(class_name,instance);}
    bool create(WindowState& state,bool demo){
        WNDCLASSEXW wc{};wc.cbSize=sizeof(wc);wc.lpfnWndProc=window_proc;wc.hInstance=instance;
        wc.hCursor=LoadCursorW(nullptr,MAKEINTRESOURCEW(32512));wc.lpszClassName=class_name;
        registered=RegisterClassExW(&wc)!=0;if(!registered)return false;
        const DWORD style=demo?WS_OVERLAPPEDWINDOW:WS_POPUP;
        const DWORD ex=demo?0:WS_EX_NOREDIRECTIONBITMAP|WS_EX_TOOLWINDOW|WS_EX_TOPMOST|WS_EX_TRANSPARENT|WS_EX_NOACTIVATE;
        handle=CreateWindowExW(ex,class_name,demo?L"Scarlet External - DEMO / MOCK":L"Scarlet External",style,
            CW_USEDEFAULT,CW_USEDEFAULT,state.width,state.height,nullptr,nullptr,instance,&state);
        if(!handle)return false;
        tray.cbSize=sizeof(tray);tray.hWnd=handle;tray.uID=1;tray.uFlags=NIF_MESSAGE|NIF_ICON|NIF_TIP;
        tray.uCallbackMessage=tray_message;tray.hIcon=LoadIconW(nullptr,MAKEINTRESOURCEW(32512));
        lstrcpynW(tray.szTip,L"Scarlet External - INSERT menu | F8 stop",128);
        if(!Shell_NotifyIconW(NIM_ADD,&tray))tray.hWnd=nullptr;
        return true;
    }
};
struct ImGuiOwner {
    bool win32{},dx11{};
    ~ImGuiOwner(){if(dx11)ImGui_ImplDX11_Shutdown();if(win32)ImGui_ImplWin32_Shutdown();if(ImGui::GetCurrentContext())ImGui::DestroyContext();}
    bool initialize(HWND window,detail::Graphics& graphics,const std::filesystem::path& assets,Logger& logger){
        IMGUI_CHECKVERSION();ImGui::CreateContext();auto& io=ImGui::GetIO();io.IniFilename=nullptr;
        if(!load_scarlet_fonts(assets))logger.warn("Fonte Scarlet ausente; usando fallback. Preserve assets/fonts junto ao executavel.");
        apply_scarlet_style();win32=ImGui_ImplWin32_Init(window);if(!win32)return false;
        dx11=ImGui_ImplDX11_Init(graphics.device,graphics.context);return dx11;
    }
};
void register_hotkeys(HWND window,WindowState& state,const OverlaySettings& settings,Logger& logger,bool initial=false){
    const int wanted[]={settings.menu_key,settings.emergency_key,settings.start_stop_key};
    // Release all changed bindings before registering so swapping keys is deterministic.
    for(int i=0;i<3;++i)if(initial||state.keys[i]!=wanted[i]){UnregisterHotKey(window,i+1);state.registered[i]=false;}
    for(int i=0;i<3;++i)if(initial||state.keys[i]!=wanted[i]){
        state.keys[i]=wanted[i];state.registered[i]=RegisterHotKey(window,i+1,MOD_NOREPEAT,wanted[i])!=FALSE;
        if(!state.registered[i])logger.warn("Atalho global indisponivel: VK "+std::to_string(wanted[i])+". Use o menu/tray ou altere a configuracao.");
    }
}
void mouse_mode(HWND window,bool interactive,bool demo){
    auto* state=reinterpret_cast<WindowState*>(GetWindowLongPtrW(window,GWLP_USERDATA));
    if(state)state->interactive=interactive||demo;
    LONG_PTR style=GetWindowLongPtrW(window,GWL_EXSTYLE);
    if(interactive||demo)style&=~static_cast<LONG_PTR>(WS_EX_TRANSPARENT|WS_EX_NOACTIVATE|WS_EX_LAYERED);
    else style|=WS_EX_TRANSPARENT|WS_EX_NOACTIVATE;
    if(!demo){
        style|=WS_EX_NOREDIRECTIONBITMAP|WS_EX_TOOLWINDOW;
        // WS_EX_TRANSPARENT on a layered window passes mouse events through even
        // to windows owned by another process. Alpha=255 does not fade text;
        // the DirectComposition visual supplies its own per-pixel alpha.
        if(!interactive)style|=WS_EX_LAYERED;
    }
    SetWindowLongPtrW(window,GWL_EXSTYLE,style);
    if(!demo&&!interactive)SetLayeredWindowAttributes(window,0,255,LWA_ALPHA);
    SetWindowPos(window,demo?HWND_NOTOPMOST:HWND_TOPMOST,0,0,0,0,SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE|SWP_FRAMECHANGED);
}
bool same_rect(RECT a,RECT b){return a.left==b.left&&a.top==b.top&&a.right==b.right&&a.bottom==b.bottom;}
}
int Dx11Overlay::run(Settings& settings,IGameDataProvider& provider,IControlSink& controls,
                    AutoChestMachine& machine,Logger& logger,const std::filesystem::path& config_path,
                    const OverlayOptions& options){
    WindowState state;NativeWindow window;
    if(!window.create(state,options.demo)){logger.error("Falha ao criar janela Win32.");return 1;}
    if(options.esp_preview){
        // A preview may coexist with the original app. It must never steal or
        // compete for the main instance's global INSERT/F6/F8 registrations.
        state.keys[0]=VK_TAB;state.keys[1]=VK_ESCAPE;state.keys[2]=VK_F4;
        SetWindowTextW(window.handle,L"Scarlet ESP Preview - DEMO | TAB menu | ESC stop | F4 auto");
        if(window.tray.hWnd){
            lstrcpynW(window.tray.szTip,L"Scarlet ESP DEMO - TAB menu | ESC stop | F4 auto",128);
            Shell_NotifyIconW(NIM_MODIFY,&window.tray);
        }
    }
    detail::Graphics graphics;
    if(!graphics.initialize(window.handle,logger,!options.demo)){logger.error("Falha DirectX 11, inclusive WARP.");return 2;}
    state.resize=false; // Initialization already used the current client dimensions.
    ImGuiOwner imgui;
    if(!imgui.initialize(window.handle,graphics,options.assets,logger)){logger.error("Falha nos backends ImGui.");return 3;}
    if(!options.esp_preview)register_hotkeys(window.handle,state,settings.overlay,logger,true);
    WindowTracker tracker;MenuState menu;menu.visible=options.demo&&!options.esp_preview;
    bool interactive=!menu.visible,shown=false;RECT last_rect{};
    HWND last_target{};bool previously_running=false;
    auto previous=std::chrono::steady_clock::now();
    if(options.demo)ShowWindow(window.handle,SW_SHOW);
    logger.info(options.demo?"Modo DEMO explicitamente selecionado; dados simulados.":"Aguardando a janela de Fortnite; nenhum provider de telemetria real esta conectado.");
    int result=0;
    while(!state.quit){
        const auto begin=std::chrono::steady_clock::now();
        MSG message{};while(PeekMessageW(&message,nullptr,0,0,PM_REMOVE)){
            if(message.message==WM_QUIT){state.quit=true;break;}TranslateMessage(&message);DispatchMessageW(&message);
        }
        if(state.quit)break;
        const auto target=options.demo?TrackedWindow{}:tracker.poll();
        if(target.handle!=last_target){last_target=target.handle;logger.info(last_target?"Janela Fortnite detectada; posicionamento por area cliente.":"Janela Fortnite indisponivel; overlay oculto.");}
        HWND foreground=GetForegroundWindow();
        bool visible=options.demo?!IsIconic(window.handle):(target.visible&&(foreground==target.handle||foreground==window.handle));
        if(!options.demo&&target.visible&&!same_rect(last_rect,target.client)){
            const auto& r=target.client;SetWindowPos(window.handle,HWND_TOPMOST,r.left,r.top,r.right-r.left,r.bottom-r.top,SWP_NOACTIVATE);
            last_rect=r;
        }
        if(state.toggle){menu.visible=!menu.visible;state.toggle=false;
            mouse_mode(window.handle,menu.visible,options.demo);interactive=menu.visible;
            if(options.demo&&menu.visible&&!visible){ShowWindow(window.handle,SW_RESTORE);visible=true;}
            if(menu.visible&&visible){ShowWindow(window.handle,SW_SHOWNOACTIVATE);SetForegroundWindow(window.handle);SetFocus(window.handle);}
            else if(!menu.visible&&!options.demo&&foreground==window.handle&&target.handle)SetForegroundWindow(target.handle);
        }
        if(state.stop){machine.emergency_stop(controls);settings.automation.enabled=false;state.stop=false;}
        if(!options.esp_preview)register_hotkeys(window.handle,state,settings.overlay,logger);
        if(!options.esp_preview&&!state.registered[0])menu.visible=true;
        if(interactive!=menu.visible){mouse_mode(window.handle,menu.visible,options.demo);interactive=menu.visible;}
        const double dt=std::clamp(std::chrono::duration<double>(begin-previous).count(),.001,.1);previous=begin;
        if(auto* mock=dynamic_cast<MockGameDataProvider*>(&provider))mock->set_aspect_ratio(static_cast<float>(state.width)/std::max(1u,state.height));
        provider.tick(dt);auto snapshot=provider.snapshot();
        const bool data=snapshot.connected&&snapshot.local_position&&finite(*snapshot.local_position);
        if(state.start){
            state.start=false;
            if(data&&(options.demo||visible))settings.automation.enabled=!settings.automation.enabled;
            else {settings.automation.enabled=false;logger.warn("Auto Chest indisponivel: provider autorizado ou janela ativa ausente.");}
        }
        if(!data||(!options.demo&&!visible))settings.automation.enabled=false;
        machine.update(snapshot,controls,settings.automation,dt);
        snapshot=provider.snapshot();
        if(previously_running&&!settings.automation.enabled)controls.stop();
        previously_running=settings.automation.enabled;
        const bool display_overlay=visible&&(menu_rendering(menu)||data);
        if(display_overlay!=shown){ShowWindow(window.handle,display_overlay?SW_SHOWNOACTIVATE:SW_HIDE);shown=display_overlay;}
        if(!display_overlay){controls.stop();std::this_thread::sleep_for(std::chrono::milliseconds(40));continue;}
        if(state.resize){if(!graphics.resize(state.width,state.height)){logger.error("Falha ao redimensionar swapchain.");result=4;break;}state.resize=false;}
        ImGui_ImplDX11_NewFrame();ImGui_ImplWin32_NewFrame();ImGui::NewFrame();
        if(options.esp_preview&&options.demo){
            for(const auto& player:snapshot.players)if(player.position&&player.head&&finite(*player.position)&&finite(*player.head)){
                snapshot.camera=make_camera(*player.position+Vec3{0,1.1f,-4},*player.position+Vec3{0,1.0f,0},static_cast<float>(state.width)/std::max(1u,state.height));
                break;
            }
        }
        if(data)draw_scene(snapshot,settings.visuals,machine.route(),static_cast<float>(state.width),static_cast<float>(state.height),options.demo,&settings.premium,ImGui::GetTime());
        RuntimeStatus status;status.demo=options.demo;status.esp_preview=options.esp_preview;status.attached=target.handle!=nullptr;status.data_available=data;
        status.provider_name=options.demo?"MockGameDataProvider":"Sem provider autorizado";status.snapshot=std::move(snapshot);
        draw_menu(menu,settings,controls,machine,logger,config_path,status);
        if(menu.request_esp_preview){
            menu.request_esp_preview=false;
            if(options.esp_preview){menu.visible=false;}
            else {
                std::wstring executable(32768,L'\0');
                const DWORD count=GetModuleFileNameW(nullptr,executable.data(),static_cast<DWORD>(executable.size()));
                if(count==0||count>=executable.size())logger.error("Nao foi possivel localizar o executavel para abrir o preview ESP.");
                else {
                    executable.resize(count);
                    const std::wstring arguments=L"--esp-preview --config \""+config_path.wstring()+L"\"";
                    const HINSTANCE launched=ShellExecuteW(nullptr,L"open",executable.c_str(),arguments.c_str(),nullptr,SW_SHOWNORMAL);
                    if(reinterpret_cast<INT_PTR>(launched)<=32)logger.error("Nao foi possivel abrir a janela independente de preview ESP.");
                    else logger.info("Preview ESP aberto em modo DEMO independente.");
                }
            }
        }
        ImGui::Render();const float clear_live[]{0,0,0,0},clear_demo[]{.02f,.02f,.02f,1};
        graphics.context->OMSetRenderTargets(1,&graphics.target,nullptr);
        graphics.context->ClearRenderTargetView(graphics.target,options.demo?clear_demo:clear_live);
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
        const HRESULT presented=graphics.swap_chain->Present(settings.overlay.vsync?1:0,0);
        if(FAILED(presented)){logger.error("Falha DirectX Present.");result=5;break;}
        const auto duration=std::chrono::duration<double>(1.0/std::clamp(settings.overlay.fps_limit,15,240));
        std::this_thread::sleep_until(begin+std::chrono::duration_cast<std::chrono::steady_clock::duration>(duration));
    }
    controls.stop();logger.info("Scarlet encerrado; controles liberados.");return result;
}
}
