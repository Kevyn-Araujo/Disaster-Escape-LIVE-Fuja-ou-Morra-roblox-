#include "esp/EspVisualEffects.h"
#include "esp/filters.hpp"
#include "imgui.h"
#include <algorithm>
#include <cmath>
#include <limits>

namespace fe {
namespace {
constexpr float tau=6.28318530718f;
const std::array<Vec2,esp_ring_segments>& unit_circle() {
    // One initialization; no per-player trigonometric sampling or dynamic containers.
    static const auto points=[] {
        std::array<Vec2,esp_ring_segments> result{};
        for(std::size_t i=0;i<result.size();++i) {
            const float angle=tau*static_cast<float>(i)/static_cast<float>(result.size());
            result[i]={std::cos(angle),std::sin(angle)};
        }
        return result;
    }();
    return points;
}
float safe(float value,float fallback) {return std::isfinite(value)?value:fallback;}
Color rgba(Color value,float opacity=1) {
    for(float& channel:value)channel=std::clamp(safe(channel,1),0.0f,1.0f);
    value[3]*=std::clamp(safe(opacity,0),0.0f,1.0f);return value;
}
ImU32 tint(const Color& value,float opacity=1) {
    const auto c=rgba(value,opacity);
    return ImGui::ColorConvertFloat4ToU32({c[0],c[1],c[2],c[3]});
}
std::optional<ImVec2> project(Vec3 value,const GameSnapshot& snapshot,float width,float height) {
    const auto p=world_to_screen(value,snapshot.camera,width,height);
    return p?std::optional<ImVec2>{{p->x,p->y}}:std::nullopt;
}
bool eligible(const Player& player,const GameSnapshot& snapshot,const VisualSettings& settings) {
    if(!player.available||!player.position||!finite(*player.position))return false;
    if(settings.team_check&&snapshot.local_team&&player.team&&*snapshot.local_team==*player.team)return false;
    const float meters=distance(*player.position,*snapshot.local_position);
    return std::isfinite(meters)&&meters<=clamped_render_distance(settings.max_player_distance_m);
}
struct ScreenBox {float left{},top{},right{},bottom{};};
std::optional<ScreenBox> screen_box(const Player& player,const GameSnapshot& snapshot,float width,float height) {
    if(player.bounds) {
        ScreenBox box{std::numeric_limits<float>::max(),std::numeric_limits<float>::max(),
                      std::numeric_limits<float>::lowest(),std::numeric_limits<float>::lowest()};
        for(const auto corner:*player.bounds) {
            if(!finite(corner))return std::nullopt;
            const auto p=project(corner,snapshot,width,height);
            if(!p)return std::nullopt;
            box.left=std::min(box.left,p->x);box.top=std::min(box.top,p->y);
            box.right=std::max(box.right,p->x);box.bottom=std::max(box.bottom,p->y);
        }
        if(box.right-box.left>=1&&box.bottom-box.top>=1)return box;
        return std::nullopt;
    }
    if(!player.head||!finite(*player.head))return std::nullopt;
    const auto foot=project(*player.position,snapshot,width,height),head=project(*player.head,snapshot,width,height);
    if(!foot||!head)return std::nullopt;
    const float top=std::min(foot->y,head->y),bottom=std::max(foot->y,head->y),center=(foot->x+head->x)*.5f;
    const float half=(bottom-top)*.23f;
    if(bottom-top<3)return std::nullopt;
    // Matches the pre-existing projected 2D box convention; no world bounds are synthesized.
    return ScreenBox{center-half,top,center+half,bottom};
}
}

std::optional<ConeGeometry> make_cone(Vec3 head,float radius,float height) {
    if(!finite(head)||!std::isfinite(radius)||!std::isfinite(height)||radius<=0||height<=0||radius>5||height>5)return std::nullopt;
    ConeGeometry geometry;geometry.apex=head+Vec3{0,height,0};
    if(!finite(geometry.apex))return std::nullopt;
    const auto& unit=unit_circle();
    for(std::size_t i=0;i<unit.size();++i) {
        geometry.rim[i]=head+Vec3{unit[i].x*radius,0,unit[i].y*radius};
        if(!finite(geometry.rim[i]))return std::nullopt;
    }
    return geometry;
}
std::optional<std::array<Vec3,esp_ring_segments>> make_hoop(
    Vec3 waist,float radius,float height_offset,double time,float speed,int direction) {
    if(!finite(waist)||!std::isfinite(radius)||radius<=0||radius>5||!std::isfinite(height_offset)
       ||std::abs(height_offset)>5||!std::isfinite(time)||!std::isfinite(speed)||std::abs(speed)>20
       ||(direction!=1&&direction!=-1))return std::nullopt;
    const double angular_speed=static_cast<double>(speed)*direction;
    const double phase=angular_speed==0?0:std::fmod(time,static_cast<double>(tau)/std::abs(angular_speed))*angular_speed;
    if(!std::isfinite(phase))return std::nullopt;
    const float yaw=static_cast<float>(phase),tilt=.16f*std::sin(yaw);
    const float sy=std::sin(yaw),cy=std::cos(yaw),st=std::sin(tilt),ct=std::cos(tilt);
    const Vec3 u{cy,0,sy},v{-sy*ct,st,cy*ct},center=waist+Vec3{0,height_offset,0};
    std::array<Vec3,esp_ring_segments> ring{};
    const auto& unit=unit_circle();
    for(std::size_t i=0;i<ring.size();++i) {
        ring[i]=center+u*(unit[i].x*radius)+v*(unit[i].y*radius);
        if(!finite(ring[i]))return std::nullopt;
    }
    return ring;
}
Color player_effect_color(const Color& base,const PremiumSettings& premium,double time,float phase) {
    if(!std::isfinite(time))return rgba(base);
    const double speed=std::clamp(safe(premium.rgb.speed,.15f),0.0f,3.0f);
    const double t=premium.animation.disable_all?0:time;
    double hue=speed>0?std::fmod(std::fmod(t,1.0/speed)*speed+safe(phase,0),1.0):std::fmod(safe(phase,0),1.0);if(hue<0)hue+=1;
    Color value{};ImGui::ColorConvertHSVtoRGB(static_cast<float>(hue),.78f,
        std::clamp(safe(premium.rgb.brightness,.9f),0.0f,1.0f),value[0],value[1],value[2]);
    value[3]=rgba(base)[3];return value;
}
Color distance_effect_color(float meters,float maximum) {
    if(!std::isfinite(meters)||!std::isfinite(maximum)||maximum<=0)return {1,1,1,1};
    const float t=std::clamp(meters/maximum,0.0f,1.0f);
    return {.2f+.8f*t,1.0f-.8f*t,.45f-.3f*t,1};
}
SpecialEspStats render_special_esp(const GameSnapshot& snapshot,const VisualSettings& visuals,const PremiumSettings& premium,
                                   float width,float height,double time) {
    SpecialEspStats stats;
    if(!ImGui::GetCurrentContext()||!snapshot.connected||!snapshot.camera.valid||!visuals.enabled||!visuals.players
       ||!snapshot.local_position||!finite(*snapshot.local_position)||!std::isfinite(width)||!std::isfinite(height)
       ||width<=0||height<=0||!std::isfinite(time))return stats;
    const auto& settings=premium.esp;
    const bool light=premium.performance.low_performance||premium.performance.disable_heavy_effects;
    const std::size_t stride=light?2:1;
    const double animated_time=premium.animation.disable_all?0:time;
    auto* draw=ImGui::GetBackgroundDrawList();
    for(const auto& player:snapshot.players) {
        if(!eligible(player,snapshot,visuals))continue;
        Color base=player.visible&&!*player.visible?visuals.hidden_color:visuals.player_color;
        if(settings.distance_gradient)base=distance_effect_color(distance(*snapshot.local_position,*player.position),clamped_render_distance(visuals.max_player_distance_m));
        if(settings.hat&&player.head&&finite(*player.head)) {
            const auto cone=make_cone(*player.head,settings.hat_radius,settings.hat_height);
            if(cone) {
                const auto apex=project(cone->apex,snapshot,width,height);
                bool drawn=false;
                for(std::size_t i=0;i<esp_ring_segments;i+=stride) {
                    const auto j=(i+stride)%esp_ring_segments;
                    const auto a=project(cone->rim[i],snapshot,width,height),b=project(cone->rim[j],snapshot,width,height);
                    const auto color=settings.hat_rainbow?player_effect_color(settings.hat_color,premium,animated_time,static_cast<float>(i)/esp_ring_segments):settings.hat_color;
                    const float thickness=std::clamp(safe(settings.hat_thickness,1.5f),.5f,8.0f);
                    if(a&&b){draw->AddLine(*a,*b,tint(color),thickness);drawn=true;}
                    if(apex&&a) {
                        if(settings.hat_filled&&!light&&b)draw->AddTriangleFilled(*apex,*a,*b,tint(color,.18f));
                        if(!settings.hat_filled||i%(stride*4)==0)draw->AddLine(*apex,*a,tint(color,.65f),thickness);
                        drawn=true;
                    }
                }
                if(drawn)++stats.hats;
            }
        }
        if(settings.hoop&&player.waist&&finite(*player.waist)) {
            const auto ring=make_hoop(*player.waist,settings.hoop_radius,settings.hoop_height_offset,animated_time,
                                      settings.hoop_speed,settings.hoop_direction);
            if(ring) {
                bool drawn=false;
                for(std::size_t i=0;i<esp_ring_segments;i+=stride) {
                    const auto a=project((*ring)[i],snapshot,width,height),b=project((*ring)[(i+stride)%esp_ring_segments],snapshot,width,height);
                    if(!a||!b)continue;
                    const float phase=static_cast<float>(i)/esp_ring_segments;
                    const auto color=settings.hoop_rainbow?player_effect_color(settings.hoop_color,premium,animated_time,phase):settings.hoop_color;
                    draw->AddLine(*a,*b,tint(color),std::clamp(safe(settings.hoop_thickness,1.5f),.5f,8.0f));drawn=true;
                }
                if(drawn)++stats.hoops;
            }
        }
        if(settings.box_3d&&player.bounds) {
            std::array<std::optional<ImVec2>,8> points{};bool valid=true;
            for(std::size_t i=0;i<points.size();++i){if(!finite((*player.bounds)[i])){valid=false;break;}points[i]=project((*player.bounds)[i],snapshot,width,height);}
            if(valid) {
                bool drawn=false;
                constexpr int edges[12][2]={{0,1},{1,2},{2,3},{3,0},{4,5},{5,6},{6,7},{7,4},{0,4},{1,5},{2,6},{3,7}};
                for(const auto& edge:edges)if(points[edge[0]]&&points[edge[1]]){draw->AddLine(*points[edge[0]],*points[edge[1]],tint(base),1.5f);drawn=true;}
                if(drawn)++stats.boxes3d;
            }
        }
        if(settings.corner_box||settings.gradient_box||settings.outline||(settings.glow_outline&&!light)) {
            const auto box=screen_box(player,snapshot,width,height);
            if(!box)continue;
            const ImVec2 top{box->left,box->top},bottom{box->right,box->bottom};
            if(settings.glow_outline&&!light)for(int layer=3;layer>=1;--layer)
                draw->AddRect(top,bottom,tint(base,.08f*static_cast<float>(4-layer)),2,0,static_cast<float>(layer)*2+1);
            if(settings.gradient_box) {
                const auto secondary=rgba(premium.appearance.accent);
                draw->AddRectFilledMultiColor(top,bottom,tint(base,.17f),tint(base,.17f),tint(secondary,.05f),tint(secondary,.05f));
            }
            if(settings.outline){draw->AddRect({top.x-1,top.y-1},{bottom.x+1,bottom.y+1},IM_COL32(0,0,0,230),0,0,3);draw->AddRect(top,bottom,tint(base),0,0,1);}
            if(settings.corner_box) {
                const float x=(bottom.x-top.x)*.26f,y=(bottom.y-top.y)*.20f;
                const ImU32 color=tint(base);
                draw->AddLine(top,{top.x+x,top.y},color,1.5f);draw->AddLine(top,{top.x,top.y+y},color,1.5f);
                draw->AddLine({bottom.x,top.y},{bottom.x-x,top.y},color,1.5f);draw->AddLine({bottom.x,top.y},{bottom.x,top.y+y},color,1.5f);
                draw->AddLine({top.x,bottom.y},{top.x+x,bottom.y},color,1.5f);draw->AddLine({top.x,bottom.y},{top.x,bottom.y-y},color,1.5f);
                draw->AddLine(bottom,{bottom.x-x,bottom.y},color,1.5f);draw->AddLine(bottom,{bottom.x,bottom.y-y},color,1.5f);
            }
            ++stats.screen_boxes;
        }
    }
    return stats;
}
}
