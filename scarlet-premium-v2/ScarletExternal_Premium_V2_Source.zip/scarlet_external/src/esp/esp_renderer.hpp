#pragma once
#include "core/types.hpp"
#include "config/settings.hpp"
namespace fe {
class PlayerESP { public: void render(const GameSnapshot&,const VisualSettings&,float,float,const PremiumSettings* premium=nullptr,double time=0) const; };
class ChestESP { public: void render(const GameSnapshot&,const VisualSettings&,float,float) const; };
void draw_scene(const GameSnapshot&,const VisualSettings&,const std::vector<Vec3>&,float,float,bool demo=false,const PremiumSettings* premium=nullptr,double time=0);
}
