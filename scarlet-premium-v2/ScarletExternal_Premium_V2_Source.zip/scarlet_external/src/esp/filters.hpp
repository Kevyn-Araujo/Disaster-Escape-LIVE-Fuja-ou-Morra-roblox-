#pragma once
#include "core/types.hpp"
namespace fe {
struct ChestCandidate { Chest chest; float distance_m{}; };
float clamped_render_distance(float requested);
std::vector<ChestCandidate> closed_chests(const GameSnapshot& snapshot, float max_distance_m);
std::vector<Player> visible_players(const GameSnapshot& snapshot, float max_distance_m, bool team_check);
} // namespace fe
