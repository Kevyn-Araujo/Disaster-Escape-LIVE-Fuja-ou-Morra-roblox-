#pragma once
#include "core/types.hpp"
#include "config/settings.hpp"
#include <array>
#include <optional>
namespace fe {
inline constexpr std::size_t esp_ring_segments=32;
struct ConeGeometry { Vec3 apex; std::array<Vec3,esp_ring_segments> rim; };
struct SpecialEspStats { std::size_t hats{},hoops{},boxes3d{},screen_boxes{}; };
// All anchors are observed provider fields. These functions never infer missing bones.
std::optional<ConeGeometry> make_cone(Vec3 head,float radius,float height);
std::optional<std::array<Vec3,esp_ring_segments>> make_hoop(
    Vec3 waist,float radius,float height_offset,double time,float speed,int direction);
Color player_effect_color(const Color& base,const PremiumSettings& premium,double time,float phase=0);
Color distance_effect_color(float meters,float maximum);
SpecialEspStats render_special_esp(const GameSnapshot&,const VisualSettings&,const PremiumSettings&,
                                   float width,float height,double time);
}
