#include "esp/filters.hpp"
#include <algorithm>
#include <cmath>

namespace fe {
float clamped_render_distance(float requested) {
    return std::isfinite(requested) ? std::clamp(requested, 50.0f, 1000.0f) : 1000.0f;
}

std::vector<ChestCandidate> closed_chests(const GameSnapshot& snapshot, float max_distance_m) {
    std::vector<ChestCandidate> result;
    if (!snapshot.connected || !snapshot.local_position || !finite(*snapshot.local_position))
        return result;
    const float limit = clamped_render_distance(max_distance_m);
    for (const auto& chest : snapshot.chests) {
        if (!chest.available || chest.state != ChestState::Closed || !chest.position || !finite(*chest.position))
            continue;
        const float meters = distance(*snapshot.local_position, *chest.position);
        if (std::isfinite(meters) && meters <= limit)
            result.push_back({chest, meters});
    }
    std::sort(result.begin(), result.end(), [](const ChestCandidate& a, const ChestCandidate& b) {
        return a.distance_m == b.distance_m ? a.chest.id < b.chest.id : a.distance_m < b.distance_m;
    });
    return result;
}

std::vector<Player> visible_players(const GameSnapshot& snapshot, float max_distance_m, bool team_check) {
    std::vector<Player> result;
    if (!snapshot.connected || !snapshot.local_position || !finite(*snapshot.local_position))
        return result;
    const float limit = clamped_render_distance(max_distance_m);
    for (const auto& player : snapshot.players) {
        if (!player.available || !player.position || !finite(*player.position)) continue;
        if (team_check && snapshot.local_team && player.team && *snapshot.local_team == *player.team)
            continue;
        const float meters = distance(*snapshot.local_position, *player.position);
        if (std::isfinite(meters) && meters <= limit) result.push_back(player);
    }
    std::sort(result.begin(), result.end(), [](const Player& a, const Player& b) { return a.id < b.id; });
    return result;
}
} // namespace fe
