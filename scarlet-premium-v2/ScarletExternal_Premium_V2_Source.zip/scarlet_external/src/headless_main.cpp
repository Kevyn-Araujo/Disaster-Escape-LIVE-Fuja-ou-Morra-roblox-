// C++20 | headless_main.cpp | Portable deterministic simulator; no game integration.
#include "automation/auto_chest.hpp"
#include "data/mock_game_data_provider.hpp"
#include "utils/logger.hpp"
#include <charconv>
#include <cmath>
#include <iomanip>
#include <iostream>
#include <string>
#include <string_view>

namespace {
using namespace fe;
bool parse_positive_int(std::string_view text, int& value) {
    const auto result = std::from_chars(text.data(), text.data()+text.size(), value);
    return result.ec == std::errc{} && result.ptr == text.data()+text.size()
        && value > 0 && value <= 1000000;
}
bool parse_dt(const std::string& text, double& value) {
    try {
        std::size_t consumed = 0;
        value = std::stod(text, &consumed);
        return consumed == text.size() && std::isfinite(value) && value >= 0.001 && value <= 0.25;
    } catch (...) { return false; }
}
void usage() {
    std::cout << "Uso: fe_headless [--scenario baseline|unknown|blocked|stuck|timeout] "
                 "[--steps 5000] [--dt 0.05]\n"
                 "Executa apenas o MockGameDataProvider. Nao se conecta ao Fortnite.\n"
                 "Retorno: 0 = sucesso/cenario de falha concluido; "
                 "1 = baseline sem 3 confirmacoes; 2 = argumentos invalidos.\n";
}
}

int main(int argc, char** argv) {
    using namespace fe;
    std::string scenario_name = "baseline";
    MockScenario scenario = MockScenario::Baseline;
    int steps = 5000;
    double dt = 0.05;
    for (int i = 1; i < argc; ++i) {
        const std::string option = argv[i];
        if (option == "--help" || option == "-h") { usage(); return 0; }
        if (i+1 >= argc) { usage(); return 2; }
        const std::string value = argv[++i];
        if (option == "--scenario") scenario_name = value;
        else if (option == "--steps") {
            if (!parse_positive_int(value, steps)) { usage(); return 2; }
        } else if (option == "--dt") {
            if (!parse_dt(value, dt)) { usage(); return 2; }
        } else { usage(); return 2; }
    }
    if (scenario_name == "baseline") scenario = MockScenario::Baseline;
    else if (scenario_name == "unknown") scenario = MockScenario::UnknownStates;
    else if (scenario_name == "blocked") scenario = MockScenario::Blocked;
    else if (scenario_name == "stuck") scenario = MockScenario::Stuck;
    else if (scenario_name == "timeout") scenario = MockScenario::InteractionTimeout;
    else { usage(); return 2; }

    Logger logger;
    MockGameDataProvider provider(scenario);
    AutomationSettings settings;
    settings.enabled = true;
    AutoChestMachine machine(logger);
    auto previous_state = machine.state();
    std::cout << "MOCK SIMULATOR | scenario=" << scenario_name
              << " | steps=" << steps << " | dt=" << dt << "\n";
    std::cout << "0.00s " << state_name(previous_state) << "\n";
    for (int step = 0; step < steps; ++step) {
        provider.tick(dt);
        const auto snapshot = provider.snapshot();
        machine.update(snapshot, provider, settings, dt);
        if (machine.state() != previous_state) {
            previous_state = machine.state();
            std::cout << std::fixed << std::setprecision(2) << snapshot.simulation_time
                      << "s " << state_name(previous_state);
            if (machine.target()) std::cout << " target=" << *machine.target();
            std::cout << " | " << machine.status() << "\n";
        }
    }
    provider.stop();
    std::size_t warnings = 0, errors = 0;
    for (const auto& entry : logger.entries()) {
        if (entry.level == LogLevel::Warning) ++warnings;
        if (entry.level == LogLevel::Error) ++errors;
    }
    std::cout << "SUMMARY confirmed_openings=" << machine.completed_count()
              << " warnings=" << warnings << " errors=" << errors
              << " elapsed=" << provider.snapshot().simulation_time << "s\n";
    if (scenario == MockScenario::Baseline) return machine.completed_count() >= 3 ? 0 : 1;
    // Fault scenarios intentionally need not open a chest; the test suite verifies their behavior.
    return 0;
}
