#include "config/settings.hpp"
#include "nlohmann/json.hpp"
#include <algorithm>
#include <cmath>
#include <fstream>
#include <functional>
#include <limits>
#include <set>
#include <vector>
#include <type_traits>
#include <stdexcept>
#include <string_view>
#include <cstdint>
#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#endif
namespace fe {
namespace {
using Json = nlohmann::json;
float bounded(float value,float low,float high,float fallback) {
    return std::isfinite(value)?std::clamp(value,low,high):fallback;
}
bool valid_profile_text(std::string_view value,std::size_t max_codepoints) {
    std::size_t count=0;
    for(std::size_t i=0;i<value.size();) {
        const auto first=static_cast<unsigned char>(value[i]);
        std::uint32_t codepoint{};
        std::size_t length{};
        if(first<=0x7f) {codepoint=first;length=1;}
        else if(first>=0xc2&&first<=0xdf) {codepoint=first&0x1fu;length=2;}
        else if(first>=0xe0&&first<=0xef) {codepoint=first&0x0fu;length=3;}
        else if(first>=0xf0&&first<=0xf4) {codepoint=first&0x07u;length=4;}
        else return false;
        if(i+length>value.size())return false;
        for(std::size_t j=1;j<length;++j) {
            const auto byte=static_cast<unsigned char>(value[i+j]);
            if((byte&0xc0u)!=0x80u)return false;
            codepoint=(codepoint<<6)|(byte&0x3fu);
        }
        if((length==2&&codepoint<0x80)||(length==3&&codepoint<0x800)
           ||(length==4&&codepoint<0x10000)||codepoint>0x10ffff
           ||(codepoint>=0xd800&&codepoint<=0xdfff)
           ||codepoint<0x20||(codepoint>=0x7f&&codepoint<=0x9f))return false;
        if(++count>max_codepoints)return false;
        i+=length;
    }
    return true;
}
std::string pointer_for(std::string key) {
    std::replace(key.begin(),key.end(),'.','/');
    return "/"+key;
}
struct Binding {
    std::string key;
    std::function<Json()> write;
    std::function<bool(const Json&)> read;
};
std::vector<Binding> bindings(Settings& settings) {
    std::vector<Binding> result;
    auto bind=[&]<class T>(const std::string& key,T& field,std::size_t text_limit=64) {
        result.push_back({pointer_for(key),[ptr=&field]() {return Json(*ptr);},
            [ptr=&field,text_limit](const Json& value) {
                (void)text_limit;
                if constexpr(std::is_same_v<T,std::string>) {
                    if(!value.is_string())return false;
                    const auto parsed=value.get<std::string>();
                    if(!valid_profile_text(parsed,text_limit))return false;
                    *ptr=parsed;
                } else if constexpr(std::is_same_v<T,bool>) {
                    if(!value.is_boolean()) return false;
                    *ptr=value.get<bool>();
                } else if constexpr(std::is_integral_v<T>) {
                    if(!value.is_number_integer()) return false;
                    const double number=value.get<double>();
                    if(number<std::numeric_limits<T>::lowest()||number>std::numeric_limits<T>::max()) return false;
                    *ptr=value.get<T>();
                } else {
                    if(!value.is_number()) return false;
                    const double number=value.get<double>();
                    if(!std::isfinite(number)||std::abs(number)>std::numeric_limits<float>::max()) return false;
                    *ptr=static_cast<T>(number);
                }
                return true;
            }});
    };
#define B(field) bind(#field,settings.field)
    B(visuals.enabled); B(visuals.players); B(visuals.chests);
    B(visuals.boxes); B(visuals.skeleton); B(visuals.names); B(visuals.distance);
    B(visuals.health); B(visuals.shield); B(visuals.snaplines); B(visuals.head_marker);
    B(visuals.player_count); B(visuals.visibility); B(visuals.team_check);
    B(visuals.chest_distance); B(visuals.chest_marker); B(visuals.nearest_highlight); B(visuals.chest_counter);
    B(visuals.max_chest_distance_m); B(visuals.max_player_distance_m);
    B(automation.enabled); B(automation.afk_mode); B(automation.auto_navigate); B(automation.auto_interact);
    B(automation.max_distance_m); B(automation.speed_mps); B(automation.interaction_distance_m);
    B(automation.interaction_timeout_s); B(automation.verification_timeout_s); B(automation.stuck_timeout_s);
    B(automation.progress_epsilon_m); B(automation.max_retries);
    B(overlay.fps_limit); B(overlay.vsync); B(overlay.transparent); B(overlay.click_through);
    B(overlay.menu_key); B(overlay.emergency_key); B(overlay.start_stop_key);
    B(automation.auto_retry); B(automation.stuck_recovery);
    B(premium.appearance.theme); B(premium.appearance.background_opacity);
    B(premium.appearance.sidebar_opacity); B(premium.appearance.card_opacity);
    B(premium.appearance.header_opacity); B(premium.appearance.border_opacity); B(premium.appearance.ui_scale);
    B(premium.rgb.enabled); B(premium.rgb.rainbow); B(premium.rgb.sidebar); B(premium.rgb.borders);
    B(premium.rgb.logo); B(premium.rgb.sliders); B(premium.rgb.toggles); B(premium.rgb.header_line);
    B(premium.rgb.mode); B(premium.rgb.speed); B(premium.rgb.brightness);
    B(premium.particles.enabled); B(premium.particles.connections); B(premium.particles.mouse_interaction);
    B(premium.particles.count); B(premium.particles.speed); B(premium.particles.size); B(premium.particles.opacity);
    B(premium.animation.enabled); B(premium.animation.disable_all); B(premium.animation.smooth_transitions);
    B(premium.animation.style); B(premium.animation.duration_ms); B(premium.animation.speed);
    B(premium.performance.low_performance); B(premium.performance.disable_heavy_effects); B(premium.performance.statistics);
    B(premium.esp.hat); B(premium.esp.hat_rainbow); B(premium.esp.hat_filled);
    B(premium.esp.hat_radius); B(premium.esp.hat_height); B(premium.esp.hat_thickness);
    B(premium.esp.hoop); B(premium.esp.hoop_rainbow); B(premium.esp.hoop_radius);
    B(premium.esp.hoop_thickness); B(premium.esp.hoop_speed); B(premium.esp.hoop_height_offset); B(premium.esp.hoop_direction);
    B(premium.esp.box_3d); B(premium.esp.corner_box); B(premium.esp.gradient_box); B(premium.esp.outline);
    B(premium.esp.rgb_skeleton); B(premium.esp.rgb_snaplines); B(premium.esp.glow_outline); B(premium.esp.distance_gradient);
    bind("premium.profile.name",settings.premium.profile.name,64);
    bind("premium.profile.status",settings.premium.profile.status,32);
#undef B
    auto color=[&](const char* prefix,Color& value) {
        constexpr const char* channels[]={".r",".g",".b",".a"};
        for(std::size_t i=0;i<4;++i) bind(std::string(prefix)+channels[i],value[i]);
    };
    color("visuals.player_color",settings.visuals.player_color);
    color("visuals.hidden_color",settings.visuals.hidden_color);
    color("visuals.chest_color",settings.visuals.chest_color);
    color("visuals.nearest_color",settings.visuals.nearest_color);
    color("visuals.skeleton_color",settings.visuals.skeleton_color);
    color("visuals.snapline_color",settings.visuals.snapline_color);
    color("visuals.head_color",settings.visuals.head_color);
    color("visuals.health_color",settings.visuals.health_color);
    color("visuals.shield_color",settings.visuals.shield_color);
    color("premium.appearance.primary",settings.premium.appearance.primary);
    color("premium.appearance.secondary",settings.premium.appearance.secondary);
    color("premium.appearance.background",settings.premium.appearance.background);
    color("premium.appearance.text",settings.premium.appearance.text);
    color("premium.appearance.border",settings.premium.appearance.border);
    color("premium.appearance.accent",settings.premium.appearance.accent);
    color("premium.particles.color",settings.premium.particles.color);
    color("premium.esp.hat_color",settings.premium.esp.hat_color);
    color("premium.esp.hoop_color",settings.premium.esp.hoop_color);
    return result;
}
} // namespace
void normalize_settings(Settings& settings) {
    auto& v=settings.visuals;
    v.max_chest_distance_m=bounded(v.max_chest_distance_m,50,1000,1000);
    v.max_player_distance_m=bounded(v.max_player_distance_m,50,1000,500);
    Color* colors[]={&v.player_color,&v.hidden_color,&v.chest_color,&v.nearest_color,
        &v.skeleton_color,&v.snapline_color,&v.head_color,&v.health_color,&v.shield_color};
    for(auto* color:colors) for(float& channel:*color) channel=bounded(channel,0,1,1);
    auto& a=settings.automation;
    a.max_distance_m=bounded(a.max_distance_m,50,1000,1000);
    a.speed_mps=bounded(a.speed_mps,0.5f,20,8);
    a.interaction_distance_m=bounded(a.interaction_distance_m,0.5f,2.2f,2);
    a.interaction_timeout_s=bounded(a.interaction_timeout_s,0.25f,30,3);
    a.verification_timeout_s=bounded(a.verification_timeout_s,0.25f,30,2);
    a.stuck_timeout_s=bounded(a.stuck_timeout_s,0.25f,30,2);
    a.progress_epsilon_m=bounded(a.progress_epsilon_m,0.01f,2,0.1f);
    a.max_retries=std::clamp(a.max_retries,0,8);
    auto& o=settings.overlay;
    o.fps_limit=std::clamp(o.fps_limit,15,240);
    const int menu_keys[]={0x2D,0x24,0x75,0x76};
    const int emergency_keys[]={0x77,0x78,0x79,0x7A};
    if(std::find(std::begin(menu_keys),std::end(menu_keys),o.menu_key)==std::end(menu_keys)) o.menu_key=0x2D;
    if(std::find(std::begin(emergency_keys),std::end(emergency_keys),o.emergency_key)==std::end(emergency_keys)) o.emergency_key=0x77;
    const int start_keys[]={0x74,0x75,0x78};
    if(std::find(std::begin(start_keys),std::end(start_keys),o.start_stop_key)==std::end(start_keys)) o.start_stop_key=0x75;
    if(o.start_stop_key==o.menu_key||o.start_stop_key==o.emergency_key) o.start_stop_key=0x74;
    if(o.menu_key==o.emergency_key) { o.menu_key=0x2D; o.emergency_key=0x77; }
    auto& p=settings.premium;
    auto& appearance=p.appearance;
    appearance.theme=std::clamp(appearance.theme,0,9);
    appearance.background_opacity=bounded(appearance.background_opacity,0,1,.85f);
    appearance.sidebar_opacity=bounded(appearance.sidebar_opacity,0,1,.90f);
    appearance.card_opacity=bounded(appearance.card_opacity,0,1,.88f);
    appearance.header_opacity=bounded(appearance.header_opacity,0,1,.92f);
    appearance.border_opacity=bounded(appearance.border_opacity,0,1,.45f);
    appearance.ui_scale=bounded(appearance.ui_scale,.75f,1.4f,1);
    auto& rgb=p.rgb;
    rgb.mode=std::clamp(rgb.mode,0,5);
    rgb.speed=bounded(rgb.speed,0,2,.15f);
    rgb.brightness=bounded(rgb.brightness,0,1,.9f);
    auto& particles=p.particles;
    particles.count=std::clamp(particles.count,0,100);
    particles.speed=bounded(particles.speed,0,3,.25f);
    particles.size=bounded(particles.size,.25f,6,1.5f);
    particles.opacity=bounded(particles.opacity,0,1,.22f);
    auto& animation=p.animation;
    animation.style=std::clamp(animation.style,0,4);
    animation.duration_ms=bounded(animation.duration_ms,50,1000,220);
    animation.speed=bounded(animation.speed,.25f,4,1);
    auto& esp=p.esp;
    esp.hat_radius=bounded(esp.hat_radius,.05f,2,.4f);
    esp.hat_height=bounded(esp.hat_height,.05f,2,.4f);
    esp.hat_thickness=bounded(esp.hat_thickness,.5f,6,1.5f);
    esp.hoop_radius=bounded(esp.hoop_radius,.05f,3,.55f);
    esp.hoop_thickness=bounded(esp.hoop_thickness,.5f,6,1.5f);
    esp.hoop_speed=bounded(esp.hoop_speed,0,6,1);
    esp.hoop_height_offset=bounded(esp.hoop_height_offset,-2,2,0);
    esp.hoop_direction=esp.hoop_direction<0?-1:1;
    Color* premium_colors[]={&appearance.primary,&appearance.secondary,&appearance.background,&appearance.text,
        &appearance.border,&appearance.accent,&particles.color,&esp.hat_color,&esp.hoop_color};
    for(auto* color:premium_colors)for(float& channel:*color)channel=bounded(channel,0,1,1);
    if(p.profile.name.empty()||!valid_profile_text(p.profile.name,64))p.profile.name="Scarlet User";
    if(p.profile.status.empty()||!valid_profile_text(p.profile.status,32))p.profile.status="Cliente";
}

bool save_settings(const std::filesystem::path& path,const Settings& settings,std::string& error) {
    error.clear();
    try {
        Settings normalized=settings; normalize_settings(normalized);
        Json document=Json::object(); document["format_version"]=1;
        for(const auto& binding:bindings(normalized)) document[Json::json_pointer(binding.key)]=binding.write();
        auto temporary=path; temporary+=".tmp";
        {
            std::ofstream stream(temporary,std::ios::trunc);
            if(!stream) {error="Nao foi possivel criar configuracao."; return false;}
            stream<<document.dump(2)<<'\n'; stream.flush();
            if(!stream) {error="Falha ao gravar configuracao."; return false;}
        }
#ifdef _WIN32
        if(!MoveFileExW(temporary.c_str(),path.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)) {
            error="Falha ao substituir configuracao: "+std::to_string(GetLastError()); return false;
        }
#else
        std::filesystem::rename(temporary,path);
#endif
        return true;
    } catch(const std::exception& exception) {error=exception.what();return false;}
}
bool load_settings(const std::filesystem::path& path,Settings& settings,std::string& error) {
    error.clear();
    try {
        if(std::filesystem::file_size(path)>65536) {error="Configuracao excede 64 KiB.";return false;}
        std::ifstream stream(path);
        if(!stream) {error="Nao foi possivel abrir configuracao.";return false;}
        std::vector<std::set<std::string>> keys;
        auto callback=[&](int,Json::parse_event_t event,Json& parsed) {
            if(event==Json::parse_event_t::object_start) keys.emplace_back();
            else if(event==Json::parse_event_t::key) {
                if(keys.empty()||!keys.back().insert(parsed.get<std::string>()).second)
                    throw std::runtime_error("Chave JSON duplicada.");
            } else if(event==Json::parse_event_t::object_end) keys.pop_back();
            return true;
        };
        const Json document=Json::parse(stream,callback);
        if(!document.is_object()||!document.contains("format_version")
           ||!document["format_version"].is_number_integer()||document["format_version"]!=1) {
            error="format_version invalido ou ausente.";return false;
        }
        Settings candidate=settings;
        auto fields=bindings(candidate);
        const auto flattened=document.flatten();
        for(const auto& [key,value]:flattened.items()) {
            if(key=="/format_version") continue;
            const auto found=std::find_if(fields.begin(),fields.end(),[&](const Binding& b){return b.key==key;});
            if(found==fields.end()) {error="Chave desconhecida: "+key;return false;}
            if(!found->read(value)) {error="Valor invalido: "+key;return false;}
        }
        normalize_settings(candidate); candidate.automation.enabled=false; settings=candidate;
        return true;
    } catch(const std::exception& exception) {error=exception.what();return false;}
}
} // namespace fe
