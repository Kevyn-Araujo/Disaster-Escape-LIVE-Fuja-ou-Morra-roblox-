#pragma once
#include <array>
#include <string>
namespace fe {
struct AppearanceSettings {
    int theme{0}; float background_opacity{.85f},sidebar_opacity{.90f},card_opacity{.88f},header_opacity{.92f},border_opacity{.45f},ui_scale{1};
    std::array<float,4> primary{1,.208f,.157f,1},secondary{.75f,.1f,.12f,1},background{.059f,.059f,.059f,1},text{.95f,.95f,.95f,1},border{.16f,.16f,.16f,1},accent{1,.65f,.2f,1};
};
struct RGBSettings {
    bool enabled{false},rainbow{true},sidebar{true},borders{true},logo{true},sliders{true},toggles{true},header_line{true};
    int mode{0};float speed{.15f},brightness{.9f};
};
struct ParticleSettings {
    bool enabled{true},connections{true},mouse_interaction{true};int count{50};
    float speed{.25f},size{1.5f},opacity{.22f};std::array<float,4> color{1,1,1,1};
};
struct AnimationSettings {bool enabled{true},disable_all{false},smooth_transitions{true};int style{0};float duration_ms{220},speed{1};};
struct PerformanceSettings {bool low_performance{false},disable_heavy_effects{false},statistics{true};};
struct ProfileSettings {std::string name{"Scarlet User"},status{"Cliente"};};
struct SpecialESPSettings {
    bool hat{false},hat_rainbow{false},hat_filled{false};float hat_radius{.4f},hat_height{.4f},hat_thickness{1.5f};std::array<float,4> hat_color{1,.208f,.157f,1};
    bool hoop{false},hoop_rainbow{false};float hoop_radius{.55f},hoop_thickness{1.5f},hoop_speed{1},hoop_height_offset{0};int hoop_direction{1};std::array<float,4> hoop_color{.3f,.9f,1,1};
    bool box_3d{false},corner_box{false},gradient_box{false},outline{false},rgb_skeleton{false},rgb_snaplines{false},glow_outline{false},distance_gradient{false};
};
struct PremiumSettings {AppearanceSettings appearance;RGBSettings rgb;ParticleSettings particles;AnimationSettings animation;PerformanceSettings performance;ProfileSettings profile;SpecialESPSettings esp;};
}
