#pragma once
#include <array>
#include "config/premium_settings.hpp"
#include <filesystem>
#include <string>
namespace fe {
using Color = std::array<float,4>;
struct VisualSettings {
    bool enabled{true}, players{true}, chests{true};
    bool boxes{true}, skeleton{true}, names{true}, distance{true};
    bool health{true}, shield{true}, snaplines{false}, head_marker{true};
    bool player_count{true}, visibility{true}, team_check{true};
    bool chest_distance{true}, chest_marker{true}, nearest_highlight{true}, chest_counter{true};
    float max_chest_distance_m{1000}, max_player_distance_m{500};
    Color player_color{0.25f,0.85f,1.0f,1.0f};
    Color hidden_color{1.0f,0.35f,0.3f,1.0f};
    Color chest_color{1.0f,0.75f,0.18f,1.0f};
    Color nearest_color{0.3f,1.0f,0.5f,1.0f};
    Color skeleton_color{0.85f,0.85f,1.0f,1.0f};
    Color snapline_color{0.6f,0.65f,0.7f,0.7f};
    Color head_color{1.0f,1.0f,1.0f,1.0f};
    Color health_color{0.2f,0.9f,0.3f,1.0f};
    Color shield_color{0.2f,0.55f,1.0f,1.0f};
};
struct AutomationSettings {
    bool enabled{false}, afk_mode{true}, auto_navigate{true}, auto_interact{true};
    bool auto_retry{true}, stuck_recovery{true};
    float max_distance_m{1000}, speed_mps{8}, interaction_distance_m{2};
    float interaction_timeout_s{3}, verification_timeout_s{2}, stuck_timeout_s{2};
    float progress_epsilon_m{0.1f};
    int max_retries{2};
};
struct OverlaySettings {
    int fps_limit{60};
    bool vsync{true}, transparent{false}, click_through{false};
    int menu_key{0x2D}, emergency_key{0x77}, start_stop_key{0x75}; // Insert and F8.
};
struct Settings {
    VisualSettings visuals;
    AutomationSettings automation;
    OverlaySettings overlay;
    PremiumSettings premium;
};
void normalize_settings(Settings& settings);
bool save_settings(const std::filesystem::path& path, const Settings& settings, std::string& error);
bool load_settings(const std::filesystem::path& path, Settings& settings, std::string& error);
} // namespace fe
