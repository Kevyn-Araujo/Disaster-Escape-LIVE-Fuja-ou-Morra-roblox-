#include "config/ConfigManager.h"
namespace fe {
bool ConfigManager::save(const std::filesystem::path& path,const Settings& settings,std::string& error) {
    return save_settings(path,settings,error);
}
bool ConfigManager::load(const std::filesystem::path& path,Settings& settings,std::string& error) {
    return load_settings(path,settings,error);
}
}
