#pragma once
#include "config/settings.hpp"
namespace fe {
// A named entry point for UI integrations; serialization remains in settings.cpp.
class ConfigManager {
public:
    static bool save(const std::filesystem::path& path,const Settings& settings,std::string& error);
    static bool load(const std::filesystem::path& path,Settings& settings,std::string& error);
};
}
