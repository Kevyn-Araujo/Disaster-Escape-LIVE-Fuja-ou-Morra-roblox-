#include "automation/auto_chest.hpp"
#include "esp/filters.hpp"
#include "navigation/path_planner.hpp"
#include <algorithm>
#include <cmath>
#include <exception>
#include <limits>

namespace fe {
namespace {
AutomationSettings normalized(AutomationSettings settings) {
    Settings all_settings;
    all_settings.automation = settings;
    normalize_settings(all_settings);
    return all_settings.automation;
}
} // namespace

const char* state_name(AutoChestState state) noexcept {
    switch (state) {
    case AutoChestState::Idle: return "IDLE";
    case AutoChestState::Searching: return "SEARCHING";
    case AutoChestState::SelectingChest: return "SELECTING_CHEST";
    case AutoChestState::Navigating: return "NAVIGATING";
    case AutoChestState::Interacting: return "INTERACTING";
    case AutoChestState::Verifying: return "VERIFYING";
    case AutoChestState::Recovering: return "RECOVERING";
    }
    return "UNKNOWN";
}

void AutoChestMachine::transition(AutoChestState state, std::string status) {
    if (state != state_) {
        logger_.info(std::string(state_name(state_)) + " -> " + state_name(state) + ": " + status);
    }
    state_ = state;
    status_ = std::move(status);
    state_elapsed_ = 0;
}

void AutoChestMachine::clear_target() {
    target_.reset();
    route_.clear();
    waypoint_index_ = 0;
    progress_elapsed_ = 0;
    movement_requested_ = false;
    next_interaction_attempt_ = 0;
    attempts_ = 0;
}

void AutoChestMachine::reset_run() {
    clear_target();
    failures_.clear();
    have_snapshot_ = false;
    stale_reported_ = false;
    stale_elapsed_ = 0;
    run_time_ = 0;
    state_elapsed_ = 0;
    search_wait_ = 0;
}

void AutoChestMachine::emergency_stop(IControlSink& controls) noexcept {
    controls.stop();
    emergency_latched_ = true;
    clear_target();
    state_ = AutoChestState::Idle;
    state_elapsed_ = 0;
    try {
        status_ = "Parada de emergencia; desligue e ligue Auto Chest para retomar";
        logger_.warn(status_);
    } catch (...) { /* The stop and latch remain effective even if logging fails. */ }
}

void AutoChestMachine::recover(IControlSink& controls, const AutomationSettings& settings,
                              const std::string& reason) {
    controls.stop();
    if (target_) {
        auto& failure = failures_[*target_];
        ++failure.attempts;
        failure.exhausted = !settings.auto_retry || failure.attempts > settings.max_retries;
        failure.cooldown_until = run_time_ + std::min(5.0, static_cast<double>(failure.attempts));
        attempts_ = failure.attempts;
        logger_.warn("Bau " + std::to_string(*target_) + ": " + reason +
            (failure.exhausted ? "; tentativas esgotadas nesta execucao" : "; aguardando recuperacao"));
    }
    route_.clear();
    waypoint_index_ = 0;
    transition(AutoChestState::Recovering, reason);
}

void AutoChestMachine::update(const GameSnapshot& snapshot, IControlSink& controls,
                             const AutomationSettings& settings, double seconds) {
    try {
        update_impl(snapshot, controls, normalized(settings), seconds);
    } catch (const std::exception& error) {
        emergency_stop(controls);
        try { logger_.error(std::string("Falha na automacao: ") + error.what()); } catch (...) {}
    } catch (...) {
        emergency_stop(controls);
        try { logger_.error("Falha desconhecida na automacao"); } catch (...) {}
    }
}

void AutoChestMachine::update_impl(const GameSnapshot& snapshot, IControlSink& controls,
                                  AutomationSettings settings, double seconds) {
    if (!settings.enabled) {
        controls.stop();
        if (previous_enabled_ || emergency_latched_ || single_complete_latched_) reset_run();
        previous_enabled_ = false;
        emergency_latched_ = false;
        single_complete_latched_ = false;
        if (state_ != AutoChestState::Idle) transition(AutoChestState::Idle, "Desativado");
        else status_ = "Desativado";
        return;
    }
    if (emergency_latched_ || single_complete_latched_) {
        previous_enabled_ = true;
        controls.stop();
        return;
    }
    if (!previous_enabled_) {
        reset_run();
        previous_enabled_ = true;
        transition(AutoChestState::Searching, "Procurando baus fechados confirmados");
    }
    if (!std::isfinite(seconds) || seconds <= 0 || seconds > 1) {
        controls.stop();
        status_ = "Intervalo invalido; esperado 0 < dt <= 1 segundo";
        return;
    }
    if (!snapshot.connected || !snapshot.local_position || !finite(*snapshot.local_position)
        || !std::isfinite(snapshot.simulation_time)) {
        controls.stop();
        clear_target();
        transition(AutoChestState::Searching, "Aguardando dados locais validos e conexao");
        have_snapshot_ = false;
        return;
    }
    if (have_snapshot_ && (snapshot.sequence < last_sequence_
                          || snapshot.simulation_time < last_simulation_time_)) {
        controls.stop();
        reset_run();
        transition(AutoChestState::Searching, "Fluxo de dados reiniciado; recalculando alvos");
    }
    if (have_snapshot_ && snapshot.sequence == last_sequence_
        && snapshot.simulation_time == last_simulation_time_) {
        controls.stop();
        stale_elapsed_ += seconds;
        status_ = stale_elapsed_ >= 1 ? "Dados desatualizados; movimento suspenso"
                                    : "Aguardando um snapshot novo";
        if (stale_elapsed_ >= 1 && !stale_reported_) {
            logger_.warn(status_);
            stale_reported_ = true;
        }
        return;
    }
    if (stale_elapsed_ > 0) status_ = std::string(state_name(state_)) + ": dados atualizados";
    have_snapshot_ = true;
    last_sequence_ = snapshot.sequence;
    last_simulation_time_ = snapshot.simulation_time;
    stale_elapsed_ = 0;
    stale_reported_ = false;
    run_time_ += seconds;

    const Vec3 local = *snapshot.local_position;
    const Chest* current = nullptr;
    if (target_) {
        const auto found = std::find_if(snapshot.chests.begin(), snapshot.chests.end(),
            [this](const Chest& chest) { return chest.id == *target_; });
        if (found != snapshot.chests.end()) current = &*found;
        if (current && current->available && current->state == ChestState::Open
            && state_ == AutoChestState::Verifying) {
            controls.stop();
            logger_.info("Abertura confirmada pelo provider: bau " + std::to_string(*target_));
            failures_.erase(*target_);
            ++completed_count_;
            clear_target();
            if (!settings.afk_mode) {
                single_complete_latched_ = true;
                transition(AutoChestState::Idle, "Um bau concluido; desligue e ligue para executar novamente");
            } else {
                transition(AutoChestState::Searching, "Abertura confirmada; procurando o proximo bau");
            }
            return;
        }
        if (!current || !current->available || current->state != ChestState::Closed
            || !current->position || !finite(*current->position)
            || distance(local, *current->position) > settings.max_distance_m) {
            controls.stop();
            clear_target();
            transition(AutoChestState::Searching, "Alvo removido, fora de alcance ou sem estado fechado confirmado");
            return;
        }
        if (distance(*current->position, target_position_) > 0.25f) {
            controls.stop();
            clear_target();
            transition(AutoChestState::SelectingChest, "Posicao do alvo mudou; recalculando rota");
            return;
        }
    }
    if ((!snapshot.navigation || !snapshot.navigation->valid())
        && state_ != AutoChestState::Verifying && state_ != AutoChestState::Recovering) {
        controls.stop();
        status_ = "Aguardando malha de navegacao autorizada valida";
        return;
    }
    if (state_ == AutoChestState::Navigating && !settings.auto_navigate) {
        controls.stop();
        progress_elapsed_ = 0;
        movement_requested_ = false;
        last_progress_position_ = local;
        status_ = "Navegacao pausada pela configuracao";
        return;
    }
    if (state_ == AutoChestState::Interacting && !settings.auto_interact) {
        controls.stop();
        status_ = "Interacao pausada pela configuracao";
        return;
    }
    state_elapsed_ += seconds;
    switch (state_) {
    case AutoChestState::Idle:
        transition(AutoChestState::Searching, "Procurando baus fechados confirmados");
        break;
    case AutoChestState::Searching: {
        controls.stop();
        search_wait_ = std::max(0.0, search_wait_ - seconds);
        if (search_wait_ > 0) break;
        const auto candidates = closed_chests(snapshot, settings.max_distance_m);
        const bool any = std::any_of(candidates.begin(), candidates.end(), [this](const ChestCandidate& candidate) {
            const auto failure = failures_.find(candidate.chest.id);
            return failure == failures_.end() || (!failure->second.exhausted && failure->second.cooldown_until <= run_time_);
        });
        if (any) transition(AutoChestState::SelectingChest, "Comparando rotas para alvos acessiveis");
        else {
            status_ = "Sem baus fechados elegiveis; aguardando atualizacoes ou recuperacao";
            search_wait_ = 0.5;
        }
        break;
    }
    case AutoChestState::SelectingChest: {
        controls.stop();
        const auto candidates = closed_chests(snapshot, settings.max_distance_m);
        std::optional<Path> best;
        std::optional<EntityId> best_id;
        Vec3 best_position{};
        for (const auto& candidate : candidates) {
            // Candidates are sorted by straight-line distance, a lower bound on any route.
            if (best && candidate.distance_m > best->length_m + 0.0001f) break;
            const auto failure = failures_.find(candidate.chest.id);
            if (failure != failures_.end() && (failure->second.exhausted || failure->second.cooldown_until > run_time_)) continue;
            auto path = plan_path(*snapshot.navigation, local, *candidate.chest.position);
            if (!path || !std::isfinite(path->length_m)) continue;
            if (!best || path->length_m < best->length_m - 0.0001f
                || (std::abs(path->length_m - best->length_m) <= 0.0001f && candidate.chest.id < *best_id)) {
                best = std::move(path);
                best_id = candidate.chest.id;
                best_position = *candidate.chest.position;
            }
        }
        if (!best) {
            search_wait_ = 0.5;
            transition(AutoChestState::Searching, "Nenhum alvo acessivel na malha de navegacao");
            break;
        }
        target_ = best_id;
        target_position_ = best_position;
        route_ = std::move(best->points);
        waypoint_index_ = 0;
        last_progress_position_ = local;
        progress_elapsed_ = 0;
        movement_requested_ = false;
        const auto failure = failures_.find(*target_);
        attempts_ = failure == failures_.end() ? 0 : failure->second.attempts;
        if (distance(local, target_position_) <= settings.interaction_distance_m
            && segment_walkable(*snapshot.navigation, local, target_position_)) {
            transition(AutoChestState::Interacting, "Alvo ao alcance; preparando interacao");
        } else transition(AutoChestState::Navigating, "Navegando pela menor rota acessivel");
        break;
    }
    case AutoChestState::Navigating: {
        if (!target_ || !current) {
            controls.stop();
            clear_target();
            transition(AutoChestState::Searching, "Alvo ausente");
            break;
        }
        if (distance(local, target_position_) <= settings.interaction_distance_m
            && segment_walkable(*snapshot.navigation, local, target_position_)) {
            controls.stop();
            transition(AutoChestState::Interacting, "Chegada ao alcance do bau");
            break;
        }
        if (!movement_requested_ || distance(local, last_progress_position_) >= settings.progress_epsilon_m) {
            last_progress_position_ = local;
            progress_elapsed_ = 0;
        } else progress_elapsed_ += seconds;
        if (progress_elapsed_ >= settings.stuck_timeout_s) {
            if (settings.stuck_recovery) recover(controls, settings, "Movimento sem progresso; personagem preso");
            else emergency_stop(controls);
            break;
        }
        while (waypoint_index_ < route_.size() && distance(local, route_[waypoint_index_]) <= 0.15f) ++waypoint_index_;
        if (waypoint_index_ >= route_.size()
            || !segment_walkable(*snapshot.navigation, local, route_[waypoint_index_])) {
            recover(controls, settings, "Rota invalida ou obstaculo detectado");
            break;
        }
        if (!controls.move_towards(route_[waypoint_index_], settings.speed_mps, seconds)) {
            recover(controls, settings, "Provider de controle rejeitou o movimento");
        } else movement_requested_ = true;
        break;
    }
    case AutoChestState::Interacting:
        controls.stop();
        if (!target_ || !current) {
            clear_target();
            transition(AutoChestState::Searching, "Alvo ausente antes da interacao");
        } else if (distance(local, target_position_) > settings.interaction_distance_m
                   || !segment_walkable(*snapshot.navigation, local, target_position_)) {
            clear_target();
            transition(AutoChestState::SelectingChest, "Alvo saiu do alcance; recalculando rota");
        } else if (state_elapsed_ >= settings.interaction_timeout_s && next_interaction_attempt_ > 0) {
            recover(controls, settings, "Tempo limite ao solicitar interacao");
        } else if (state_elapsed_ >= next_interaction_attempt_) {
            next_interaction_attempt_ = state_elapsed_ + 0.2;
            if (controls.interact(*target_)) {
                transition(AutoChestState::Verifying, "Interacao aceita; aguardando estado Open confirmado");
            }
        }
        break;
    case AutoChestState::Verifying:
        controls.stop();
        if (state_elapsed_ >= settings.verification_timeout_s) {
            recover(controls, settings, "Tempo limite sem confirmacao de abertura");
        }
        break;
    case AutoChestState::Recovering:
        controls.stop();
        if (state_elapsed_ >= 0.3) {
            clear_target();
            transition(AutoChestState::Searching, "Recuperacao concluida; reavaliando alvos e cooldowns");
        }
        break;
    }
}
} // namespace fe
