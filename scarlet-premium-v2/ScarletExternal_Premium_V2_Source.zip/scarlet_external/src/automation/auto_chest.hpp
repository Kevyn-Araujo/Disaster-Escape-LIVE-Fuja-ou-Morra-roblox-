#pragma once
#include "config/settings.hpp"
#include "data/game_data_provider.hpp"
#include "utils/logger.hpp"
#include <optional>
#include <string>
#include <unordered_map>
#include <vector>

namespace fe {
enum class AutoChestState { Idle, Searching, SelectingChest, Navigating, Interacting, Verifying, Recovering };
const char* state_name(AutoChestState state) noexcept;

class AutoChestMachine {
public:
    explicit AutoChestMachine(Logger& logger) : logger_(logger) {}
    void update(const GameSnapshot& snapshot, IControlSink& controls,
                const AutomationSettings& settings, double seconds);
    void emergency_stop(IControlSink& controls) noexcept;
    AutoChestState state() const noexcept { return state_; }
    std::optional<EntityId> target() const noexcept { return target_; }
    const std::string& status() const noexcept { return status_; }
    int attempts() const noexcept { return attempts_; }
    const std::vector<Vec3>& route() const noexcept { return route_; }
    std::size_t completed_count() const noexcept { return completed_count_; }
private:
    struct Failure { int attempts{}; double cooldown_until{}; bool exhausted{}; };
    void update_impl(const GameSnapshot&, IControlSink&, AutomationSettings, double);
    void transition(AutoChestState state, std::string status);
    void clear_target();
    void reset_run();
    void recover(IControlSink&, const AutomationSettings&, const std::string& reason);
    Logger& logger_;
    AutoChestState state_{AutoChestState::Idle};
    std::string status_{"Desativado"};
    std::optional<EntityId> target_;
    Vec3 target_position_{}, last_progress_position_{};
    std::vector<Vec3> route_;
    std::size_t waypoint_index_{}, completed_count_{};
    std::unordered_map<EntityId, Failure> failures_;
    int attempts_{};
    bool previous_enabled_{}, emergency_latched_{}, single_complete_latched_{}, movement_requested_{};
    bool have_snapshot_{}, stale_reported_{};
    std::uint64_t last_sequence_{};
    double last_simulation_time_{}, stale_elapsed_{}, run_time_{};
    double state_elapsed_{}, progress_elapsed_{}, search_wait_{}, next_interaction_attempt_{};
};
} // namespace fe
