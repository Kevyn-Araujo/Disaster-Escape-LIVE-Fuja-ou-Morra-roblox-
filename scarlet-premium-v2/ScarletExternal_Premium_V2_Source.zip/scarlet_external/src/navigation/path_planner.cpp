#include "navigation/path_planner.hpp"
#include <algorithm>
#include <cmath>
#include <limits>
#include <queue>

namespace fe {
namespace {
constexpr std::size_t max_planning_cells = 1'048'576;
constexpr double epsilon = 1.0e-10;
struct Cell { int x{}, z{}; };

bool in_bounds(const NavigationGrid& grid, int x, int z) {
    return x >= 0 && z >= 0 && x < grid.width && z < grid.height;
}
bool cell_free(const NavigationGrid& grid, int x, int z) {
    return in_bounds(grid, x, z)
        && grid.walkable[static_cast<std::size_t>(z) * grid.width + x] != 0;
}
bool touched_free(const NavigationGrid& grid, int x, int z) {
    // Outside cells touched only at the outer boundary do not occupy the map.
    return !in_bounds(grid, x, z) || cell_free(grid, x, z);
}
double grid_x(const NavigationGrid& grid, Vec3 p) {
    return (static_cast<double>(p.x) - grid.origin.x) / grid.cell_size_m;
}
double grid_z(const NavigationGrid& grid, Vec3 p) {
    return (static_cast<double>(p.z) - grid.origin.z) / grid.cell_size_m;
}
bool grid_position(const NavigationGrid& grid, Vec3 p, Cell& cell) {
    if (!finite(p)) return false;
    const double x = grid_x(grid, p), z = grid_z(grid, p);
    if (!std::isfinite(x) || !std::isfinite(z) || x < 0 || z < 0
        || x >= grid.width || z >= grid.height) return false;
    cell = {static_cast<int>(std::floor(x)), static_cast<int>(std::floor(z))};
    return true;
}
bool integer_coordinate(double value) {
    return std::abs(value - std::round(value)) <= epsilon;
}
bool endpoint_free(const NavigationGrid& grid, Cell cell, double x, double z) {
    if (!cell_free(grid, cell.x, cell.z)) return false;
    const bool boundary_x = integer_coordinate(x), boundary_z = integer_coordinate(z);
    if (boundary_x && !touched_free(grid, cell.x - 1, cell.z)) return false;
    if (boundary_z && !touched_free(grid, cell.x, cell.z - 1)) return false;
    return !(boundary_x && boundary_z)
        || touched_free(grid, cell.x - 1, cell.z - 1);
}
float heuristic(Cell a, Cell b) {
    const int dx = std::abs(a.x - b.x), dz = std::abs(a.z - b.z);
    return static_cast<float>(std::max(dx, dz))
        + 0.41421356237f * static_cast<float>(std::min(dx, dz));
}
Vec3 center(const NavigationGrid& grid, Cell cell, float y) {
    return {grid.origin.x + (static_cast<float>(cell.x) + 0.5f) * grid.cell_size_m,
        y, grid.origin.z + (static_cast<float>(cell.z) + 0.5f) * grid.cell_size_m};
}
void append_unique(std::vector<Vec3>& points, Vec3 point) {
    if (points.empty() || distance(points.back(), point) > 1.0e-5f)
        points.push_back(point);
}
} // namespace

bool is_walkable(const NavigationGrid& grid, Vec3 position) {
    if (!grid.valid()) return false;
    Cell cell;
    return grid_position(grid, position, cell) && cell_free(grid, cell.x, cell.z);
}

bool segment_walkable(const NavigationGrid& grid, Vec3 start, Vec3 end) {
    if (!grid.valid()) return false;
    Cell current, last;
    if (!grid_position(grid, start, current) || !grid_position(grid, end, last)) return false;
    const double sx = grid_x(grid, start), sz = grid_z(grid, start);
    const double ex = grid_x(grid, end), ez = grid_z(grid, end);
    if (!endpoint_free(grid, current, sx, sz) || !endpoint_free(grid, last, ex, ez)) return false;
    const double dx = ex - sx, dz = ez - sz;
    const int step_x = (dx > 0) - (dx < 0), step_z = (dz > 0) - (dz < 0);
    const double infinity = std::numeric_limits<double>::infinity();
    const double delta_x = step_x ? 1.0 / std::abs(dx) : infinity;
    const double delta_z = step_z ? 1.0 / std::abs(dz) : infinity;
    double next_x = step_x > 0 ? (std::floor(sx) + 1.0 - sx) / dx
        : step_x < 0 ? (sx - std::floor(sx)) / -dx : infinity;
    double next_z = step_z > 0 ? (std::floor(sz) + 1.0 - sz) / dz
        : step_z < 0 ? (sz - std::floor(sz)) / -dz : infinity;
    const bool along_x_boundary = step_x == 0 && integer_coordinate(sx);
    const bool along_z_boundary = step_z == 0 && integer_coordinate(sz);
    // A supercover traversal: all cells touched by an edge or corner are checked.
    const int max_steps = grid.width + grid.height + 4;
    for (int step = 0; step < max_steps; ++step) {
        if (!cell_free(grid, current.x, current.z)) return false;
        if (along_x_boundary && !touched_free(grid, current.x - 1, current.z)) return false;
        if (along_z_boundary && !touched_free(grid, current.x, current.z - 1)) return false;
        if (current.x == last.x && current.z == last.z) return true;
        const double tolerance = epsilon * std::max({1.0, std::abs(next_x), std::abs(next_z)});
        if (step_x && step_z && std::abs(next_x - next_z) <= tolerance) {
            if (!cell_free(grid, current.x + step_x, current.z)
                || !cell_free(grid, current.x, current.z + step_z)) return false;
            current.x += step_x;
            current.z += step_z;
            next_x += delta_x;
            next_z += delta_z;
        } else if (next_x < next_z) {
            current.x += step_x;
            next_x += delta_x;
        } else {
            current.z += step_z;
            next_z += delta_z;
        }
    }
    return false;
}

std::optional<Path> plan_path(const NavigationGrid& grid, Vec3 start, Vec3 goal) {
    if (!grid.valid() || grid.walkable.size() > max_planning_cells) return std::nullopt;
    Cell first, last;
    if (!grid_position(grid, start, first) || !grid_position(grid, goal, last)
        || !cell_free(grid, first.x, first.z) || !cell_free(grid, last.x, last.z)) return std::nullopt;
    if (segment_walkable(grid, start, goal)) {
        Path path;
        path.points.push_back(start);
        append_unique(path.points, goal);
        path.length_m = distance(start, goal);
        return std::isfinite(path.length_m) ? std::optional<Path>{std::move(path)} : std::nullopt;
    }

    struct Node { float f{}, g{}; int index{}; };
    struct Later {
        bool operator()(const Node& a, const Node& b) const {
            if (a.f != b.f) return a.f > b.f;
            if (a.g != b.g) return a.g > b.g;
            return a.index > b.index;
        }
    };
    const auto index = [&grid](Cell cell) { return cell.z * grid.width + cell.x; };
    const auto cell_at = [&grid](int id) { return Cell{id % grid.width, id / grid.width}; };
    const int start_index = index(first), goal_index = index(last);
    std::vector<float> costs(grid.walkable.size(), std::numeric_limits<float>::infinity());
    std::vector<int> parents(grid.walkable.size(), -1);
    std::vector<std::uint8_t> closed(grid.walkable.size(), 0);
    std::priority_queue<Node, std::vector<Node>, Later> open;
    costs[start_index] = 0;
    open.push({heuristic(first, last), 0, start_index});
    constexpr int offsets[8][2] = {{1,0},{0,1},{-1,0},{0,-1},{1,1},{-1,1},{-1,-1},{1,-1}};
    while (!open.empty()) {
        const Node node = open.top();
        open.pop();
        if (closed[node.index] || node.g != costs[node.index]) continue;
        closed[node.index] = 1;
        if (node.index == goal_index) break;
        const Cell current = cell_at(node.index);
        for (const auto& offset : offsets) {
            const Cell next{current.x + offset[0], current.z + offset[1]};
            if (!cell_free(grid, next.x, next.z)) continue;
            const bool diagonal = offset[0] && offset[1];
            if (diagonal && (!cell_free(grid, current.x + offset[0], current.z)
                || !cell_free(grid, current.x, current.z + offset[1]))) continue;
            const int next_index = index(next);
            if (closed[next_index]) continue;
            const float candidate = node.g + (diagonal ? 1.41421356237f : 1.0f);
            if (candidate >= costs[next_index]) continue;
            costs[next_index] = candidate;
            parents[next_index] = node.index;
            open.push({candidate + heuristic(next, last), candidate, next_index});
        }
    }
    if (!closed[goal_index]) return std::nullopt;
    std::vector<Cell> cells;
    for (int cursor = goal_index; cursor != -1; cursor = parents[cursor])
        cells.push_back(cell_at(cursor));
    std::reverse(cells.begin(), cells.end());
    std::vector<Vec3> raw;
    raw.reserve(cells.size() + 2);
    append_unique(raw, start);
    for (Cell cell : cells) append_unique(raw, center(grid, cell, start.y));
    append_unique(raw, goal);
    for (std::size_t i = 1; i < raw.size(); ++i)
        if (!segment_walkable(grid, raw[i - 1], raw[i])) return std::nullopt;

    // A bounded lookahead removes unnecessary center points without quadratic work.
    Path path;
    path.points.push_back(raw.front());
    for (std::size_t anchor = 0; anchor + 1 < raw.size();) {
        std::size_t next = std::min(anchor + 32, raw.size() - 1);
        while (next > anchor + 1 && !segment_walkable(grid, raw[anchor], raw[next])) --next;
        path.length_m += distance(raw[anchor], raw[next]);
        append_unique(path.points, raw[next]);
        anchor = next;
    }
    if (!std::isfinite(path.length_m)) return std::nullopt;
    return path;
}
} // namespace fe
