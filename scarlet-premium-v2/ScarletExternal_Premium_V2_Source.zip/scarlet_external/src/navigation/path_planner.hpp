#pragma once
#include "core/types.hpp"
#include <optional>
#include <vector>

namespace fe {
struct Path {
    std::vector<Vec3> points;
    float length_m{};
};

bool is_walkable(const NavigationGrid& grid, Vec3 position);
bool segment_walkable(const NavigationGrid& grid, Vec3 start, Vec3 end);

// XZ-plane A*: at most 1,048,576 cells. Obstacles include diagonal corner contact.
// The returned polyline includes the exact endpoints, in meters.
std::optional<Path> plan_path(const NavigationGrid& grid, Vec3 start, Vec3 goal);
} // namespace fe
