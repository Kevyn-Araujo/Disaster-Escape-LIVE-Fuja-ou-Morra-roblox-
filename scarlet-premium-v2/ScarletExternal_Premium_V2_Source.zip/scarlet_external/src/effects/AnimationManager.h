#pragma once
#include "config/premium_settings.hpp"
namespace fe {
class AnimationManager {
public:
    void update(bool visible,float delta_seconds,const AnimationSettings& settings);
    float progress() const noexcept;
    bool active() const noexcept { return value_>0; } // Also true during the closing fade.
    bool animating() const noexcept { return value_>0&&value_<1; }
    static float damp(float current,float target,float delta_seconds,float rate=16) noexcept;
private:
    float value_{};
};
}
