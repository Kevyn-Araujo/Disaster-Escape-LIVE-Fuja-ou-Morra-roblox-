#include "effects/UIEffects.h"
#include "effects/AnimationManager.h"
#include <algorithm>
#include <cmath>
namespace fe {
void UIEffects::begin_frame(float delta_seconds,bool smooth) noexcept {
    delta_=std::isfinite(delta_seconds)?std::clamp(delta_seconds,0.0f,.25f):0;
    smooth_=smooth;++frame_;
}
float UIEffects::scalar(ImGuiID id,float target,float rate) noexcept {
    if(!std::isfinite(target))target=0;
    // Fixed open-addressed storage: no allocation, even after arbitrary widget IDs.
    const std::size_t start=(static_cast<std::size_t>(id)*2654435761u)%capacity;
    std::size_t oldest=start;
    for(std::size_t offset=0;offset<capacity;++offset){
        const std::size_t index=(start+offset)%capacity;
        auto& entry=entries_[index];
        if(!entry.used){entry={id,target,frame_,true};++size_;return target;}
        if(entry.id==id){
            entry.value=smooth_?AnimationManager::damp(entry.value,target,delta_,rate):target;
            entry.touched=frame_;return entry.value;
        }
        if(entry.touched<entries_[oldest].touched)oldest=index;
    }
    entries_[oldest]={id,target,frame_,true};return target;
}
}
