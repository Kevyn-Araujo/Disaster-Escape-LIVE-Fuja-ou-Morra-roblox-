#include "effects/ParticleSystem.h"
#include "effects/ThemeManager.h"
#include "effects/RGBManager.h"
#include <algorithm>
#include <cmath>
namespace fe {
namespace {
float bounded(float value,float lo,float hi,float fallback){return std::isfinite(value)?std::clamp(value,lo,hi):fallback;}
float random_unit(std::uint32_t& seed){seed=1664525u*seed+1013904223u;return static_cast<float>((seed>>8)&0xFFFFFFu)/16777216.0f;}
float wrapped(float value,float extent){value=std::fmod(value,extent);return value<0?value+extent:value;}
ImU32 tint(Color color,float alpha){
    for(float& c:color)c=bounded(c,0,1,1);
    color[3]*=bounded(alpha,0,1,0);
    return ImGui::ColorConvertFloat4ToU32({color[0],color[1],color[2],color[3]});
}
}
void ParticleSystem::initialize(std::size_t index){
    auto& particle=particles_[index];std::uint32_t seed=0x51CA713u+static_cast<std::uint32_t>(index)*2654435761u;
    seed^=seed>>16;seed*=0x7feb352du;seed^=seed>>15;seed*=0x846ca68bu;seed^=seed>>16;
    particle.position={random_unit(seed)*width_,random_unit(seed)*height_};
    particle.velocity={random_unit(seed)*2-1,random_unit(seed)*2-1};
    particle.phase=random_unit(seed);
    const float angle=particle.phase*6.28318530718f;
    particle.sine=std::sin(angle);particle.cosine=std::cos(angle);
}
void ParticleSystem::update(float delta_seconds,float width,float height,const ParticleSettings& settings,
                            int theme,Vec2 mouse,bool mouse_valid,bool performance){
    if(!std::isfinite(width)||!std::isfinite(height)||width<=0||height<=0){count_=0;return;}
    if(width_>0&&height_>0&&(width_!=width||height_!=height)){
        const float sx=width/width_,sy=height/height_;
        for(std::size_t i=0;i<initialized_;++i){particles_[i].position.x*=sx;particles_[i].position.y*=sy;}
    }
    width_=width;height_=height;theme_=std::clamp(theme,0,9);performance_=performance;settings_=settings;
    settings_.count=std::clamp(settings_.count,0,100);settings_.speed=bounded(settings_.speed,0,3,.25f);
    settings_.size=bounded(settings_.size,.3f,6,1.5f);settings_.opacity=bounded(settings_.opacity,0,1,.22f);
    const int cap=performance?25:100;
    count_=settings_.enabled?static_cast<std::size_t>(std::min(settings_.count,cap)):0;
    while(initialized_<count_){initialize(initialized_);++initialized_;}
    if(!count_||!std::isfinite(delta_seconds)||delta_seconds<=0)return;
    const float dt=std::min(delta_seconds,.25f);elapsed_+=dt;++updates_;
    // Two trigonometric calls per frame; particle phase values are cached at creation.
    const float sine=std::sin(static_cast<float>(std::fmod(elapsed_,1000.0))*.6f);
    const float cosine=std::cos(static_cast<float>(std::fmod(elapsed_,1000.0))*.6f);
    mouse_valid=mouse_valid&&std::isfinite(mouse.x)&&std::isfinite(mouse.y);
    for(std::size_t i=0;i<count_;++i){
        auto& p=particles_[i];
        const float drift=sine*p.cosine+cosine*p.sine;
        Vec2 velocity{p.velocity.x*20*settings_.speed,p.velocity.y*15*settings_.speed};
        if(theme_==1){velocity.x=(p.velocity.x*4+drift*4)*settings_.speed;velocity.y=(12+p.phase*16)*settings_.speed;}
        else if(theme_==7){velocity.x=(p.velocity.x*6+drift*10)*settings_.speed;velocity.y=(10+p.phase*20)*settings_.speed;}
        else if(theme_==3){velocity.x+=drift*2*settings_.speed;velocity.y*=.65f;}
        if(settings_.mouse_interaction&&mouse_valid){
            const float dx=p.position.x-mouse.x,dy=p.position.y-mouse.y;
            const float squared=dx*dx+dy*dy;
            if(squared>1&&squared<10000){
                const float dist=std::sqrt(squared),push=(1-dist*.01f)*12;
                velocity.x+=dx/dist*push;velocity.y+=dy/dist*push;
            }
        }
        p.position.x=wrapped(p.position.x+velocity.x*dt,width_);
        p.position.y=wrapped(p.position.y+velocity.y*dt,height_);
    }
}
void ParticleSystem::draw(ImDrawList* draw_list,ImVec2 origin,const RGBSettings& rgb,double time,
                          const AppearanceSettings& appearance,float alpha) const {
    if(!draw_list||!count_||width_<=0||height_<=0)return;
    alpha=bounded(alpha,0,1,0)*settings_.opacity;if(alpha<=0)return;
    const auto theme=ThemeManager::palette_for(theme_,appearance);
    auto color_for=[&](const Particle& particle){
        Color base{1,1,1,1};
        if(theme_==1)base={1,1,1,base[3]};
        else if(theme_==7)base={1,.65f+.2f*particle.phase,.79f+.12f*particle.phase,base[3]};
        else if(theme_==3)base=particle.phase<.5f?Color{.72f,.8f,1,base[3]}:Color{1,.72f,.88f,base[3]};
        else if(theme_==2)base=particle.phase<.5f?theme.primary:theme.secondary;
        else if(theme_==4||theme_==5||theme_==6)base=theme.accent;
        for(std::size_t i=0;i<3;++i)base[i]*=bounded(settings_.color[i],0,1,1);
        base[3]=bounded(settings_.color[3],0,1,1);
        return RGBManager::sample(rgb,time,particle.phase,base);
    };
    draw_list->PushClipRect(origin,{origin.x+width_,origin.y+height_},true);
    // Six fixed neighbors per particle: <=600 pair checks at the hard cap, no all-pairs loop.
    if(settings_.connections&&!performance_){
        constexpr std::size_t neighbors=6;
        for(std::size_t i=0;i<count_;++i)for(std::size_t offset=1;offset<=neighbors;++offset){
            const std::size_t j=i+offset;if(j>=count_)break;
            const auto& a=particles_[i];const auto& b=particles_[j];
            const float dx=a.position.x-b.position.x,dy=a.position.y-b.position.y,squared=dx*dx+dy*dy;
            constexpr float range=130;
            if(squared>=range*range)continue;
            const float opacity=(1-squared/(range*range))*alpha*.27f;
            draw_list->AddLine({origin.x+a.position.x,origin.y+a.position.y},{origin.x+b.position.x,origin.y+b.position.y},tint(color_for(a),opacity),.65f);
        }
    }
    const float radius=settings_.size;
    for(std::size_t i=0;i<count_;++i){
        const auto& particle=particles_[i];const ImVec2 p{origin.x+particle.position.x,origin.y+particle.position.y};
        const auto color=color_for(particle);const auto fill=tint(color,alpha);
        if((theme_==4||theme_==5)&&!performance_)draw_list->AddCircleFilled(p,radius*2.8f,tint(color,alpha*.10f),12);
        if(theme_==7){
            const float rotation=particle.phase*6.28318530718f+static_cast<float>(std::fmod(elapsed_,1000.0))*.12f;
            draw_list->AddEllipseFilled(p,{radius*1.6f,radius*.75f},fill,rotation,12);
        }else if(theme_==2){
            draw_list->AddQuadFilled({p.x,p.y-radius*1.4f},{p.x+radius,p.y},{p.x,p.y+radius*1.4f},{p.x-radius,p.y},fill);
        }else draw_list->AddCircleFilled(p,radius*(theme_==1?.8f:1),fill,12);
    }
    draw_list->PopClipRect();
}
}
