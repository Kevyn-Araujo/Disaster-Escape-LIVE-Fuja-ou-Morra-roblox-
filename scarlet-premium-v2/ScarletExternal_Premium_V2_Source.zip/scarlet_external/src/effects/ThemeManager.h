#pragma once
#include "config/settings.hpp"
namespace fe {
struct ThemePalette {Color primary{},secondary{},background{},text{},border{},accent{},card{},header{},sidebar{};};
class ThemeManager {
public:
    void update(const AppearanceSettings& settings,float dt,bool animate=true);
    const ThemePalette& palette() const noexcept {return palette_;}
    static ThemePalette palette_for(int theme,const AppearanceSettings& custom);
    static const char* name(int index) noexcept;
private:
    ThemePalette palette_{};
    bool initialized_{};
};
}
