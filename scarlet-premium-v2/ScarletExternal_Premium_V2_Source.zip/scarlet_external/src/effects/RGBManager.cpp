#include "effects/RGBManager.h"
#include <algorithm>
#include <cmath>
namespace fe {
namespace {
float bounded(float value,float lo,float hi,float fallback){return std::isfinite(value)?std::clamp(value,lo,hi):fallback;}
float wrapped(double value){return static_cast<float>(value-std::floor(value));}
struct HSV {float h{},s{},v{};};
HSV to_hsv(Color c){
    const float hi=std::max({c[0],c[1],c[2]}),lo=std::min({c[0],c[1],c[2]}),delta=hi-lo;
    HSV value;value.v=hi;value.s=hi>0?delta/hi:0;
    if(delta<=1e-7f)return value;
    if(hi==c[0])value.h=(c[1]-c[2])/delta;
    else if(hi==c[1])value.h=2+(c[2]-c[0])/delta;
    else value.h=4+(c[0]-c[1])/delta;
    value.h=wrapped(value.h/6);return value;
}
}
Color RGBManager::hsv(float h,float s,float v,float alpha){
    h=std::isfinite(h)?wrapped(h):0;s=bounded(s,0,1,0);v=bounded(v,0,1,0);alpha=bounded(alpha,0,1,1);
    const float sector=h*6;const int index=static_cast<int>(sector);const float fraction=sector-index;
    const float a=v*(1-s),b=v*(1-s*fraction),c=v*(1-s*(1-fraction));
    switch(index%6){case 0:return {v,c,a,alpha};case 1:return {b,v,a,alpha};case 2:return {a,v,c,alpha};case 3:return {a,b,v,alpha};case 4:return {c,a,v,alpha};default:return {v,a,b,alpha};}
}
Color RGBManager::sample(const RGBSettings& settings,double time,float phase,Color fallback){
    if(!settings.enabled)return fallback;
    for(float& value:fallback)value=bounded(value,0,1,1);
    if(!std::isfinite(time))time=0;
    if(!std::isfinite(phase))phase=0;
    const float speed=bounded(settings.speed,0,4,.15f),brightness=bounded(settings.brightness,0,1,.9f);
    // Reduce time before multiplication so even very large finite timestamps remain finite.
    const double cycle=std::fmod(time,1000000.0)*speed;
    const float t=wrapped(cycle+phase),wave=.5f+.5f*std::sin(t*6.28318530718f);
    const auto base=to_hsv(fallback);float hue=base.h,saturation=base.s,value=base.v;
    switch(std::clamp(settings.mode,0,5)){
    case 0:hue=settings.rainbow?t:base.h;saturation=settings.rainbow?.82f:base.s;value=settings.rainbow?1.0f:base.v*(.82f+.18f*wave);break;
    case 1:hue=settings.rainbow?wrapped(cycle*.35+phase):base.h;saturation=settings.rainbow?.75f:base.s;value=(settings.rainbow?1.0f:base.v)*(.50f+.50f*wave);break;
    case 2:hue=settings.rainbow?wrapped(cycle+phase+.12f*wave):base.h;saturation=settings.rainbow?.88f:base.s;value=(settings.rainbow?1.0f:base.v)*(.72f+.28f*wave);break;
    case 3:break;
    case 4:hue=settings.rainbow?wrapped(base.h+.22f*wave+phase*.15f):base.h;saturation=base.s;value=base.v*(.80f+.20f*wave);break;
    case 5:hue=settings.rainbow?wrapped(base.h+cycle*.12+phase):base.h;saturation=base.s;value=base.v*(.58f+.42f*wave*wave);break;
    }
    return hsv(hue,saturation,value*brightness,fallback[3]);
}
}
