#pragma once
#include "imgui.h"
#include <array>
#include <cstddef>
#include <cstdint>
namespace fe {
class UIEffects {
public:
    static constexpr std::size_t capacity=1024;
    void begin_frame(float delta_seconds,bool smooth) noexcept;
    float scalar(ImGuiID id,float target,float rate=16) noexcept;
    std::size_t size() const noexcept {return size_;}
private:
    struct Entry { ImGuiID id{};float value{};std::uint64_t touched{};bool used{}; };
    std::array<Entry,capacity> entries_{};
    std::uint64_t frame_{};
    std::size_t size_{};
    float delta_{};bool smooth_{true};
};
}
