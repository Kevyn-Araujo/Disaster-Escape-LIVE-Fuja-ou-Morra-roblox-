#include "effects/ThemeManager.h"
#include <algorithm>
#include <cmath>
namespace fe {
namespace {
Color rgb(float r,float g,float b){return {r,g,b,1};}
Color clean(Color c){for(float& value:c)value=std::isfinite(value)?std::clamp(value,0.0f,1.0f):1.0f;return c;}
Color lifted(Color value,float amount){for(int i=0;i<3;++i)value[i]=std::clamp(value[i]+amount,0.0f,1.0f);return value;}
void blend(Color& value,const Color& target,float factor){for(std::size_t i=0;i<4;++i)value[i]+=(target[i]-value[i])*factor;}
}
const char* ThemeManager::name(int index) noexcept {
    constexpr const char* names[]={"Scarlet Classic","Christmas","Halloween","Easter","Nuke","Cyberpunk","Ocean","Sakura","Midnight","Custom"};
    return names[std::clamp(index,0,9)];
}
ThemePalette ThemeManager::palette_for(int theme,const AppearanceSettings& custom){
    ThemePalette p;
    p.primary=rgb(1,.208f,.157f);p.secondary=rgb(.75f,.10f,.12f);p.background=rgb(.059f,.059f,.059f);
    p.text=rgb(.95f,.95f,.95f);p.border=rgb(.16f,.16f,.16f);p.accent=rgb(1,.65f,.2f);
    switch(std::clamp(theme,0,9)){
    case 1:p.primary=rgb(.90f,.16f,.20f);p.secondary=rgb(.12f,.62f,.32f);p.background=rgb(.035f,.065f,.045f);p.accent=rgb(.98f,.76f,.29f);p.border=rgb(.18f,.29f,.20f);break;
    case 2:p.primary=rgb(1,.43f,.10f);p.secondary=rgb(.59f,.24f,.86f);p.background=rgb(.055f,.035f,.065f);p.accent=rgb(.75f,.45f,1);p.border=rgb(.26f,.13f,.31f);break;
    case 3:p.primary=rgb(.75f,.59f,.94f);p.secondary=rgb(.97f,.63f,.78f);p.background=rgb(.12f,.11f,.17f);p.text=rgb(.98f,.95f,1);p.accent=rgb(.58f,.84f,.98f);p.border=rgb(.32f,.27f,.40f);break;
    case 4:p.primary=rgb(.44f,1,.15f);p.secondary=rgb(.16f,.66f,.09f);p.background=rgb(.025f,.045f,.025f);p.accent=rgb(.78f,1,.14f);p.border=rgb(.18f,.30f,.12f);break;
    case 5:p.primary=rgb(.76f,.26f,1);p.secondary=rgb(.06f,.89f,.97f);p.background=rgb(.035f,.025f,.075f);p.accent=rgb(.10f,.95f,1);p.border=rgb(.23f,.12f,.35f);break;
    case 6:p.primary=rgb(.16f,.73f,.98f);p.secondary=rgb(.07f,.45f,.70f);p.background=rgb(.025f,.065f,.115f);p.accent=rgb(.20f,.94f,.91f);p.border=rgb(.09f,.24f,.32f);break;
    case 7:p.primary=rgb(1,.54f,.75f);p.secondary=rgb(.79f,.30f,.58f);p.background=rgb(.065f,.035f,.055f);p.accent=rgb(1,.88f,.95f);p.border=rgb(.28f,.16f,.24f);break;
    case 8:p.primary=rgb(.39f,.51f,.72f);p.secondary=rgb(.24f,.31f,.45f);p.background=rgb(.025f,.03f,.045f);p.accent=rgb(.65f,.74f,.90f);p.border=rgb(.13f,.16f,.22f);break;
    case 9:p.primary=clean(custom.primary);p.secondary=clean(custom.secondary);p.background=clean(custom.background);p.text=clean(custom.text);p.border=clean(custom.border);p.accent=clean(custom.accent);break;
    default:break;
    }
    p.sidebar=lifted(p.background,.002f);p.card=lifted(p.background,.012f);p.header=lifted(p.background,.04f);
    return p;
}
void ThemeManager::update(const AppearanceSettings& settings,float dt,bool animate){
    const auto target=palette_for(settings.theme,settings);
    if(!initialized_||!animate){palette_=target;initialized_=true;return;}
    dt=std::isfinite(dt)?std::clamp(dt,0.0f,.25f):0;
    const float factor=1-std::exp(-12*dt);
    blend(palette_.primary,target.primary,factor);blend(palette_.secondary,target.secondary,factor);
    blend(palette_.background,target.background,factor);blend(palette_.text,target.text,factor);
    blend(palette_.border,target.border,factor);blend(palette_.accent,target.accent,factor);
    blend(palette_.sidebar,target.sidebar,factor);blend(palette_.card,target.card,factor);blend(palette_.header,target.header,factor);
}
}
