#include "effects/AnimationManager.h"
#include <algorithm>
#include <cmath>
namespace fe {
float AnimationManager::damp(float current,float target,float delta_seconds,float rate) noexcept {
    if(!std::isfinite(target))target=0;
    if(!std::isfinite(current))current=target;
    if(!std::isfinite(delta_seconds)||delta_seconds<=0)return current;
    if(!std::isfinite(rate)||rate<=0)return target;
    const float factor=-std::expm1(-rate*std::min(delta_seconds,.25f));
    const float next=current+(target-current)*factor;
    return std::abs(next-target)<.0001f?target:next;
}
void AnimationManager::update(bool visible,float delta_seconds,const AnimationSettings& settings) {
    if(!settings.enabled||settings.disable_all){value_=visible?1.0f:0.0f;return;}
    if(!std::isfinite(delta_seconds)||delta_seconds<=0)return;
    const float duration=std::isfinite(settings.duration_ms)?std::clamp(settings.duration_ms,50.0f,1000.0f)*.001f:.22f;
    const float speed=std::isfinite(settings.speed)?std::clamp(settings.speed,.25f,4.0f):1.0f;
    const float step=std::min(delta_seconds,.25f)*speed/(duration*(visible?1.0f:.8f));
    value_=std::clamp(value_+(visible?step:-step),0.0f,1.0f);
}
float AnimationManager::progress() const noexcept {
    // A cubic ease-out keeps position/scale changes continuous when reversing mid-flight.
    const float remaining=1-value_;
    return 1-remaining*remaining*remaining;
}
}
