#pragma once
#include "config/settings.hpp"
namespace fe {
class RGBManager {
public:
    static Color sample(const RGBSettings&,double time,float phase,Color fallback);
    static Color hsv(float h,float s,float v,float alpha=1);
};
}
