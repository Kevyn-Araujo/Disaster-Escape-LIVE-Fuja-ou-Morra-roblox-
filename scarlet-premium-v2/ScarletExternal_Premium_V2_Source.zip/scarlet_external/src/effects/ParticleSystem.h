#pragma once
#include "config/settings.hpp"
#include "core/types.hpp"
#include "imgui.h"
#include <array>
#include <cstddef>
#include <cstdint>
namespace fe {
class ParticleSystem {
public:
    struct Particle {Vec2 position{},velocity{};float sine{},cosine{},phase{};};
    static constexpr std::size_t maximum=100;
    void update(float delta_seconds,float width,float height,const ParticleSettings& settings,
                int theme,Vec2 mouse,bool mouse_valid,bool performance);
    void draw(ImDrawList* draw_list,ImVec2 origin,const RGBSettings& rgb,double time,
              const AppearanceSettings& appearance,float alpha) const;
    std::size_t count() const noexcept {return count_;}
    std::uint64_t update_count() const noexcept {return updates_;}
    const std::array<Particle,maximum>& particles() const noexcept {return particles_;}
private:
    void initialize(std::size_t index);
    std::array<Particle,maximum> particles_{};
    std::size_t count_{},initialized_{};
    std::uint64_t updates_{};
    float width_{},height_{};double elapsed_{};
    ParticleSettings settings_{};
    int theme_{};bool performance_{};
};
}
