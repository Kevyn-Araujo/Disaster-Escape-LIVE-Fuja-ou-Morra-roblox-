# Scarlet Premium UI V2 — implementação e validação

## Atualização incremental

O projeto existente foi modificado diretamente. Não foi recriado. Hashes confirmam preservação de `auto_chest.cpp`, `path_planner.cpp` e `filters.cpp`. O corpo de `ChestESP::render` também permaneceu byte a byte igual. Evidência: `docs/test-results/v2/preserved.json`.

## Implementação disponível

| Área | Implementado |
|---|---|
| Alpha | Background85%, sidebar90%, cards88%, headers92% por padrão; sliders individuais; superfícies sem fundo opaco oculto; texto independente do alpha do fundo. |
| Composição live | DirectComposition, BGRA flip swapchain premultiplicado, clear transparente e blend padrão ImGui. Sem blur ou cópia CPU do framebuffer. |
| RGB | Seis modos HSV, velocidade, brilho e alvos independentes. Desligar restaura a paleta selecionada. |
| Temas | Scarlet Classic, Christmas, Halloween, Easter, Nuke, Cyberpunk, Ocean, Sakura, Midnight e Custom, com prévias, transição e escolha salva automaticamente. |
| Partículas | Array fixo100, padrão50, movimento DeltaTime, cores, tamanho/opacidade, conexões limitadas e reação discreta ao mouse; neve/pétalas/cores sazonais. |
| Animações | Abertura padrão220ms, fade/scale/slide/ease out, fechamento inverso curto, transições de controles e indicador de aba. Desativação global disponível. |
| Perfil | Posição inferior esquerda preservada, avatar circular, nome/status locais configuráveis, cores do tema e hover. |
| ESP | Chapéu cônico, bambolê 3D, boxes3D/cantos/gradiente, outline/glow e RGB de ossos/snaplines; dados observados obrigatórios. |
| JSON | Persistência completa e compatibilidade com arquivos anteriores sem campos premium; mesma validação atômica existente. ConfigManager é uma fachada, não outro serializador. |
| Teste independente | `--esp-preview` / `Testar-ESP.bat`, câmera aproximada sobre mock explícito; TAB/ESC/F4 locais. |

O glow é um halo leve do contorno projetado, não uma inferência de malha/silhueta corporal. Cabeça, cintura e oito cantos de bounds são campos opcionais. A ausência de qualquer um omite o efeito que depende dele; o mock fornece esses dados para seus corpos definidos.

## Testes executados

- **19/19 grupos existentes do núcleo passaram**, incluindo filtros, navegação, abertura confirmada, falhas, emergência e JSON.
- **12/12 grupos novos premium passaram**: roundtrip de todos os campos, compatibilidade anterior, validação de perfil/JSON, temas, RGB, tempo de animação a30/60/144Hz, cache limitado, partículas, alpha/geometria, dados ESP ausentes e modo leve.
- **Controles reais ImGui passaram**, usando eventos de mouse: funções anteriores, seleção de tema/autosave, opacidade, RGB, partículas, chapéu, bambolê, box3D, animação de saída e ausência de updates de partículas após fechamento completo e reabertura após intervalo longo sem pular a animação.
- **Coleta simulada passou**: três aberturas confirmadas, sem avisos ou erros no baseline.
- **CTest portátil4/4 passou**; ASan/UBSan com detecção de vazamentos também4/4 passou sem diagnóstico.
- A regressão final adicional de ESP confirmou velocidade RGB zero estática e brilho zero preto, tanto nativa quanto com sanitizadores.
- **Build/link Windows x64 passou** para aplicação, headless, testes existentes/premium, preview e rastreador de janela. A versão usa Windows SDK/DirectComposition e target Windows10/11.

Saídas completas em `docs/test-results/v2/`. Compiladores: GCC14.2 nativo e LLVM-MinGW/Clang18.1.8 para Windows, C++20, CMake4.4.4, Ninja1.13.2. O caminho VS2022 está documentado no README; MSVC não foi executado neste Linux.

## Prévia visual

`docs/preview/v2/` contém imagens do **mesmo código Dear ImGui**, rasterizado em CPU: clássico, Cyberpunk/RGB, Christmas/Appearance e efeitos de ESP sobre o mock. Não são capturas de Fortnite nem um menu HTML.

Foram inspecionados layout, cores, legibilidade, perfil inferior esquerdo, conexões discretas, controles, cone/anéis e boxes. Não se afirma fidelidade pixel a pixel à fonte/logo originais, que não foram fornecidos como assets.

## Limites explícitos da validação

**Não houve execução gráfica no Windows ou em Fortnite neste ambiente Linux.** A transição de estilos de janela, DirectComposition, foco/click-through entre processos, múltiplos monitores e apresentação real precisam de execução Windows. A compatibilidade das APIs foi revisada e o alvo foi compilado; isso não substitui o teste visual/runtime.

Sem uma integração autorizada, o modo padrão continua sem entidades reais e sem coleta sobre Fortnite. Nenhuma fonte de memória, bypass, driver ou mecanismo de evasão foi adicionado.

Não foi medido impacto de FPS/CPU/GPU em Fortnite. Os limites abaixo são garantias estruturais/testadas do código, não um benchmark de desempenho do jogo.

## Limites de custo

- Máximo100 partículas; Performance Mode reduz para25 e retira conexões.
- Até seis vizinhos por partícula: no máximo600 verificações por frame, sem busca all-pairs.
- Círculo ESP pré-calculado32 segmentos, reduzido a16 no modo leve; arrays fixos por forma.
- Fill e glow ESP suprimidos no modo leve/Disable Heavy Effects; glow de tema usa somente camadas finas, sem blur.
- Cache de microanimações fixo1024 entradas.
- Fontes carregadas uma vez; recursos DirectX reutilizados e resize só quando necessário.
- Partículas, temas e microcontroles não são atualizados após o menu terminar de fechar. ESP ativo com provider válido continua sendo desenhado.
- Timings usam DeltaTime; não se espera uma quantidade fixa de frames para concluir animações.

## Checklist para executar no Windows

1. Extraia todo o ZIP e mantenha assets/fonts junto ao executável.
2. Rode `Iniciar-DEMO.bat`, abra Settings e teste as seis seções da coluna direita. Em Appearance, escolha temas; confira autosave e Load Config.
3. Abra Player ESP → Hat / Hoop e Extra ESP; use Visual Test. Na janela separada, TAB abre menu; ESC para; F4 inicia/para. Ela não disputa os atalhos globais do processo principal.
4. No modo live com Fortnite em janela/borderless, teste INSERT, resize/minimizar/restaurar, alpha e clique no jogo durante o fechamento. Confirme No data source quando não há provider real.
5. Teste Performance Mode, Disable Heavy Effects e Disable Animations. Compare custos em hardware real antes de tirar conclusões de FPS.
6. Rode fe_tests.exe, fe_premium_tests.exe e ScarletWindowTests.exe no Windows. O teste de rastreamento usa alvo controlado, não o jogo.

O preview lê a configuração ao abrir. Mudanças salvas por outra instância são aplicadas à instância atual por Load Config.
