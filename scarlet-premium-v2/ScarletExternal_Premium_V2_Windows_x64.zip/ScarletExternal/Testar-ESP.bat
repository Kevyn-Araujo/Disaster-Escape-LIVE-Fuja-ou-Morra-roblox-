@echo off
cd /d "%~dp0"
start "" "%~dp0ScarletExternal.exe" --esp-preview
