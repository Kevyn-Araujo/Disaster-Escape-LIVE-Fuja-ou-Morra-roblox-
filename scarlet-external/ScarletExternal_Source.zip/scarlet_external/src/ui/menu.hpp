#pragma once
#include "core/types.hpp"
#include <filesystem>
#include <string>
namespace fe {
struct Settings;
class IControlSink;
class AutoChestMachine;
class Logger;
struct MenuState {
    bool visible{false};
    int page{};
    Vec2 offset{};
    std::string config_status;
};
struct RuntimeStatus {
    bool demo{}, attached{}, data_available{};
    std::string provider_name{"Sem provider autorizado"};
    std::string window_status{"Aguardando Fortnite"};
    GameSnapshot snapshot;
};
bool load_scarlet_fonts(const std::filesystem::path& assets);
void apply_scarlet_style();
void draw_menu(MenuState&,Settings&,IControlSink&,AutoChestMachine&,Logger&,
               const std::filesystem::path&,const RuntimeStatus&);
}
