#include "ui/menu.hpp"
#include "automation/auto_chest.hpp"
#include "config/settings.hpp"
#include "esp/filters.hpp"
#include "utils/logger.hpp"
#include "imgui.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <string>

namespace fe {
namespace {
ImFont* text_font{};
ImFont* logo_font{};
constexpr ImU32 red=IM_COL32(255,53,40,255),white=IM_COL32(242,242,242,255);
constexpr ImU32 muted=IM_COL32(107,107,107,255),edge=IM_COL32(28,28,28,255);
constexpr ImU32 bg=IM_COL32(15,15,15,255),body=IM_COL32(18,18,18,255),header=IM_COL32(25,25,25,255);
struct Canvas {
    ImDrawList* d;
    ImVec2 origin;
    float scale;
    ImVec2 p(float x,float y) const {return {origin.x+x*scale,origin.y+y*scale};}
    void rect(float x,float y,float w,float h,ImU32 color,float rounding=0) const {
        d->AddRectFilled(p(x,y),p(x+w,y+h),color,rounding*scale);
    }
    void text(float x,float y,const std::string& value,ImU32 color=white,float size=21,ImFont* font=nullptr) const {
        d->AddText(font?font:text_font,size*scale,p(x,y),color,value.c_str());
    }
    void line(float x,float y,float x2,float y2,ImU32 color,float weight=1) const {
        d->AddLine(p(x,y),p(x2,y2),color,weight*scale);
    }
    bool hit(const std::string& id,float x,float y,float w,float h) const {
        ImGui::SetCursorScreenPos(p(x,y));
        ImGui::InvisibleButton(id.c_str(),{w*scale,h*scale});
        return ImGui::IsItemClicked();
    }
    void icon(int kind,float x,float y,ImU32 color,float size=24) const {
        const float k=size/24;
        auto l=[&](float a,float b,float c,float e,float t=2){line(x+a*k,y+b*k,x+c*k,y+e*k,color,t);};
        auto circle=[&](float a,float b,float radius,bool filled){
            if(filled)d->AddCircleFilled(p(x+a*k,y+b*k),radius*k*scale,color,20);
            else d->AddCircle(p(x+a*k,y+b*k),radius*k*scale,color,20,2*scale);
        };
        if(kind==0) {circle(12,4,3,true);l(12,9,12,16);l(12,10,6,14);l(12,10,18,14);l(12,16,7,23);l(12,16,17,23);}
        else if(kind==1) {
            d->AddRect(p(x+2*k,y+7*k),p(x+22*k,y+22*k),color,2*scale,0,2*scale);
            l(2,13,22,13);l(9,10,9,16);l(15,10,15,16);l(5,7,7,2);l(7,2,17,2);l(17,2,19,7);
        } else if(kind==2) {
            circle(4,20,3,false);circle(20,4,3,false);l(7,20,16,20);l(16,20,17,18);l(17,18,17,13);l(17,13,7,13);l(7,13,7,5);l(7,5,16,5);
        } else if(kind==3) {
            circle(12,12,7,false);circle(12,12,2,true);
            for(int i=0;i<8;++i){float a=static_cast<float>(i)*.785398f;l(12+8*std::cos(a),12+8*std::sin(a),12+11*std::cos(a),12+11*std::sin(a),3);}
        } else if(kind==4) {
            d->AddBezierCubic(p(x,y+12*k),p(x+8*k,y-2*k),p(x+16*k,y-2*k),p(x+24*k,y+12*k),color,2*scale);
            d->AddBezierCubic(p(x,y+12*k),p(x+8*k,y+26*k),p(x+16*k,y+26*k),p(x+24*k,y+12*k),color,2*scale);
            circle(12,12,4,true);
        } else {circle(12,12,10,false);l(12,6,12,13);circle(12,18,1,true);}
    }
};
void card(const Canvas& c,const char* title,int icon,float x,float y,float w,float h) {
    c.rect(x,y,w,h,body,8);c.rect(x,y,w,46,header,8);c.rect(x,y+32,w,14,header);
    c.icon(icon,x+16,y+11,red,23);c.text(x+50,y+10,title,white,24);
}
void toggle(const Canvas& c,const char* label,bool& value,float x,float y,float w,bool locked=false) {
    const bool pressed=c.hit(label,x,y,w,34);
    if(pressed&&!locked)value=!value;
    const bool hover=ImGui::IsItemHovered();
    if(hover&&!locked)c.rect(x-4,y,w+8,34,IM_COL32(24,24,24,255),4);
    c.text(x,y+4,label,locked?muted:IM_COL32(184,184,184,255),20);
    const float sx=x+w-44;
    const ImU32 track=value?(locked?IM_COL32(105,39,34,255):red):IM_COL32(32,32,32,255);
    c.rect(sx,y+8,44,21,track,11);
    c.d->AddCircleFilled(c.p(sx+(value?33:11),y+18.5f),8*c.scale,
                        value?white:IM_COL32(67,67,67,255),24);
    if(locked&&hover)ImGui::SetTooltip("Regra obrigatoria; este filtro nao pode ser desativado.");
}
void slider(const Canvas& c,const char* label,float& value,float lo,float hi,float x,float y,float w,const char* unit) {
    c.text(x,y,label,IM_COL32(184,184,184,255),20);
    char number[48];std::snprintf(number,sizeof(number),"%.0f%s",value,unit);
    const float tw=text_font->CalcTextSizeA(18*c.scale,1000,0,number).x/c.scale;
    c.text(x+w-tw,y+2,number,muted,18);
    const float tx=x+8,ty=y+38,track=w-16;
    c.hit(std::string(label)+"##slider",x,y+23,w,30);
    if(ImGui::IsItemActive()) {
        const float position=(ImGui::GetIO().MousePos.x-c.p(tx,ty).x)/(track*c.scale);
        value=lo+std::clamp(position,0.0f,1.0f)*(hi-lo);
    }
    const float t=std::clamp((value-lo)/(hi-lo),0.0f,1.0f);
    c.rect(tx,ty-5,track,10,IM_COL32(58,58,58,255),5);
    if(t>0)c.rect(tx,ty-5,track*t,10,red,5);
    c.d->AddCircleFilled(c.p(tx+track*t,ty),9*c.scale,white,24);
}
bool button(const Canvas& c,const char* label,float x,float y,float w,float h=36,bool accent=false) {
    const bool clicked=c.hit(label,x,y,w,h);
    c.rect(x,y,w,h,accent?red:(ImGui::IsItemHovered()?IM_COL32(42,42,42,255):IM_COL32(29,29,29,255)),5);
    const float size=19*c.scale;
    const auto dim=text_font->CalcTextSizeA(size,1000,0,label);
    c.d->AddText(text_font,size,{c.p(x+w*.5f,y).x-dim.x*.5f,c.p(x,y+h*.5f).y-dim.y*.5f},white,label);
    return clicked;
}
const char* key_name(int value) {
    switch(value){case 0x2D:return "INSERT";case 0x24:return "HOME";case 0x74:return "F5";case 0x75:return "F6";case 0x76:return "F7";case 0x77:return "F8";case 0x78:return "F9";case 0x79:return "F10";default:return "F11";}
}
void key_row(const Canvas& c,const char* label,int& key,const int* choices,int count,float x,float y,float w) {
    c.text(x,y+7,label,IM_COL32(184,184,184,255),20);
    if(button(c,key_name(key),x+w-88,y,88)) {
        int index=0;for(int i=0;i<count;++i)if(choices[i]==key)index=i;
        key=choices[(index+1)%count];
    }
}
void color_row(const Canvas& c,const char* label,Color& color,float x,float y,float w) {
    c.text(x,y+5,label,IM_COL32(184,184,184,255),20);
    if(c.hit(std::string(label)+"##color",x+w-38,y+5,38,22))ImGui::OpenPopup(label);
    c.rect(x+w-38,y+6,38,21,ImGui::ColorConvertFloat4ToU32({color[0],color[1],color[2],color[3]}),4);
    if(ImGui::BeginPopup(label)){ImGui::ColorPicker4(label,color.data(),ImGuiColorEditFlags_AlphaBar);ImGui::EndPopup();}
}
void automation(const Canvas& c,Settings& settings,const RuntimeStatus& runtime,float x,float y,float w) {
    auto& a=settings.automation;
    const bool before=a.enabled;toggle(c,"Enable Auto Chest",a.enabled,x,y,w);
    if(!before&&a.enabled&&!runtime.data_available)a.enabled=false;
    toggle(c,"AFK Mode",a.afk_mode,x,y+35,w);
    toggle(c,"Auto Navigate",a.auto_navigate,x,y+70,w);
    toggle(c,"Auto Interact",a.auto_interact,x,y+105,w);
    toggle(c,"Auto Retry",a.auto_retry,x,y+140,w);
    toggle(c,"Stuck Recovery",a.stuck_recovery,x,y+175,w);
}
}

bool load_scarlet_fonts(const std::filesystem::path& assets) {
    auto& io=ImGui::GetIO();ImFontConfig config;config.OversampleH=3;config.OversampleV=2;
    const auto regular=assets/"fonts/Barlow-SemiBold.ttf",logo=assets/"fonts/KaushanScript-Regular.ttf";
    bool ok=std::filesystem::exists(regular)&&std::filesystem::exists(logo);
    if(std::filesystem::exists(regular))text_font=io.Fonts->AddFontFromFileTTF(regular.string().c_str(),24,&config);
    if(!text_font)text_font=io.Fonts->AddFontDefault();
    if(std::filesystem::exists(logo))logo_font=io.Fonts->AddFontFromFileTTF(logo.string().c_str(),76,&config);
    if(!logo_font){logo_font=text_font;ok=false;}io.FontDefault=text_font;
    return ok;
}
void apply_scarlet_style() {
    auto& s=ImGui::GetStyle();s.WindowPadding={0,0};s.WindowBorderSize=0;s.WindowRounding=10;
    s.FrameRounding=5;s.PopupRounding=6;s.ScrollbarSize=5;s.ScrollbarRounding=4;s.ItemSpacing={8,8};
    for(auto& color:s.Colors)color=ImVec4(.12f,.12f,.12f,1);
    s.Colors[ImGuiCol_Text]={.94f,.94f,.94f,1};s.Colors[ImGuiCol_WindowBg]={.059f,.059f,.059f,1};
    s.Colors[ImGuiCol_PopupBg]={.08f,.08f,.08f,1};s.Colors[ImGuiCol_Border]={.15f,.15f,.15f,1};
    s.Colors[ImGuiCol_FrameBg]={.15f,.15f,.15f,1};s.Colors[ImGuiCol_FrameBgHovered]={.2f,.2f,.2f,1};
    s.Colors[ImGuiCol_FrameBgActive]={.25f,.25f,.25f,1};s.Colors[ImGuiCol_SliderGrab]={1,.208f,.157f,1};
    s.Colors[ImGuiCol_SliderGrabActive]={1,.208f,.157f,1};s.Colors[ImGuiCol_CheckMark]={1,.208f,.157f,1};
    s.Colors[ImGuiCol_Button]={.14f,.14f,.14f,1};s.Colors[ImGuiCol_ButtonHovered]={.22f,.22f,.22f,1};
    s.Colors[ImGuiCol_Header]={.2f,.1f,.1f,1};s.Colors[ImGuiCol_HeaderHovered]={.3f,.12f,.1f,1};
    s.Colors[ImGuiCol_NavCursor]={1,.208f,.157f,1};
}
void draw_menu(MenuState& menu,Settings& settings,IControlSink& controls,AutoChestMachine& machine,
               Logger& logger,const std::filesystem::path& config_path,const RuntimeStatus& runtime) {
    if(!menu.visible)return;
    const auto display=ImGui::GetIO().DisplaySize;
    const float scale=std::min({1.0f,(display.x-10)/1237.0f,(display.y-10)/850.0f});
    if(scale<=0)return;
    const ImVec2 size{1237*scale,850*scale};
    const float ox=std::clamp((display.x-size.x)*.5f+menu.offset.x,0.0f,std::max(0.0f,display.x-size.x));
    const float oy=std::clamp((display.y-size.y)*.5f+menu.offset.y,0.0f,std::max(0.0f,display.y-size.y));
    ImGui::SetNextWindowPos({ox,oy});ImGui::SetNextWindowSize(size);
    constexpr auto flags=ImGuiWindowFlags_NoDecoration|ImGuiWindowFlags_NoSavedSettings|ImGuiWindowFlags_NoMove|ImGuiWindowFlags_NoScrollWithMouse|ImGuiWindowFlags_NoScrollbar;
    ImGui::Begin("Scarlet##root",nullptr,flags);
    Canvas c{ImGui::GetWindowDrawList(),{ox,oy},scale};
    c.rect(0,0,1237,850,bg,10);c.d->AddRect(c.p(0,0),c.p(1237,850),edge,10*scale);
    c.line(245,0,245,850,edge,2);c.line(1095,0,1095,850,edge,2);c.line(245,81,1095,81,edge,2);
    c.text(25,16,"Scarlet",red,90,logo_font);
    c.text(27,124,"Visuals",muted,20);
    const char* pages[]={"Player ESP","Chest ESP","Auto Chest AFK","Settings"};
    const float nav_y[]={157,220,374,554};
    c.text(27,340,"Automation",muted,20);c.text(27,520,"Configuration",muted,20);
    for(int i=0;i<4;++i){
        const bool clicked=c.hit(std::string("nav_")+pages[i],18,nav_y[i],209,48);
        const bool selected=menu.page==i;
        if(selected||ImGui::IsItemHovered())c.rect(18,nav_y[i],192,48,selected?body:IM_COL32(21,21,21,255),5);
        c.icon(i,29,nav_y[i]+11,selected?red:muted,26);
        c.text(74,nav_y[i]+12,pages[i],selected?white:muted,i==2?18.0f:22.0f);
        if(selected)c.rect(191,nav_y[i]+10,10,28,red,6);
        if(clicked)menu.page=i;
    }
    // Header is the only draggable region; controls never drag the panel.
    c.hit("panel_drag",247,0,845,80);
    if(ImGui::IsItemActive()&&ImGui::IsMouseDragging(ImGuiMouseButton_Left)){
        menu.offset.x+=ImGui::GetIO().MouseDelta.x;menu.offset.y+=ImGui::GetIO().MouseDelta.y;
    }
    c.text(261,36,"Scarlet",muted,23);c.text(338,36,">",muted,23);
    c.icon(menu.page,357,37,red,22);c.text(385,36,pages[menu.page],red,23);
    const float end_x=385+text_font->CalcTextSizeA(23*scale,2000,0,pages[menu.page]).x/scale;
    c.text(end_x+15,36,">",muted,23);c.text(end_x+40,36,menu.page==3?"Preferences":"Overview",muted,23);
    // Narrow right-hand rail, retained from the supplied visual reference.
    for(int i=0;i<3;++i){const float y=44+i*76.0f;
        const int page=i==0?0:i==1?1:3;
        if(c.hit(std::string("rail_")+std::to_string(i),1124,y,64,64))menu.page=page;
        c.d->AddRect(c.p(1124,y),c.p(1188,y+64),IM_COL32(44,44,44,255),10*scale,0,2*scale);
        c.icon(i==0?0:i==1?1:3,1143,y+18,menu.page==page?red:muted,27);
    }
    c.d->AddCircleFilled(c.p(61,752),35*scale,IM_COL32(30,30,30,255),40);
    c.text(43,720,"S",red,47,logo_font);
    c.text(110,732,runtime.demo?"Test Environment":"Fortnite",white,21);
    c.text(110,757,runtime.demo?"MOCK / DEMO":runtime.data_available?"Data connected":"No data source",runtime.data_available?IM_COL32(87,215,125,255):red,17);
    constexpr float lx=260,rx=664,cw=398;
    auto& v=settings.visuals;auto& a=settings.automation;
    if(menu.page<=1){
        card(c,"Player ESP",0,lx,97,cw,400);
        toggle(c,"Enable Player ESP",v.players,lx+19,153,cw-50);
        toggle(c,"Box ESP 2D",v.boxes,lx+19,190,cw-50);
        toggle(c,"Skeleton ESP",v.skeleton,lx+19,227,cw-50);
        toggle(c,"Player Names",v.names,lx+19,264,cw-50);
        toggle(c,"Distance ESP",v.distance,lx+19,301,cw-50);
        toggle(c,"Health Bar",v.health,lx+19,338,cw-50);
        toggle(c,"Shield Bar",v.shield,lx+19,375,cw-50);
        toggle(c,"Snaplines",v.snaplines,lx+19,412,cw-50);
        card(c,"ESP Colors",4,lx,503,cw,322);
        slider(c,"Max Player Distance",v.max_player_distance_m,50,1000,lx+19,562,cw-50," m");
        color_row(c,"Player Color",v.player_color,lx+19,622,cw-50);
        color_row(c,"Skeleton Color",v.skeleton_color,lx+19,660,cw-50);
        color_row(c,"Chest Color",v.chest_color,lx+19,698,cw-50);
        color_row(c,"Nearest Chest Color",v.nearest_color,lx+19,736,cw-50);
        card(c,"Chest ESP",1,rx,97,cw,434);
        toggle(c,"Enable Chest ESP",v.chests,rx+20,153,cw-50);
        bool closed=true;toggle(c,"Closed Chests Only",closed,rx+20,190,cw-50,true);
        toggle(c,"Chest Markers",v.chest_marker,rx+20,227,cw-50);
        toggle(c,"Chest Distance",v.chest_distance,rx+20,264,cw-50);
        toggle(c,"Nearest Chest Highlight",v.nearest_highlight,rx+20,301,cw-50);
        toggle(c,"Chest Counter",v.chest_counter,rx+20,338,cw-50);
        slider(c,"Max Chest Distance",v.max_chest_distance_m,50,1000,rx+20,389,cw-50," m");
        c.text(rx+20,477,runtime.data_available?"Provider data available":"Waiting for authorized data",muted,17);
        card(c,"Auto Chest AFK",2,rx,536,cw,289);
        automation(c,settings,runtime,rx+20,590,cw-50);
    } else if(menu.page==2){
        card(c,"Auto Chest AFK",2,lx,97,cw,400);
        automation(c,settings,runtime,lx+20,153,cw-50);
        bool nearest=true;toggle(c,"Nearest Chest Selection",nearest,lx+20,368,cw-50,true);
        slider(c,"Search Distance",a.max_distance_m,50,1000,lx+20,415,cw-50," m");
        card(c,"Recovery",2,lx,503,cw,322);
        slider(c,"Movement Speed",a.speed_mps,.5f,20,lx+20,560,cw-50," m/s");
        slider(c,"Stuck Timeout",a.stuck_timeout_s,.25f,15,lx+20,632,cw-50," s");
        slider(c,"Verification Timeout",a.verification_timeout_s,.25f,15,lx+20,704,cw-50," s");
        card(c,"Session",4,rx,97,cw,434);
        c.text(rx+20,160,"Provider",muted,19);c.text(rx+20,191,runtime.demo?"MockGameDataProvider":"Unavailable",white,22);
        c.text(rx+20,242,"Automation State",muted,19);c.text(rx+20,274,state_name(machine.state()),red,23);
        c.text(rx+20,328,"Confirmed Openings",muted,19);c.text(rx+20,358,std::to_string(machine.completed_count()),white,28);
        const auto target=machine.target();c.text(rx+20,415,target?"Target: "+std::to_string(*target):"Target: none",muted,19);
        if(button(c,"STOP",rx+20,471,cw-40,37,true)){machine.emergency_stop(controls);a.enabled=false;}
        card(c,"Hotkeys",3,rx,536,cw,289);
        constexpr int starts[]={0x74,0x75,0x78};constexpr int stops[]={0x77,0x79,0x7A};
        key_row(c,"Start / Stop",settings.overlay.start_stop_key,starts,3,rx+20,599,cw-50);
        key_row(c,"Emergency Stop",settings.overlay.emergency_key,stops,3,rx+20,650,cw-50);
        c.text(rx+20,725,runtime.data_available?"Control sink available":"No live control sink connected",muted,17);
    } else {
        card(c,"Settings",3,lx,97,cw,400);
        constexpr int menus[]={0x2D,0x24,0x76};key_row(c,"Menu Hotkey",settings.overlay.menu_key,menus,3,lx+20,160,cw-50);
        float fps=static_cast<float>(settings.overlay.fps_limit);slider(c,"FPS Limit",fps,15,240,lx+20,220,cw-50," FPS");settings.overlay.fps_limit=static_cast<int>(std::round(fps));
        toggle(c,"Vertical Sync",settings.overlay.vsync,lx+20,291,cw-50);
        if(button(c,"Save Config",lx+20,350,166,39)){std::string error;bool ok=save_settings(config_path,settings,error);menu.config_status=ok?"JSON configuration saved":error;logger.log(ok?LogLevel::Info:LogLevel::Error,menu.config_status);}
        if(button(c,"Load Config",lx+204,350,166,39)){std::string error;bool ok=load_settings(config_path,settings,error);if(ok)machine.emergency_stop(controls);menu.config_status=ok?"JSON loaded; automation stopped":error;logger.log(ok?LogLevel::Info:LogLevel::Error,menu.config_status);}
        c.text(lx+20,430,"Configuration format: JSON",muted,18);
        card(c,"Overlay",4,rx,97,cw,434);
        c.text(rx+20,159,"Window",muted,19);c.text(rx+20,191,runtime.attached?"Fortnite window detected":runtime.demo?"Standalone demo":"Waiting for Fortnite",white,21);
        c.text(rx+20,254,"Rendering",muted,19);c.text(rx+20,286,"Win32 / DirectX 11 / ImGui",white,21);
        c.text(rx+20,349,"Input",muted,19);c.text(rx+20,381,"Click-through when menu closes",white,20);
        c.text(rx+20,453,"Windowed / Borderless",muted,18);
        card(c,"Debug Logs",5,lx,503,802,322);
        ImGui::SetCursorScreenPos(c.p(lx+20,560));
        ImGui::BeginChild("logs",{762*scale,240*scale},false);
        ImGui::PushFont(text_font);ImGui::SetWindowFontScale(.72f*scale);
        for(const auto& entry:logger.entries())ImGui::TextWrapped("%s  %s",entry.time.c_str(),entry.message.c_str());
        if(!menu.config_status.empty())ImGui::TextWrapped("%s",menu.config_status.c_str());
        ImGui::SetWindowFontScale(1);ImGui::PopFont();ImGui::EndChild();
    }
    normalize_settings(settings);
    ImGui::End();
}
} // namespace fe
