// C++20 | main.cpp | Windows x64 / MSVC 2022. Default provider intentionally has no live data.
#include "overlay/window_tracker.hpp"
#include "overlay/dx11_overlay.hpp"
#include "automation/auto_chest.hpp"
#include "data/mock_game_data_provider.hpp"
#include "data/unavailable_game_data_provider.hpp"
#include "config/settings.hpp"
#include "utils/logger.hpp"
#include <shellapi.h>
#include <memory>
#include <vector>
#include <string>
#include <stdexcept>
namespace {
std::filesystem::path executable_directory(){
    std::vector<wchar_t> path(32768);const auto size=GetModuleFileNameW(nullptr,path.data(),static_cast<DWORD>(path.size()));
    if(size==0||size>=path.size())throw std::runtime_error("Nao foi possivel localizar o executavel.");
    return std::filesystem::path(std::wstring(path.data(),size)).parent_path();
}
}
int WINAPI wWinMain(HINSTANCE,HINSTANCE,PWSTR,int){
    try {
        using DpiFunction=BOOL(WINAPI*)(DPI_AWARENESS_CONTEXT);
        const auto set_dpi=reinterpret_cast<DpiFunction>(GetProcAddress(GetModuleHandleW(L"user32.dll"),"SetProcessDpiAwarenessContext"));
        if(set_dpi)set_dpi(DPI_AWARENESS_CONTEXT_PER_MONITOR_AWARE_V2);else SetProcessDPIAware();
        int count{};LPWSTR* raw=CommandLineToArgvW(GetCommandLineW(),&count);
        if(!raw)throw std::runtime_error("Falha ao analisar argumentos.");
        std::vector<std::wstring> args;for(int i=1;i<count;++i)args.emplace_back(raw[i]);LocalFree(raw);
        bool demo=false;std::filesystem::path config;
        for(std::size_t i=0;i<args.size();++i){
            if(args[i]==L"--demo")demo=true;
            else if(args[i]==L"--config"&&i+1<args.size())config=args[++i];
            else {MessageBoxW(nullptr,L"ScarletExternal.exe [--demo] [--config arquivo.json]\n\nINSERT: menu | F6: iniciar/parar | F8: emergencia\nSem --demo, aguarda Fortnite. Tray: clique direito para sair.\nNao inclui provider real de dados do jogo.",L"Scarlet External",MB_OK);return args[i]==L"--help"?0:2;}
        }
        const auto base=executable_directory();
        if(config.empty()){
            wchar_t local[32768]{};DWORD size=GetEnvironmentVariableW(L"LOCALAPPDATA",local,32768);
            auto directory=size&&size<32768?std::filesystem::path(local)/L"ScarletExternal":base;
            std::filesystem::create_directories(directory);config=directory/"config.json";
        }
        if(!config.parent_path().empty())std::filesystem::create_directories(config.parent_path());
        fe::Logger logger((config.parent_path()/"scarlet.log").string());fe::Settings settings;std::string error;
        if(std::filesystem::exists(config)&&!fe::load_settings(config,settings,error))logger.warn("Configuracao nao carregada: "+error);
        settings.automation.enabled=false;fe::normalize_settings(settings);
        fe::AutoChestMachine machine(logger);fe::Dx11Overlay overlay;
        const fe::OverlayOptions options{demo,base/"assets"};
        int result;
        if(demo){fe::MockGameDataProvider provider;result=overlay.run(settings,provider,provider,machine,logger,config,options);}
        else {fe::UnavailableGameDataProvider provider;result=overlay.run(settings,provider,provider,machine,logger,config,options);}
        if(result)MessageBoxW(nullptr,L"Falha ao inicializar/renderizar Scarlet. Consulte scarlet.log na pasta de configuracao.",L"Scarlet External",MB_OK|MB_ICONERROR);
        return result;
    }catch(const std::exception& error){MessageBoxA(nullptr,error.what(),"Scarlet External",MB_OK|MB_ICONERROR);return 1;}
}
