#pragma once
#include <filesystem>
namespace fe {
struct Settings;
class IGameDataProvider;
class IControlSink;
class AutoChestMachine;
class Logger;
struct OverlayOptions { bool demo{}; std::filesystem::path assets; };
class Dx11Overlay {
public:
    int run(Settings&,IGameDataProvider&,IControlSink&,AutoChestMachine&,Logger&,
            const std::filesystem::path&,const OverlayOptions&);
};
}
