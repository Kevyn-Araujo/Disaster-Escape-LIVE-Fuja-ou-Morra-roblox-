#pragma once
namespace fe::detail {
template<class T> void release(T*& object) {
    if (object) { object->Release(); object=nullptr; }
}
struct Graphics {
    ID3D11Device* device{};
    ID3D11DeviceContext* context{};
    IDXGISwapChain* swap_chain{};
    ID3D11RenderTargetView* target{};
    ~Graphics() {
        if (context) context->ClearState();
        release(target); release(swap_chain); release(context); release(device);
    }
    bool create_target() {
        ID3D11Texture2D* back_buffer{};
        HRESULT result=swap_chain->GetBuffer(0,__uuidof(ID3D11Texture2D),
                                             reinterpret_cast<void**>(&back_buffer));
        if (FAILED(result)) return false;
        result=device->CreateRenderTargetView(back_buffer,nullptr,&target);
        release(back_buffer);
        return SUCCEEDED(result);
    }
    bool initialize(HWND window,Logger& logger) {
        DXGI_SWAP_CHAIN_DESC description{};
        description.BufferCount=2;
        description.BufferDesc.Format=DXGI_FORMAT_R8G8B8A8_UNORM;
        description.BufferUsage=DXGI_USAGE_RENDER_TARGET_OUTPUT;
        description.OutputWindow=window;
        description.SampleDesc.Count=1;
        description.Windowed=TRUE;
        description.SwapEffect=DXGI_SWAP_EFFECT_DISCARD;
        constexpr D3D_FEATURE_LEVEL levels[]{D3D_FEATURE_LEVEL_11_0,D3D_FEATURE_LEVEL_10_0};
        D3D_FEATURE_LEVEL selected{};
        HRESULT result=D3D11CreateDeviceAndSwapChain(nullptr,D3D_DRIVER_TYPE_HARDWARE,
            nullptr,0,levels,2,D3D11_SDK_VERSION,&description,&swap_chain,&device,&selected,&context);
        if (FAILED(result)) {
            release(swap_chain); release(context); release(device);
            logger.warn("Hardware DirectX initialization failed; trying WARP software rendering.");
            result=D3D11CreateDeviceAndSwapChain(nullptr,D3D_DRIVER_TYPE_WARP,
                nullptr,0,levels,2,D3D11_SDK_VERSION,&description,&swap_chain,&device,&selected,&context);
        }
        return SUCCEEDED(result)&&create_target();
    }
    bool resize(UINT width,UINT height) {
        context->OMSetRenderTargets(0,nullptr,nullptr);
        release(target);
        if (FAILED(swap_chain->ResizeBuffers(0,width,height,DXGI_FORMAT_UNKNOWN,0))) return false;
        return create_target();
    }
};
}
