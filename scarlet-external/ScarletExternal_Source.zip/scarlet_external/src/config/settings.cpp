#include "config/settings.hpp"
#include "nlohmann/json.hpp"
#include <algorithm>
#include <cmath>
#include <fstream>
#include <functional>
#include <limits>
#include <set>
#include <vector>
#include <type_traits>
#include <stdexcept>
#ifdef _WIN32
#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include <windows.h>
#endif
namespace fe {
namespace {
using Json = nlohmann::json;
float bounded(float value,float low,float high,float fallback) {
    return std::isfinite(value)?std::clamp(value,low,high):fallback;
}
std::string pointer_for(std::string key) {
    std::replace(key.begin(),key.end(),'.','/');
    return "/"+key;
}
struct Binding {
    std::string key;
    std::function<Json()> write;
    std::function<bool(const Json&)> read;
};
std::vector<Binding> bindings(Settings& settings) {
    std::vector<Binding> result;
    auto bind=[&]<class T>(const std::string& key,T& field) {
        result.push_back({pointer_for(key),[ptr=&field]() {return Json(*ptr);},
            [ptr=&field](const Json& value) {
                if constexpr(std::is_same_v<T,bool>) {
                    if(!value.is_boolean()) return false;
                    *ptr=value.get<bool>();
                } else if constexpr(std::is_integral_v<T>) {
                    if(!value.is_number_integer()) return false;
                    const double number=value.get<double>();
                    if(number<std::numeric_limits<T>::lowest()||number>std::numeric_limits<T>::max()) return false;
                    *ptr=value.get<T>();
                } else {
                    if(!value.is_number()) return false;
                    const double number=value.get<double>();
                    if(!std::isfinite(number)||std::abs(number)>std::numeric_limits<float>::max()) return false;
                    *ptr=static_cast<T>(number);
                }
                return true;
            }});
    };
#define B(field) bind(#field,settings.field)
    B(visuals.enabled); B(visuals.players); B(visuals.chests);
    B(visuals.boxes); B(visuals.skeleton); B(visuals.names); B(visuals.distance);
    B(visuals.health); B(visuals.shield); B(visuals.snaplines); B(visuals.head_marker);
    B(visuals.player_count); B(visuals.visibility); B(visuals.team_check);
    B(visuals.chest_distance); B(visuals.chest_marker); B(visuals.nearest_highlight); B(visuals.chest_counter);
    B(visuals.max_chest_distance_m); B(visuals.max_player_distance_m);
    B(automation.enabled); B(automation.afk_mode); B(automation.auto_navigate); B(automation.auto_interact);
    B(automation.max_distance_m); B(automation.speed_mps); B(automation.interaction_distance_m);
    B(automation.interaction_timeout_s); B(automation.verification_timeout_s); B(automation.stuck_timeout_s);
    B(automation.progress_epsilon_m); B(automation.max_retries);
    B(overlay.fps_limit); B(overlay.vsync); B(overlay.transparent); B(overlay.click_through);
    B(overlay.menu_key); B(overlay.emergency_key); B(overlay.start_stop_key);
    B(automation.auto_retry); B(automation.stuck_recovery);
#undef B
    auto color=[&](const char* prefix,Color& value) {
        constexpr const char* channels[]={".r",".g",".b",".a"};
        for(std::size_t i=0;i<4;++i) bind(std::string(prefix)+channels[i],value[i]);
    };
    color("visuals.player_color",settings.visuals.player_color);
    color("visuals.hidden_color",settings.visuals.hidden_color);
    color("visuals.chest_color",settings.visuals.chest_color);
    color("visuals.nearest_color",settings.visuals.nearest_color);
    color("visuals.skeleton_color",settings.visuals.skeleton_color);
    color("visuals.snapline_color",settings.visuals.snapline_color);
    color("visuals.head_color",settings.visuals.head_color);
    color("visuals.health_color",settings.visuals.health_color);
    color("visuals.shield_color",settings.visuals.shield_color);
    return result;
}
} // namespace
void normalize_settings(Settings& settings) {
    auto& v=settings.visuals;
    v.max_chest_distance_m=bounded(v.max_chest_distance_m,50,1000,1000);
    v.max_player_distance_m=bounded(v.max_player_distance_m,50,1000,500);
    Color* colors[]={&v.player_color,&v.hidden_color,&v.chest_color,&v.nearest_color,
        &v.skeleton_color,&v.snapline_color,&v.head_color,&v.health_color,&v.shield_color};
    for(auto* color:colors) for(float& channel:*color) channel=bounded(channel,0,1,1);
    auto& a=settings.automation;
    a.max_distance_m=bounded(a.max_distance_m,50,1000,1000);
    a.speed_mps=bounded(a.speed_mps,0.5f,20,8);
    a.interaction_distance_m=bounded(a.interaction_distance_m,0.5f,2.2f,2);
    a.interaction_timeout_s=bounded(a.interaction_timeout_s,0.25f,30,3);
    a.verification_timeout_s=bounded(a.verification_timeout_s,0.25f,30,2);
    a.stuck_timeout_s=bounded(a.stuck_timeout_s,0.25f,30,2);
    a.progress_epsilon_m=bounded(a.progress_epsilon_m,0.01f,2,0.1f);
    a.max_retries=std::clamp(a.max_retries,0,8);
    auto& o=settings.overlay;
    o.fps_limit=std::clamp(o.fps_limit,15,240);
    const int menu_keys[]={0x2D,0x24,0x75,0x76};
    const int emergency_keys[]={0x77,0x78,0x79,0x7A};
    if(std::find(std::begin(menu_keys),std::end(menu_keys),o.menu_key)==std::end(menu_keys)) o.menu_key=0x2D;
    if(std::find(std::begin(emergency_keys),std::end(emergency_keys),o.emergency_key)==std::end(emergency_keys)) o.emergency_key=0x77;
    const int start_keys[]={0x74,0x75,0x78};
    if(std::find(std::begin(start_keys),std::end(start_keys),o.start_stop_key)==std::end(start_keys)) o.start_stop_key=0x75;
    if(o.start_stop_key==o.menu_key||o.start_stop_key==o.emergency_key) o.start_stop_key=0x74;
    if(o.menu_key==o.emergency_key) { o.menu_key=0x2D; o.emergency_key=0x77; }
}

bool save_settings(const std::filesystem::path& path,const Settings& settings,std::string& error) {
    error.clear();
    try {
        Settings normalized=settings; normalize_settings(normalized);
        Json document=Json::object(); document["format_version"]=1;
        for(const auto& binding:bindings(normalized)) document[Json::json_pointer(binding.key)]=binding.write();
        auto temporary=path; temporary+=".tmp";
        {
            std::ofstream stream(temporary,std::ios::trunc);
            if(!stream) {error="Nao foi possivel criar configuracao."; return false;}
            stream<<document.dump(2)<<'\n'; stream.flush();
            if(!stream) {error="Falha ao gravar configuracao."; return false;}
        }
#ifdef _WIN32
        if(!MoveFileExW(temporary.c_str(),path.c_str(),MOVEFILE_REPLACE_EXISTING|MOVEFILE_WRITE_THROUGH)) {
            error="Falha ao substituir configuracao: "+std::to_string(GetLastError()); return false;
        }
#else
        std::filesystem::rename(temporary,path);
#endif
        return true;
    } catch(const std::exception& exception) {error=exception.what();return false;}
}
bool load_settings(const std::filesystem::path& path,Settings& settings,std::string& error) {
    error.clear();
    try {
        if(std::filesystem::file_size(path)>65536) {error="Configuracao excede 64 KiB.";return false;}
        std::ifstream stream(path);
        if(!stream) {error="Nao foi possivel abrir configuracao.";return false;}
        std::vector<std::set<std::string>> keys;
        auto callback=[&](int,Json::parse_event_t event,Json& parsed) {
            if(event==Json::parse_event_t::object_start) keys.emplace_back();
            else if(event==Json::parse_event_t::key) {
                if(keys.empty()||!keys.back().insert(parsed.get<std::string>()).second)
                    throw std::runtime_error("Chave JSON duplicada.");
            } else if(event==Json::parse_event_t::object_end) keys.pop_back();
            return true;
        };
        const Json document=Json::parse(stream,callback);
        if(!document.is_object()||!document.contains("format_version")
           ||!document["format_version"].is_number_integer()||document["format_version"]!=1) {
            error="format_version invalido ou ausente.";return false;
        }
        Settings candidate=settings;
        auto fields=bindings(candidate);
        const auto flattened=document.flatten();
        for(const auto& [key,value]:flattened.items()) {
            if(key=="/format_version") continue;
            const auto found=std::find_if(fields.begin(),fields.end(),[&](const Binding& b){return b.key==key;});
            if(found==fields.end()) {error="Chave desconhecida: "+key;return false;}
            if(!found->read(value)) {error="Valor invalido: "+key;return false;}
        }
        normalize_settings(candidate); candidate.automation.enabled=false; settings=candidate;
        return true;
    } catch(const std::exception& exception) {error=exception.what();return false;}
}
} // namespace fe
