# Validação executada

Validação em Linux x86-64, com GCC 14.2.0, CMake 4.4.4 e Ninja 1.13.2. Os executáveis Windows foram compilados com LLVM-MinGW 20240619 / Clang 18.1.8 para x86-64, com runtime C++ ligado estaticamente. Dear ImGui está fixado na versão 1.91.9b.

## Resultados observados

| Verificação | Resultado |
|---|---|
| Build C++20 nativo, núcleo + testes + headless | Passou |
| `core_regressions` | 17/17 grupos comportamentais passaram |
| `simulated_collection` | Passou; três aberturas confirmadas, zero avisos, zero erros |
| CTest nativo | 2/2 passou |
| ASan + UBSan + detecção de vazamentos, núcleo/testes/headless | 2/2 passou, sem diagnóstico dos sanitizadores |
| Build e link Windows x64, aplicativo Win32/D3D11/ImGui | Passou |
| Build e link Windows x64, testes e headless | Passou |
| Execução dos executáveis no Windows / MSVC v143 | Não executada neste ambiente |
| Inspeção visual, GPU/WARP, transparência, redimensionamento e atalhos em Windows | Não executada; somente compilação e revisão do código |
| Integração com partida real de Fortnite | Não implementada nem testada |

Os tempos da rodada final foram aproximadamente 5,88 s para CTest nativo e 27,39 s para CTest com sanitizadores. Não são benchmarks de FPS ou de desempenho gráfico.

## Cobertura comportamental

1. Estados de baús: Closed/Unknown/Open/Destroyed/Unavailable e disponibilidade.
2. Distâncias inclusivas em metros, limites de 50 e 1.000 m e desempate estável.
3. Campos opcionais de jogadores, equipes desconhecidas e posições inválidas.
4. WorldToScreen, matriz inválida, clipping e posição atrás da câmera.
5. A* com obstáculos, limites da grade e cantos bloqueados.
6. Escolha da menor rota acessível, em vez de um alvo próximo inacessível.
7. Três aberturas confirmadas no cenário básico.
8. AFK desativado: somente uma coleta por habilitação.
9. Trava e rearme da parada de emergência.
10. Desativação e desconexão interrompem comandos.
11. Snapshot repetido suspende o controle.
12. Alvo invalidado é removido.
13. Confirmação Open aceita durante verificação mesmo sem nova malha de navegação.
14. Cenários preso e timeout não produzem sucesso falso.
15. Baú mais próximo bloqueado é ignorado; outros são coletados.
16. Validação de comandos do mock e reinicialização reproduzível.
17. Configuração: roundtrip, rejeição atômica, versão, duplicatas, chaves desconhecidas, normalização e automação desativada após carga.

## Comandos utilizados

```sh
cmake --preset portable
cmake --build --preset portable --parallel
ctest --preset portable

cmake --preset sanitizers
cmake --build --preset sanitizers --parallel
ASAN_OPTIONS=detect_leaks=1:halt_on_error=1 \
UBSAN_OPTIONS=halt_on_error=1:print_stacktrace=1 \
ctest --preset sanitizers

cmake -S . -B build/windows-cross -G Ninja \
  -DCMAKE_TOOLCHAIN_FILE=cmake/mingw-toolchain.cmake \
  -DCMAKE_BUILD_TYPE=Release -DFE_BUILD_OVERLAY=ON \
  -DCMAKE_EXE_LINKER_FLAGS=-static
cmake --build build/windows-cross --parallel
```

No último comando, os binários LLVM-MinGW estavam no PATH. A compilação cruzada gerou `fortnite_external.exe`, `fe_tests.exe` e `fe_headless.exe` em formato PE32+ x86-64. A inspeção de imports não encontrou dependência de DLL de runtime C++ do toolchain; continuam necessárias as bibliotecas de sistema Windows, UCRT e DirectX.

Os logs completos de CTest estão em `docs/test-results/`. As instruções para compilar com o compilador e SDK do Visual Studio 2022 estão no README; esse fluxo permanece a confirmar em uma máquina Windows.

## Dependências de integração

O estado Closed no mock é observado no mundo simulado, não inferido de um spawn. Abertura só é contabilizada após o provider publicar Open. Nada nesses testes demonstra detecção ou coleta de objetos reais de Fortnite. Para isso seria necessário desenvolver e validar as origens e os canais descritos em `INTEGRATION.md`.
