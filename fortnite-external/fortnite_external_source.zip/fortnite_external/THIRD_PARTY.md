# Dependências incluídas

Dear ImGui v1.91.9b, commit `f5befd2d29e66809cd1110a152e375a7f1981f06`.
Fonte: https://github.com/ocornut/imgui . Licença MIT, preservada em `vendor/imgui/LICENSE.txt`.
Os arquivos necessários para o backend Win32/DirectX 11 estão incluídos; o build não baixa dependências.

DirectX 11, DXGI, DWM e as bibliotecas Win32 vêm do Windows SDK. MSVC vem do Visual Studio 2022.
CMake >=3.25 é a ferramenta de configuração. O núcleo e os testes usam somente C++20 e threads da biblioteca padrão.

O toolchain LLVM-MinGW usado para verificar a compilação cruzada não faz parte do código-fonte distribuído.
