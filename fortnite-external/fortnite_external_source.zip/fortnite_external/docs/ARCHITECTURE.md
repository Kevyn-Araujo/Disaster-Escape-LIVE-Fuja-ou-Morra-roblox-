# Arquitetura

Este aplicativo é um simulador externo de dados, visualização e automação. A aquisição implementada é `MockGameDataProvider`; o programa não obtém dados de uma partida de Fortnite.

## Módulos

| Diretório | Responsabilidade |
|---|---|
| `src/core` | Tipos, unidades e projeção WorldToScreen sem dependência de Windows. |
| `src/data` | Contratos `IGameDataProvider` e `IControlSink`, aquisição simulada e snapshots coerentes. |
| `src/esp` | Elegibilidade, distâncias e desenho de entidades com dados disponíveis. |
| `src/navigation` | Validação de grade, segmentos percorríveis e planejamento A*. |
| `src/automation` | Seleção acessível, estados de coleta, confirmação, limites e recuperação. |
| `src/overlay` | Janela Win32, dispositivo DirectX 11 e ciclo de vida gráfico. |
| `src/ui` | Menu ImGui, controles, cenários e apresentação do diagnóstico. |
| `src/config` | Configurações, normalização e persistência transacional. |
| `src/utils` | Registro limitado de mensagens com sincronização. |
| `tests` | Testes de comportamento do núcleo portátil. |

```mermaid
flowchart LR
    P[IGameDataProvider] --> S[GameSnapshot coerente]
    S --> F[Filtros e WorldToScreen]
    F --> R[ESP / ImGui / DirectX 11]
    S --> A[AutoChestMachine]
    A --> N[Planejador A*]
    A --> C[IControlSink]
    C --> M[Simulação autorizada]
    M --> P
    U[Menu e configurações] --> A
    U --> R
```

## Contrato dos dados

As posições usam metros e um sistema cartesiano com `Y` vertical; a navegação usa o plano `XZ`. `Mat4` contém 16 valores em ordem de linhas; a projeção calcula `clip = M * vetor_coluna`. `make_camera` constrói uma câmera de referência com profundidade positiva à frente, projeção perspectiva e profundidade DirectX entre zero e um.

Um `GameSnapshot` contém seu número de sequência, tempo de simulação, estado de conexão, posição local, câmera e coleções. O provider devolve uma cópia completa. O mock protege as leituras e as mutações com `std::shared_mutex`; nenhum consumidor depende de referências a contêineres que outra thread possa alterar. O aplicativo atual executa aquisição, automação e desenho em sequência no mesmo ciclo. Um provider assíncrono deverá preservar esse contrato de snapshot.

Campos ausentes permanecem ausentes. Vida, escudo, equipe, nome e visibilidade são opcionais. Um indicador de visibilidade depende de um valor fornecido pela origem; não é deduzido da distância ou da projeção. As linhas do esqueleto dependem dos segmentos fornecidos pelo provider. Nenhum valor visual inventado completa os campos que faltam.

O estado de um baú é `Unknown`, `Closed`, `Open`, `Destroyed` ou `Unavailable`. Somente `Closed`, disponível e com posição finita, entra no filtro. Um ponto de spawn possível não satisfaz esse contrato. O limite solicitado é normalizado para 50–1.000 metros, com comparação inclusiva na borda. A lista de baús é reconstruída a cada snapshot; assim que a origem confirma `Open`, o baú deixa de ser elegível.

## Navegação

O planejador usa uma grade explícita de células percorríveis. Não supõe que um destino projetado na tela seja acessível. Os pontos de partida e chegada devem estar dentro de células livres. Movimentos diagonais não atravessam quinas bloqueadas; os segmentos resultantes são verificados para impedir atravessamento de obstáculos entre dois pontos.

A seleção considera baús fechados dentro da distância direta configurada, calcula rotas válidas e prefere a rota de menor comprimento. Empates são resolvidos pelo identificador da entidade. O waypoint final preserva a posição do baú. A grade precisa vir de uma origem autorizada; o mock fornece a sua própria geometria conhecida. Esta implementação cobre um plano de navegação: não modela escadas, construção, saltos, veículos ou malhas tridimensionais.

`IControlSink` recebe comandos de movimento, interação e parada, separados da aquisição. A implementação entregue modifica apenas o mundo simulado. Aceitar uma interação não confirma que o baú abriu: o provider precisa publicar essa mudança depois.

## Máquina de estados

| Estado | Trabalho e condição de saída |
|---|---|
| `IDLE` | Aguarda habilitação; respeita a trava de emergência e a coleta única. |
| `SEARCHING` | Procura candidatos confirmados e dados suficientes. |
| `SELECTING_CHEST` | Escolhe uma rota válida para o alvo elegível de menor custo. |
| `NAVIGATING` | Percorre waypoints, acompanha progresso e detecta ausência de movimento. |
| `INTERACTING` | Solicita interação dentro do alcance permitido e limita seu tempo. |
| `VERIFYING` | Aguarda um snapshot que confirme explicitamente `Open`. |
| `RECOVERING` | Para, registra falha, aplica intervalo e tenta novamente até o limite. |

Snapshots repetidos suspendem os comandos; a ausência persistente de atualização é registrada. Desconexão, posição local inválida e invalidação do alvo interrompem o fluxo. As falhas por alvo têm tentativas limitadas; alvos esgotados aguardam um novo ciclo desligar/ligar. A parada de emergência fica travada até que a máquina observe `enabled=false` e, depois, `enabled=true`. Com AFK desativado, uma abertura confirmada também encerra a rodada até nova habilitação.

## Cenários reproduzíveis

| Nome de linha de comando | Objetivo |
|---|---|
| `baseline` | Três baús fechados alcançáveis, além de entidades abertas, destruídas, desconhecidas, indisponíveis e fora do limite. |
| `unknown` | Exercitar estados sem confirmação sem tratá-los como fechados. |
| `blocked` | O baú fechado mais próximo fica inacessível; outros continuam alcançáveis. |
| `stuck` | O controle aceita movimento, mas a posição não avança; testa detecção e recuperação. |
| `timeout` | A interação é aceita, mas o estado aberto nunca é publicado; testa verificação e limite. |

## Configuração e diagnóstico

O arquivo de configuração usa `key=value`, versão explícita e valores normalizados. Chaves desconhecidas, duplicadas ou malformadas produzem erro sem substituir parcialmente a configuração em uso. A carga deixa a automação desativada. A interface decide quando o operador a habilita novamente.

O logger preserva um histórico limitado e pode escrever em arquivo. Erros não são convertidos em aberturas ou em dados visuais válidos. O executável sem interface usa exatamente o mesmo provider, planejador e máquina de estados dos componentes gráficos.

## Limites de desempenho

O filtro de distância reduz o desenho e a seleção. A renderização exige posições finitas e projeções válidas; objetos fora da câmera não são desenhados. O planejamento evita grades inválidas ou excessivas. O limite de FPS e o VSync são opções do frontend gráfico. A geração de snapshots por cópia privilegia coerência e simplicidade; integrações com grandes volumes deverão medir o custo antes de substituir esse contrato por armazenamento imutável compartilhado.
