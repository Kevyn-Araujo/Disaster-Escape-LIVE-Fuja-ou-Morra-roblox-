# Integração e limites

## O que existe neste projeto

O provider entregue é `MockGameDataProvider`. Ele produz posições, estados e obstáculos de uma simulação própria. O sink de controle altera essa simulação. Player ESP, Chest ESP e Auto Chest demonstram seus comportamentos sobre esses dados, usando o mesmo núcleo que os testes exercitam.

O aplicativo não se conecta ao processo do Fortnite, não lê sua memória, não injeta DLL, não usa driver e não altera proteções. Ele não envia movimentos ou interações para o jogo. Ativar transparência ou colocar uma janela sobre outra janela não fornece dados do jogo.

## Dados de uma partida real

Nenhum provider baseado em API pública ou autorizada de Fortnite foi incluído ou validado nesta entrega para obter, durante uma partida, as posições de jogadores, seus atributos visuais, os baús realmente existentes e seus estados. Portanto, não há demonstração de detecção de jogadores ou baús reais neste projeto.

Esta documentação descreve o contrato implementado e seus limites; não afirma uma auditoria atual de todos os SDKs, APIs, modos de criação ou formatos de replay da Epic. A disponibilidade e a autorização de uma futura origem precisam ser verificadas na documentação e no ambiente específico dessa integração. Serviços de conta, catálogo, estatísticas ou identidade, por si sós, não satisfazem o contrato espacial e temporal do provider. Dados de replay, quando disponíveis para uso autorizado, também não devem ser apresentados automaticamente como telemetria de uma partida ao vivo.

## Requisitos para adicionar uma origem autorizada

Implemente `IGameDataProvider` em um novo módulo sem modificar o renderizador. A origem deverá fornecer:

1. Um snapshot coerente com sequência ou tempo que avance quando os dados forem atualizados, além de um estado explícito de conexão.
2. Posição local e posições válidas de entidades em metros. Converta as unidades antes de publicar o snapshot.
3. Identificadores estáveis de entidades. Reutilizar um identificador para outro objeto pode invalidar a confirmação e as tentativas de coleta.
4. Estado observado de cada baú. Uma localização de spawn ou a ausência de confirmação de abertura não prova `Closed`.
5. Dados de câmera e matriz com a convenção documentada. Se a origem não fornecer câmera válida, mantenha `camera.valid=false`.
6. Somente os atributos realmente fornecidos: os campos opcionais permitem ausência de nome, vida, escudo, equipe, visibilidade e ossos.
7. Geometria de navegação confiável para automatizar rotas. Sem ela, exibir uma posição não autoriza inferir um caminho transitável.

Não deixe `connected=true` com dados antigos indefinidamente. Uma origem que perde sua conexão deverá publicar a desconexão. A automação também observa a progressão do snapshot e suspende controles quando não há dados novos.

## Controle em outro ambiente

Implemente `IControlSink` apenas quando esse ambiente disponibilizar um mecanismo de controle autorizado. Retornar `true` de `interact` significa que o pedido foi aceito; a confirmação de abertura precisa aparecer no snapshot seguinte. O sink deve parar ao receber `stop()` e reportar falhas reais de movimento ou interação.

O planejador atual representa um piso em grade e não conhece a física de Fortnite. Uma integração que precise de rampas, portas, saltos ou múltiplos andares precisará ampliar o modelo e testar esses movimentos antes de habilitar a navegação. Aumentar o alcance do ESP para 1.000 metros não cria essas informações nem amplia os dados disponíveis na origem.

## Validação independente

Mantenha três evidências separadas:

| Evidência | O que demonstra |
|---|---|
| Testes do núcleo com mock | Filtros, projeção, rotas e transições sobre cenários reproduzíveis. |
| Compilação do alvo Windows | Consistência do código e dependências para esse alvo; não comprova desenho na GPU. |
| Execução visual no Windows | Funcionamento observado de Win32, DirectX 11, ImGui, hotkeys e estilos de janela. |
| Testes de um novo provider | Qualidade e autorização da origem e confirmação dos seus dados reais. |

Uma dessas evidências não substitui as demais. Os resultados efetivamente executados nesta entrega estão no relatório de validação do projeto.

## Executável sem interface

O alvo `fe_headless` permite repetir cenários sem Win32 ou DirectX:

```sh
./fe_headless --scenario baseline --steps 5000 --dt 0.05
./fe_headless --scenario blocked --steps 5000 --dt 0.05
./fe_headless --scenario stuck --steps 2000 --dt 0.05
./fe_headless --scenario timeout --steps 2000 --dt 0.05
```

O passo aceito vai de 0,001 a 0,25 segundo e o total de passos de 1 a 1.000.000. O tempo avança de forma simulada: não há espera de tempo real entre os passos. `--help` apresenta os parâmetros.

O retorno é `2` para argumentos inválidos. No cenário `baseline`, o retorno é `0` ao confirmar pelo menos três aberturas e `1` se o limite de passos terminar antes disso. Nos cenários de falha, o retorno `0` indica que a simulação terminou normalmente, mesmo quando nenhuma abertura era esperada; os testes verificam separadamente seus resultados. O resumo conta confirmações observadas pela máquina, não pedidos de interação.
