// C++20 | tests.cpp | Portable behavioral tests; no game process is accessed.
#include "automation/auto_chest.hpp"
#include "config/settings.hpp"
#include "data/mock_game_data_provider.hpp"
#include "esp/filters.hpp"
#include "navigation/path_planner.hpp"
#include "utils/logger.hpp"
#include <algorithm>
#include <chrono>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <functional>
#include <iostream>
#include <limits>
#include <stdexcept>
#include <string>
#include <vector>

namespace {
using namespace fe;
void require(bool value, const char* expression, int line) {
    if (!value) throw std::runtime_error(std::string("line ")+std::to_string(line)+": "+expression);
}
#define REQUIRE(expression) require(static_cast<bool>(expression), #expression, __LINE__)
bool near(float a, float b, float epsilon=0.001f) { return std::abs(a-b) <= epsilon; }
NavigationGrid grid(int width, int height) {
    NavigationGrid result;
    result.width = width; result.height = height;
    result.walkable.assign(static_cast<std::size_t>(width*height), 1);
    return result;
}
GameSnapshot snapshot() {
    GameSnapshot result;
    result.sequence = 1; result.connected = true;
    result.local_position = Vec3{0,0,0}; result.local_team = 1;
    return result;
}
Chest chest(EntityId id, Vec3 position, ChestState state=ChestState::Closed) {
    return {id, position, state, true};
}
struct RecordingSink final : IControlSink {
    int moves{}, interactions{}, stops{};
    bool accept_move{true}, accept_interact{true};
    bool move_towards(Vec3, float, double) override { ++moves; return accept_move; }
    bool interact(EntityId) override { ++interactions; return accept_interact; }
    void stop() noexcept override { ++stops; }
};
void advance(MockGameDataProvider& provider, AutoChestMachine& machine,
             const AutomationSettings& settings, int steps, double dt=0.05) {
    for (int i=0; i<steps; ++i) {
        provider.tick(dt);
        machine.update(provider.snapshot(), provider, settings, dt);
    }
}
void advance_snapshot(GameSnapshot& data, AutoChestMachine& machine,
                      RecordingSink& sink, const AutomationSettings& settings,
                      int steps, double dt=0.05) {
    for (int i=0; i<steps; ++i) {
        ++data.sequence; data.simulation_time += dt;
        machine.update(data, sink, settings, dt);
    }
}
std::size_t fault_count(const Logger& logger) {
    const auto entries = logger.entries();
    return static_cast<std::size_t>(std::count_if(entries.begin(), entries.end(), [](const LogEntry& e) {
        return e.level == LogLevel::Warning || e.level == LogLevel::Error;
    }));
}

void chest_state_filter() {
    auto data = snapshot();
    data.chests = {chest(1,{3,0,4}), chest(2,{2,0,0},ChestState::Unknown),
        chest(3,{2,0,0},ChestState::Open), chest(4,{2,0,0},ChestState::Destroyed),
        chest(5,{2,0,0},ChestState::Unavailable)};
    auto unavailable = chest(6,{2,0,0}); unavailable.available = false;
    auto missing = chest(7,{2,0,0}); missing.position.reset();
    auto invalid = chest(8,{std::numeric_limits<float>::quiet_NaN(),0,0});
    data.chests.push_back(unavailable); data.chests.push_back(missing); data.chests.push_back(invalid);
    const auto filtered = closed_chests(data,1000);
    REQUIRE(filtered.size()==1); REQUIRE(filtered.front().chest.id==1);
    REQUIRE(near(filtered.front().distance_m,5));
    data.chests.front().state = ChestState::Open;
    REQUIRE(closed_chests(data,1000).empty());
}
void distance_limits_and_order() {
    auto data = snapshot();
    data.chests = {chest(9,{50,0,0}),chest(8,{50,0,0}),chest(3,{50.01f,0,0}),
        chest(4,{1000,0,0}),chest(5,{1000.1f,0,0})};
    const auto close = closed_chests(data,1);
    REQUIRE(close.size()==2); REQUIRE(close[0].chest.id==8); REQUIRE(close[1].chest.id==9);
    const auto far = closed_chests(data,5000);
    REQUIRE(far.size()==4); REQUIRE(far.back().chest.id==4);
    REQUIRE(near(clamped_render_distance(-5),50)); REQUIRE(near(clamped_render_distance(5000),1000));
    const float nan_limit = clamped_render_distance(std::numeric_limits<float>::quiet_NaN());
    REQUIRE(std::isfinite(nan_limit)); REQUIRE(nan_limit>=50 && nan_limit<=1000);
    data.local_position.reset(); REQUIRE(closed_chests(data,1000).empty());
    data.local_position = Vec3{0,0,0}; data.connected=false;
    REQUIRE(closed_chests(data,1000).empty());
}
void player_optional_fields() {
    auto data = snapshot();
    Player enemy; enemy.id=1; enemy.position=Vec3{0,0,10}; enemy.team=2; enemy.visible=false;
    Player teammate=enemy; teammate.id=2; teammate.team=1;
    Player unknown=enemy; unknown.id=3; unknown.team.reset(); unknown.visible.reset();
    unknown.health.reset(); unknown.shield.reset(); unknown.name.reset();
    Player invalid=enemy; invalid.id=4; invalid.position=Vec3{0,0,std::numeric_limits<float>::infinity()};
    Player missing=enemy; missing.id=5; missing.position.reset();
    Player unavailable=enemy; unavailable.id=6; unavailable.available=false;
    data.players={enemy,teammate,unknown,invalid,missing,unavailable};
    const auto filtered=visible_players(data,1000,true);
    REQUIRE(filtered.size()==2);
    REQUIRE(std::any_of(filtered.begin(),filtered.end(),[](const Player& p){return p.id==1 && p.visible==false;}));
    REQUIRE(std::any_of(filtered.begin(),filtered.end(),[](const Player& p){return p.id==3 && !p.team && !p.health;}));
    REQUIRE(visible_players(data,1000,false).size()==3);
    data.local_team.reset(); REQUIRE(visible_players(data,1000,true).size()==3);
    data.connected=false; REQUIRE(visible_players(data,1000,false).empty());
}
void projection_contract() {
    auto camera=make_camera({0,0,0},{0,0,1},16.0f/9.0f);
    REQUIRE(camera.valid);
    const auto center=world_to_screen({0,0,10},camera,1920,1080);
    REQUIRE(center.has_value()); REQUIRE(near(center->x,960)); REQUIRE(near(center->y,540));
    REQUIRE(!world_to_screen({0,0,-10},camera,1920,1080));
    REQUIRE(!world_to_screen({1000,0,1},camera,1920,1080));
    REQUIRE(!world_to_screen({0,0,10},camera,0,1080));
    REQUIRE(!world_to_screen({0,0,10},camera,1920,-1));
    REQUIRE(!world_to_screen({0,0,std::numeric_limits<float>::infinity()},camera,1920,1080));
    camera.view_projection.values[0]=std::numeric_limits<float>::quiet_NaN();
    REQUIRE(!world_to_screen({0,0,10},camera,1920,1080));
    camera=Camera{}; camera.valid=true;
    REQUIRE(!world_to_screen({0,0,10},camera,1920,1080));
    REQUIRE(!make_camera({0,0,0},{0,0,0},1).valid);
    REQUIRE(!make_camera({0,0,0},{0,0,1},-1).valid);
}
void planner_obstacles_and_boundaries() {
    auto navigation=grid(5,5);
    const Vec3 start{0.5f,0,0.5f}, goal{4.5f,0,4.5f};
    const auto path=plan_path(navigation,start,goal);
    REQUIRE(path.has_value()); REQUIRE(!path->points.empty());
    REQUIRE(distance(path->points.back(),goal)<0.001f);
    REQUIRE(std::isfinite(path->length_m) && path->length_m>0);
    Vec3 previous=start;
    for (const auto& point:path->points) { REQUIRE(segment_walkable(navigation,previous,point)); previous=point; }
    REQUIRE(!plan_path(navigation,{-0.01f,0,0.5f},goal));
    REQUIRE(!plan_path(navigation,start,{5,0,4.5f}));
    for (int z=0;z<5;++z) navigation.walkable[static_cast<std::size_t>(z*5+2)]=0;
    REQUIRE(!plan_path(navigation,start,goal));
    REQUIRE(!segment_walkable(navigation,start,goal));
    auto corner=grid(2,2); corner.walkable[1]=0; corner.walkable[2]=0;
    REQUIRE(!plan_path(corner,{0.5f,0,0.5f},{1.5f,0,1.5f}));
    REQUIRE(!segment_walkable(corner,{0.5f,0,0.5f},{1.5f,0,1.5f}));
    auto invalid=grid(2,2); invalid.walkable.pop_back();
    REQUIRE(!plan_path(invalid,start,{1.5f,0,1.5f}));
}
void nearest_reachable_route_selection() {
    auto data=snapshot(); data.local_position=Vec3{1.5f,0,1.5f}; data.navigation=grid(9,9);
    for(int z=0;z<8;++z) data.navigation->walkable[static_cast<std::size_t>(z*9+2)]=0;
    data.chests={chest(1,{3.5f,0,1.5f}),chest(2,{1.5f,0,7.5f})};
    Logger logger; AutoChestMachine machine(logger); RecordingSink sink;
    AutomationSettings settings; settings.enabled=true;
    advance_snapshot(data,machine,sink,settings,5);
    REQUIRE(machine.target().has_value()); REQUIRE(*machine.target()==2);
}
void baseline_confirmed_openings() {
    Logger logger; MockGameDataProvider provider; AutoChestMachine machine(logger);
    AutomationSettings settings; settings.enabled=true;
    advance(provider,machine,settings,5000);
    REQUIRE(machine.completed_count()>=3);
    const auto final=provider.snapshot();
    for (EntityId id:{EntityId{101},EntityId{102},EntityId{103}}) {
        const auto found=std::find_if(final.chests.begin(),final.chests.end(),[id](const Chest& c){return c.id==id;});
        REQUIRE(found!=final.chests.end()); REQUIRE(found->state==ChestState::Open);
    }
    REQUIRE(closed_chests(final,1000).empty());
}
void afk_off_collects_one() {
    Logger logger; MockGameDataProvider provider; AutoChestMachine machine(logger);
    AutomationSettings settings; settings.enabled=true; settings.afk_mode=false;
    advance(provider,machine,settings,2000);
    REQUIRE(machine.completed_count()==1);
    const auto position=*provider.snapshot().local_position;
    advance(provider,machine,settings,500);
    REQUIRE(machine.completed_count()==1);
    REQUIRE(distance(position,*provider.snapshot().local_position)<0.001f);
}
void emergency_latch_and_rearm() {
    Logger logger; MockGameDataProvider provider; AutoChestMachine machine(logger);
    AutomationSettings settings; settings.enabled=true;
    advance(provider,machine,settings,12);
    machine.emergency_stop(provider);
    const Vec3 stopped=*provider.snapshot().local_position;
    advance(provider,machine,settings,100);
    REQUIRE(distance(stopped,*provider.snapshot().local_position)<0.001f);
    REQUIRE(machine.completed_count()==0);
    settings.enabled=false; advance(provider,machine,settings,1);
    settings.enabled=true; advance(provider,machine,settings,2000);
    REQUIRE(machine.completed_count()>=1);
}
void disabled_and_disconnect_stop() {
    Logger logger; AutoChestMachine machine(logger); RecordingSink sink;
    auto data=snapshot(); data.local_position=Vec3{0.5f,0,0.5f}; data.navigation=grid(8,8);
    data.chests={chest(1,{4.5f,0,4.5f})};
    AutomationSettings settings;
    advance_snapshot(data,machine,sink,settings,20);
    REQUIRE(sink.moves==0 && sink.interactions==0);
    settings.enabled=true; advance_snapshot(data,machine,sink,settings,5);
    const int before_moves=sink.moves, before_stops=sink.stops;
    data.connected=false; advance_snapshot(data,machine,sink,settings,1);
    REQUIRE(sink.moves==before_moves); REQUIRE(sink.stops>before_stops);
    data.connected=true; data.local_position.reset();
    advance_snapshot(data,machine,sink,settings,1);
    REQUIRE(sink.moves==before_moves);
}
void stale_snapshot_stops_controls() {
    Logger logger; AutoChestMachine machine(logger); RecordingSink sink;
    auto data=snapshot(); data.local_position=Vec3{0.5f,0,0.5f}; data.navigation=grid(8,8);
    data.chests={chest(1,{6.5f,0,6.5f})};
    AutomationSettings settings; settings.enabled=true; settings.stuck_timeout_s=10;
    advance_snapshot(data,machine,sink,settings,5);
    for(int i=0;i<200;++i) machine.update(data,sink,settings,0.05);
    const int stopped_moves=sink.moves;
    for(int i=0;i<20;++i) machine.update(data,sink,settings,0.05);
    REQUIRE(sink.moves==stopped_moves); REQUIRE(sink.stops>0);
    REQUIRE(machine.completed_count()==0);
}
void invalidated_target_removed() {
    Logger logger; AutoChestMachine machine(logger); RecordingSink sink;
    auto data=snapshot(); data.local_position=Vec3{0.5f,0,0.5f}; data.navigation=grid(8,8);
    data.chests={chest(1,{6.5f,0,6.5f})};
    AutomationSettings settings; settings.enabled=true;
    advance_snapshot(data,machine,sink,settings,5);
    REQUIRE(machine.target()==std::optional<EntityId>{1});
    data.chests[0].state=ChestState::Unknown;
    advance_snapshot(data,machine,sink,settings,1);
    REQUIRE(machine.target()!=std::optional<EntityId>{1});
    REQUIRE(machine.completed_count()==0);
}
void explicit_open_confirmation_without_navigation() {
    Logger logger; AutoChestMachine machine(logger); RecordingSink sink;
    auto data=snapshot(); data.local_position=Vec3{0.5f,0,0.5f}; data.navigation=grid(3,3);
    data.chests={chest(1,{1.5f,0,0.5f})};
    AutomationSettings settings; settings.enabled=true;
    for(int i=0;i<12 && machine.state()!=AutoChestState::Verifying;++i)
        advance_snapshot(data,machine,sink,settings,1);
    REQUIRE(machine.state()==AutoChestState::Verifying);
    REQUIRE(sink.interactions>0); REQUIRE(machine.completed_count()==0);
    data.chests[0].state=ChestState::Open;
    data.navigation.reset();
    advance_snapshot(data,machine,sink,settings,1);
    REQUIRE(machine.completed_count()==1);
    REQUIRE(!machine.target());
}
void fault_scenarios_do_not_fake_success() {
    for (const auto scenario:{MockScenario::Stuck,MockScenario::InteractionTimeout}) {
        Logger logger; MockGameDataProvider provider(scenario); AutoChestMachine machine(logger);
        AutomationSettings settings; settings.enabled=true; settings.max_retries=1;
        settings.stuck_timeout_s=0.4f; settings.interaction_timeout_s=0.5f;
        settings.verification_timeout_s=0.5f;
        const auto start=*provider.snapshot().local_position;
        advance(provider,machine,settings,2000);
        REQUIRE(machine.completed_count()==0); REQUIRE(fault_count(logger)>0);
        REQUIRE(machine.attempts()<=settings.max_retries+1);
        if (scenario==MockScenario::Stuck)
            REQUIRE(distance(start,*provider.snapshot().local_position)<0.001f);
    }
}
void blocked_nearest_skipped() {
    Logger logger; MockGameDataProvider provider(MockScenario::Blocked); AutoChestMachine machine(logger);
    AutomationSettings settings; settings.enabled=true;
    advance(provider,machine,settings,5000);
    REQUIRE(machine.completed_count()>=2);
    const auto final=provider.snapshot();
    const auto blocked=std::find_if(final.chests.begin(),final.chests.end(),[](const Chest& c){return c.id==101;});
    REQUIRE(blocked!=final.chests.end()); REQUIRE(blocked->state==ChestState::Closed);
}
void mock_movement_validation() {
    MockGameDataProvider provider;
    const auto before=provider.snapshot();
    REQUIRE(before.local_position.has_value());
    const Vec3 position=*before.local_position;
    REQUIRE(!provider.move_towards({std::numeric_limits<float>::quiet_NaN(),0,0},8,0.1));
    REQUIRE(!provider.interact(999999)); REQUIRE(!provider.interact(103));
    provider.move_towards(position+Vec3{10,0,0},8,0.1);
    REQUIRE(distance(position,*provider.snapshot().local_position)<=0.801f);
    const auto sequence=provider.snapshot().sequence;
    provider.set_scenario(MockScenario::Baseline);
    REQUIRE(provider.snapshot().sequence>sequence);
}
void configuration_roundtrip_and_atomic_rejection() {
    const auto unique=std::to_string(std::chrono::steady_clock::now().time_since_epoch().count());
    const auto directory=std::filesystem::temp_directory_path()/("fe-tests-"+unique);
    std::filesystem::create_directories(directory);
    struct Cleanup { std::filesystem::path path; ~Cleanup(){std::error_code ec;std::filesystem::remove_all(path,ec);} } cleanup{directory};
    Settings source;
    source.automation.enabled=true;
    source.visuals.names=false; source.visuals.max_chest_distance_m=725;
    source.visuals.chest_color={0.12f,0.34f,0.56f,0.78f};
    source.automation.speed_mps=11; source.automation.max_retries=3;
    source.overlay.fps_limit=120; source.overlay.vsync=false;
    std::string error;
    REQUIRE(save_settings(directory/"settings.ini",source,error));
    Settings loaded;
    REQUIRE(load_settings(directory/"settings.ini",loaded,error));
    REQUIRE(!loaded.visuals.names); REQUIRE(near(loaded.visuals.max_chest_distance_m,725));
    REQUIRE(near(loaded.visuals.chest_color[2],0.56f));
    REQUIRE(near(loaded.automation.speed_mps,11)); REQUIRE(loaded.automation.max_retries==3);
    REQUIRE(!loaded.automation.enabled);
    REQUIRE(loaded.overlay.fps_limit==120 && !loaded.overlay.vsync);
    const auto original=loaded;
    { std::ofstream broken(directory/"broken.ini"); broken << "invalid settings payload without an equals sign\n"; }
    REQUIRE(!load_settings(directory/"broken.ini",loaded,error));
    REQUIRE(!error.empty()); REQUIRE(loaded.visuals.names==original.visuals.names);
    REQUIRE(near(loaded.visuals.max_chest_distance_m,original.visuals.max_chest_distance_m));
    REQUIRE(loaded.overlay.fps_limit==original.overlay.fps_limit);
    const std::vector<std::string> invalid_payloads={
        "format_version=1\nvisuals.max_chest_distance_m=nan\n",
        "format_version=1\nvisuals.max_chest_distance_m=100\nvisuals.max_chest_distance_m=200\n",
        "format_version=1\nunrecognized.key=123\n",
        "format_version=999\n"
    };
    for(const auto& payload:invalid_payloads) {
        { std::ofstream broken(directory/"invalid.ini"); broken<<payload; }
        REQUIRE(!load_settings(directory/"invalid.ini",loaded,error));
        REQUIRE(near(loaded.visuals.max_chest_distance_m,original.visuals.max_chest_distance_m));
    }
    { std::ofstream valid(directory/"clamped.ini"); valid<<"format_version=1\nvisuals.max_chest_distance_m=9999\n"; }
    REQUIRE(load_settings(directory/"clamped.ini",loaded,error));
    REQUIRE(near(loaded.visuals.max_chest_distance_m,1000));
    Settings invalid;
    invalid.visuals.max_chest_distance_m=std::numeric_limits<float>::quiet_NaN();
    invalid.automation.max_distance_m=5000; invalid.automation.speed_mps=-1;
    invalid.overlay.fps_limit=-100;
    normalize_settings(invalid);
    REQUIRE(std::isfinite(invalid.visuals.max_chest_distance_m));
    REQUIRE(invalid.visuals.max_chest_distance_m>=50 && invalid.visuals.max_chest_distance_m<=1000);
    REQUIRE(invalid.automation.max_distance_m>=50 && invalid.automation.max_distance_m<=1000);
    REQUIRE(invalid.automation.speed_mps>0); REQUIRE(invalid.overlay.fps_limit>=15);
}
}

int main() {
    const std::vector<std::pair<const char*,std::function<void()>>> tests={
        {"chest_state_filter",chest_state_filter},
        {"distance_limits_and_order",distance_limits_and_order},
        {"player_optional_fields",player_optional_fields},
        {"projection_contract",projection_contract},
        {"planner_obstacles_and_boundaries",planner_obstacles_and_boundaries},
        {"nearest_reachable_route_selection",nearest_reachable_route_selection},
        {"baseline_confirmed_openings",baseline_confirmed_openings},
        {"afk_off_collects_one",afk_off_collects_one},
        {"emergency_latch_and_rearm",emergency_latch_and_rearm},
        {"disabled_and_disconnect_stop",disabled_and_disconnect_stop},
        {"stale_snapshot_stops_controls",stale_snapshot_stops_controls},
        {"invalidated_target_removed",invalidated_target_removed},
        {"explicit_open_confirmation_without_navigation",explicit_open_confirmation_without_navigation},
        {"fault_scenarios_do_not_fake_success",fault_scenarios_do_not_fake_success},
        {"blocked_nearest_skipped",blocked_nearest_skipped},
        {"mock_movement_validation",mock_movement_validation},
        {"configuration_roundtrip_and_atomic_rejection",configuration_roundtrip_and_atomic_rejection}
    };
    int failures=0;
    for(const auto& [name,test]:tests) {
        try { test(); std::cout << "PASS " << name << '\n'; }
        catch(const std::exception& exception) { ++failures; std::cerr << "FAIL " << name << ": " << exception.what() << '\n'; }
    }
    std::cout << "RESULT " << tests.size()-static_cast<std::size_t>(failures) << '/' << tests.size() << " passed\n";
    return failures==0?0:1;
}
