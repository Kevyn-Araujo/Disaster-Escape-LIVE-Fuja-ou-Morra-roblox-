# Fortnite External Lab

Aplicativo externo para Windows em **C++20, Dear ImGui e DirectX 11**, com ESP de jogadores e baús e coleta automática em um **ambiente simulado reproduzível**.

**Esta entrega não detecta entidades de uma partida real de Fortnite e não envia comandos ao jogo.** O aplicativo executa `MockGameDataProvider`: posições, câmera, estados de baús e movimentos pertencem à simulação. O rótulo `MOCK DATA SIMULATOR` permanece visível.

## Executar no Visual Studio 2022

Requisitos: Windows 10/11 x64, Visual Studio 2022 com **Desenvolvimento para desktop com C++**, MSVC v143, Windows SDK e CMake **3.25 ou superior**. Dear ImGui já está incluído em `vendor/imgui`; não é necessário baixar bibliotecas durante o build.

Extraia o projeto e abra um Developer PowerShell do VS 2022 na pasta que contém `CMakeLists.txt`:

```powershell
cmake --preset vs2022
cmake --build --preset vs2022-release --parallel
ctest --preset vs2022-release
.\build\vs2022\Release\fortnite_external.exe
```

Para abrir a solução gerada no Visual Studio:

```powershell
cmake --open build/vs2022
```

O núcleo não precisa de privilégios administrativos. Se a GPU não fornecer um dispositivo D3D11 compatível, o aplicativo tenta o renderizador WARP. Erros de inicialização aparecem no console e no arquivo de log quando disponível.

## Usar a simulação

1. Em **Visuals**, configure ESP, cores e limites de distância. Baús são sempre filtrados por estado **Closed confirmado e disponível**. Estados Unknown/Open/Destroyed/Unavailable não contam como fechados.
2. Em **Auto Farm**, ative `Enable Auto Chest`. O personagem simulado seleciona a menor rota calculada entre alvos acessíveis, segue a malha, interage e aguarda a confirmação `Open` do provider.
3. `AFK Mode` repete a coleta. Desativá-lo limita a execução a um baú confirmado; desligue e ligue a automação para iniciar outro ciclo.
4. **F8** é a parada de emergência padrão. **Insert** mostra/esconde o menu. Os atalhos podem ser configurados em Settings. O botão de emergência também está no menu.
5. Em **Settings**, teste os cenários Baseline, Unknown States, Blocked, Stuck e Interaction Timeout; observe o status e os logs.
6. Salve/carregue configurações. O carregamento valida o arquivo antes de aplicá-lo e deixa a automação desativada, exigindo acionamento explícito.

O limite de baús começa em **1.000 m** e aceita **50–1.000 m**. Todas as coordenadas da simulação usam metros. O alcance não expande a malha: um baú pode estar no alcance visual e não possuir rota disponível.

O modo transparente usa DWM; click-through é aplicado à janela quando o menu está oculto. Os atalhos globais permitem reabrir o menu e parar a automação. A janela não se vincula automaticamente à janela do Fortnite.

## Implementado

- Snapshots consistentes com sincronização no provider e separação entre leitura de dados e comandos de controle.
- ESP de baús fechados, distância, contador, marcador e destaque do mais próximo; exclusão após confirmação de abertura no próximo snapshot consumido.
- ESP de jogadores com caixas, ossos, nome, distância, vida, escudo, snaplines, cabeça, contador, indicador de visibilidade e filtro de equipe, conforme campos realmente fornecidos.
- WorldToScreen com câmera/matriz válidas, clipping DirectX e rejeição de coordenadas inválidas. Campos ausentes são omitidos ou apresentados como desconhecidos.
- A* planar sobre grade, obstáculos, verificação de segmentos e proibição de atravessar cantos bloqueados.
- Estados IDLE, SEARCHING, SELECTING_CHEST, NAVIGATING, INTERACTING, VERIFYING e RECOVERING; timeout, detecção de falta de progresso, tentativas limitadas, cooldown e parada de emergência.
- Menu de três abas, configuração persistente validada, logs limitados, controle de FPS, vsync, redimensionamento e limpeza de recursos D3D11/ImGui.

## Testes e execução sem interface

No Linux com GCC/Clang C++20, CMake e Ninja:

```sh
cmake --preset portable
cmake --build --preset portable --parallel
ctest --preset portable
./build/portable/fe_headless --scenario baseline --steps 2000 --dt 0.05
```

No Windows, o executável equivalente é `build\vs2022\Release\fe_headless.exe`.
O passo simulado deve estar entre 0 e 0,25 s; o padrão de testes é **0,05 s**. Consulte `fe_headless --help` para cenários e códigos de saída.

Para ASan/UBSan em GCC/Clang Linux:

```sh
cmake --preset sanitizers
cmake --build --preset sanitizers --parallel
ctest --preset sanitizers
```

Os resultados observados nesta entrega, incluindo as limitações de verificação no Windows, estão em [docs/VALIDATION.md](docs/VALIDATION.md).

## Estrutura e integração adicional

```text
src/core/         Tipos, metros, câmera e projeção
src/data/         IGameDataProvider, IControlSink e simulador
src/overlay/      Janela Win32 e DirectX 11
src/esp/          Filtros e desenho do ESP
src/navigation/   Grade, colisão de segmentos e A*
src/automation/   Máquina de estados Auto Chest
src/ui/           Menu ImGui
src/config/       Configuração e validação
src/utils/        Logs
tests/            Regressões portáveis
docs/             Arquitetura, limites e resultados
```

Veja [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) e [docs/INTEGRATION.md](docs/INTEGRATION.md). A aquisição de dados reais exige uma fonte autorizada que efetivamente forneça os campos necessários; uma API de estatísticas ou metadados não basta. A navegação também exige uma malha confiável e um canal de controle autorizado. Essas integrações não estão incluídas.

Não há offsets, leitura de memória do jogo, DLL injetada, driver, evasão de anti-cheat ou manipulação das proteções do Fortnite nesta implementação.

Dependências e licenças: [THIRD_PARTY.md](THIRD_PARTY.md).
