#pragma once
#include <array>
#include <cmath>
#include <cstdint>
#include <optional>
#include <string>
#include <vector>

namespace fe {
using EntityId = std::uint64_t;
struct Vec2 { float x{}, y{}; };
struct Vec3 { float x{}, y{}, z{}; };
inline Vec3 operator+(Vec3 a, Vec3 b) { return {a.x+b.x,a.y+b.y,a.z+b.z}; }
inline Vec3 operator-(Vec3 a, Vec3 b) { return {a.x-b.x,a.y-b.y,a.z-b.z}; }
inline Vec3 operator*(Vec3 a, float s) { return {a.x*s,a.y*s,a.z*s}; }
inline float dot(Vec3 a, Vec3 b) { return a.x*b.x+a.y*b.y+a.z*b.z; }
inline float length(Vec3 a) { return std::sqrt(dot(a,a)); }
inline float distance(Vec3 a, Vec3 b) { return length(a-b); }
inline bool finite(Vec3 a) { return std::isfinite(a.x)&&std::isfinite(a.y)&&std::isfinite(a.z); }
struct Mat4 { std::array<float,16> values{}; }; // Row-major; clip = M * column vector.
struct Camera {
    Vec3 position{}, forward{0,0,1}, up{0,1,0};
    Mat4 view_projection{};
    bool valid{false};
};
Camera make_camera(Vec3 position, Vec3 target, float aspect, float vertical_fov_radians=1.04719755f);
std::optional<Vec2> world_to_screen(Vec3 world, const Camera& camera, float width, float height);

enum class ChestState { Unknown, Closed, Open, Destroyed, Unavailable };
struct Chest {
    EntityId id{};
    std::optional<Vec3> position;
    ChestState state{ChestState::Unknown};
    bool available{true};
};
struct BoneSegment { Vec3 from{}, to{}; };
struct Player {
    EntityId id{};
    std::optional<Vec3> position;
    std::optional<Vec3> head;
    std::optional<std::string> name;
    std::optional<float> health, max_health, shield, max_shield;
    std::optional<int> team;
    std::optional<bool> visible;
    std::vector<BoneSegment> skeleton;
    bool available{true};
};
struct NavigationGrid {
    int width{}, height{};
    float cell_size_m{1};
    Vec3 origin{}; // Lower-left corner on the XZ plane; positions use meters.
    std::vector<std::uint8_t> walkable;
    bool valid() const {
        return width>0&&height>0&&width<=4096&&height<=4096&&finite(origin)
            &&std::isfinite(cell_size_m)&&cell_size_m>0
            &&walkable.size()==static_cast<std::size_t>(width)*static_cast<std::size_t>(height);
    }
};
struct GameSnapshot {
    std::uint64_t sequence{};
    double simulation_time{};
    bool connected{true};
    std::optional<Vec3> local_position;
    std::optional<int> local_team;
    Camera camera;
    std::vector<Player> players;
    std::vector<Chest> chests;
    std::optional<NavigationGrid> navigation;
};
} // namespace fe
