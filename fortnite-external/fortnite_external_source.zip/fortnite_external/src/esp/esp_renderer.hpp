#pragma once
#include "core/types.hpp"
#include "config/settings.hpp"
namespace fe {
void draw_scene(const GameSnapshot& snapshot, const VisualSettings& settings,
                const std::vector<Vec3>& route, float width, float height);
} // namespace fe
