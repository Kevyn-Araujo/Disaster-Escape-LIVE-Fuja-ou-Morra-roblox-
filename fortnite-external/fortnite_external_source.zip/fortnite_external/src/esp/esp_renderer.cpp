#include "esp/esp_renderer.hpp"
#include "esp/filters.hpp"
#include "imgui.h"
#include <algorithm>
#include <cmath>
#include <cstdio>
#include <optional>
#include <string>

namespace fe {
namespace {
ImU32 tint(const Color& color) {
    return ImGui::ColorConvertFloat4ToU32(ImVec4(color[0],color[1],color[2],color[3]));
}
ImVec2 point(Vec2 value) { return {value.x,value.y}; }
void label(ImDrawList* draw, ImVec2 position, ImU32 color, const std::string& value) {
    draw->AddText(ImVec2(position.x+1,position.y+1),IM_COL32(0,0,0,230),value.c_str());
    draw->AddText(position,color,value.c_str());
}
std::optional<ImVec2> project(Vec3 value,const GameSnapshot& snapshot,float w,float h) {
    const auto p=world_to_screen(value,snapshot.camera,w,h);
    if (!p) return std::nullopt;
    return point(*p);
}
void line(ImDrawList* draw,Vec3 a,Vec3 b,const GameSnapshot& snapshot,
          float w,float h,ImU32 color,float thickness=1) {
    const auto x=project(a,snapshot,w,h), y=project(b,snapshot,w,h);
    if (x&&y) draw->AddLine(*x,*y,color,thickness);
}
void world_background(ImDrawList* draw,const GameSnapshot& snapshot,
                      const std::vector<Vec3>& route,float w,float h) {
    if (!snapshot.local_position||!finite(*snapshot.local_position)) return;
    const auto local=*snapshot.local_position;
    const float center_x=std::floor(local.x/10.0f)*10.0f;
    const float center_z=std::floor(local.z/10.0f)*10.0f;
    for (int offset=-12;offset<=12;++offset) {
        const float delta=offset*10.0f;
        line(draw,{center_x+delta,0,center_z-120},{center_x+delta,0,center_z+120},
             snapshot,w,h,IM_COL32(65,85,104,100));
        line(draw,{center_x-120,0,center_z+delta},{center_x+120,0,center_z+delta},
             snapshot,w,h,IM_COL32(65,85,104,100));
    }
    if (snapshot.navigation&&snapshot.navigation->valid()) {
        const auto& grid=*snapshot.navigation;
        std::size_t drawn=0;
        std::size_t inspected=0;
        const auto bounded_cell=[](double value,int maximum) {
            return static_cast<int>(std::clamp(value,0.0,static_cast<double>(maximum)));
        };
        const int min_x=bounded_cell(std::floor((static_cast<double>(local.x)-grid.origin.x-160)/grid.cell_size_m),grid.width-1);
        const int max_x=bounded_cell(std::ceil((static_cast<double>(local.x)-grid.origin.x+160)/grid.cell_size_m),grid.width-1);
        const int min_z=bounded_cell(std::floor((static_cast<double>(local.z)-grid.origin.z-160)/grid.cell_size_m),grid.height-1);
        const int max_z=bounded_cell(std::ceil((static_cast<double>(local.z)-grid.origin.z+160)/grid.cell_size_m),grid.height-1);
        for (int z=min_z;z<=max_z&&drawn<2000&&inspected<40000;++z) {
            for (int x=min_x;x<=max_x&&drawn<2000&&inspected<40000;++x) {
                ++inspected;
                if (grid.walkable[static_cast<std::size_t>(z)*grid.width+x]) continue;
                Vec3 a=grid.origin+Vec3{x*grid.cell_size_m,0,z*grid.cell_size_m};
                if (distance(a,local)>160) continue;
                Vec3 b=a+Vec3{grid.cell_size_m,0,0};
                Vec3 c=a+Vec3{grid.cell_size_m,0,grid.cell_size_m};
                Vec3 d=a+Vec3{0,0,grid.cell_size_m};
                const auto pa=project(a,snapshot,w,h),pb=project(b,snapshot,w,h);
                const auto pc=project(c,snapshot,w,h),pd=project(d,snapshot,w,h);
                if (pa&&pb&&pc&&pd) {
                    draw->AddQuadFilled(*pa,*pb,*pc,*pd,IM_COL32(135,58,62,110));
                    draw->AddQuad(*pa,*pb,*pc,*pd,IM_COL32(220,90,90,180));
                    ++drawn;
                }
            }
        }
    }
    for (std::size_t i=1;i<route.size();++i) {
        line(draw,route[i-1]+Vec3{0,.08f,0},route[i]+Vec3{0,.08f,0},
             snapshot,w,h,IM_COL32(70,230,160,220),2);
    }
}
void bar(ImDrawList* draw,float x,float top,float bottom,float value,float maximum,ImU32 color) {
    if (!std::isfinite(value)||!std::isfinite(maximum)||maximum<=0||value<0) return;
    const float fraction=std::clamp(value/maximum,0.0f,1.0f);
    draw->AddRectFilled({x,top},{x+4,bottom},IM_COL32(10,15,20,230));
    draw->AddRectFilled({x+1,bottom-(bottom-top)*fraction},{x+3,bottom},color);
}
}

void draw_scene(const GameSnapshot& snapshot,const VisualSettings& settings,
                const std::vector<Vec3>& route,float width,float height) {
    auto* draw=ImGui::GetBackgroundDrawList();
    const ImU32 text=IM_COL32(225,235,245,255);
    label(draw,{22,16},IM_COL32(90,210,255,255),"EXTERNAL LAB  /  MOCK DATA SIMULATOR");
    label(draw,{22,35},text,"No live Fortnite provider or game input is connected.");
    char hud[192];
    if (snapshot.local_position&&finite(*snapshot.local_position)) {
        const auto p=*snapshot.local_position;
        std::snprintf(hud,sizeof(hud),"Local: %.1f, %.1f, %.1f m  |  t=%.1f s  |  snapshot #%llu",
            p.x,p.y,p.z,snapshot.simulation_time,static_cast<unsigned long long>(snapshot.sequence));
        label(draw,{22,54},text,hud);
    }
    if (!snapshot.connected||!snapshot.camera.valid) {
        label(draw,{22,76},IM_COL32(255,125,100,255),"Data unavailable or invalid camera; entity rendering paused.");
        return;
    }
    world_background(draw,snapshot,route,width,height);
    if (!settings.enabled) return;

    if (settings.chests) {
        const auto chests=closed_chests(snapshot,settings.max_chest_distance_m);
        if (settings.chest_counter) {
            std::snprintf(hud,sizeof(hud),"Confirmed closed chests in range: %zu",chests.size());
            label(draw,{22,76},tint(settings.chest_color),hud);
        }
        for (std::size_t i=0;i<chests.size();++i) {
            const auto& candidate=chests[i];
            const auto screen=project(*candidate.chest.position+Vec3{0,.6f,0},snapshot,width,height);
            if (!screen) continue;
            const bool nearest=settings.nearest_highlight&&i==0;
            const auto color=tint(nearest?settings.nearest_color:settings.chest_color);
            if (settings.chest_marker) {
                const float size=std::clamp(100.0f/std::sqrt(std::max(1.0f,candidate.distance_m)),7.0f,24.0f);
                draw->AddRect({screen->x-size,screen->y-size*.55f},{screen->x+size,screen->y+size*.55f},color,2,0,nearest?3.0f:1.5f);
                draw->AddLine({screen->x-size,screen->y},{screen->x+size,screen->y},color);
                if (nearest) draw->AddCircle(*screen,size+5,color,20,1.5f);
            }
            std::string name=nearest?"Nearest chest":"Chest";
            if (settings.chest_distance) {
                char meters[40];
                std::snprintf(meters,sizeof(meters)," %.0f m",candidate.distance_m);
                name+=meters;
            }
            label(draw,{screen->x+12,screen->y-10},color,name);
        }
    }
    if (!settings.players) return;
    const auto players=visible_players(snapshot,settings.max_player_distance_m,settings.team_check);
    if (settings.player_count) {
        std::snprintf(hud,sizeof(hud),"Eligible players in range: %zu",players.size());
        label(draw,{22,95},tint(settings.player_color),hud);
    }
    for (const auto& player:players) {
        const auto foot=project(*player.position,snapshot,width,height);
        const auto head=player.head?project(*player.head,snapshot,width,height):std::nullopt;
        if (!foot&&!head) continue;
        const auto color=tint(player.visible&&!*player.visible?settings.hidden_color:settings.player_color);
        if (settings.skeleton) {
            for (const auto& bone:player.skeleton)
                if (finite(bone.from)&&finite(bone.to))
                    line(draw,bone.from,bone.to,snapshot,width,height,tint(settings.skeleton_color),1.5f);
        }
        if (settings.snaplines&&foot)
            draw->AddLine({width*.5f,height-2},*foot,tint(settings.snapline_color));
        if (settings.head_marker&&head)
            draw->AddCircle(*head,4,tint(settings.head_color),12,1.5f);
        if (head&&foot) {
            const float top=std::min(head->y,foot->y),bottom=std::max(head->y,foot->y);
            const float box_height=bottom-top;
            const float center=(head->x+foot->x)*.5f,half=box_height*.23f;
            if (box_height>=3) {
                if (settings.boxes) draw->AddRect({center-half,top},{center+half,bottom},color,0,0,1.5f);
                if (settings.health&&player.health&&player.max_health)
                    bar(draw,center-half-7,top,bottom,*player.health,*player.max_health,tint(settings.health_color));
                if (settings.shield&&player.shield&&player.max_shield)
                    bar(draw,center+half+3,top,bottom,*player.shield,*player.max_shield,tint(settings.shield_color));
            }
        }
        const auto anchor=head?*head:*foot;
        float y=anchor.y-18;
        if (settings.names&&player.name) {
            label(draw,{anchor.x+8,y},color,*player.name);
            y-=15;
        }
        if (settings.distance&&snapshot.local_position) {
            const float meters=distance(*snapshot.local_position,*player.position);
            if (std::isfinite(meters)) {
                std::snprintf(hud,sizeof(hud),"%.0f m",meters);
                label(draw,{anchor.x+8,y},text,hud);
                y-=15;
            }
        }
        if (settings.visibility)
            label(draw,{anchor.x+8,y},color,player.visible?(*player.visible?"Visible":"Hidden"):"Visibility unknown");
    }
}
} // namespace fe
