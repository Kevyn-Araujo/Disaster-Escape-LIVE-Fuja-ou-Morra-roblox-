#pragma once
#include <filesystem>
#include <string>
namespace fe {
struct Settings;
class MockGameDataProvider;
class AutoChestMachine;
class Logger;
struct MenuState {
    bool visible{true};
    bool show_logs{true};
    int scenario{};
    std::string config_status;
};
void draw_menu(MenuState& menu, Settings& settings, MockGameDataProvider& provider,
               AutoChestMachine& machine, Logger& logger,
               const std::filesystem::path& config_path);
} // namespace fe
