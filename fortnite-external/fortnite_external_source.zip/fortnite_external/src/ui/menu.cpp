#include "ui/menu.hpp"
#include "automation/auto_chest.hpp"
#include "config/settings.hpp"
#include "data/mock_game_data_provider.hpp"
#include "utils/logger.hpp"
#include "imgui.h"
#include <array>
#include <string>

namespace fe {
namespace {
void color(const char* label, Color& value) {
    ImGui::ColorEdit4(label, value.data(), ImGuiColorEditFlags_NoInputs);
}
void choose_hotkey(const char* label, int& value, const int* keys,
                   const char* const* labels, int count) {
    int selected = 0;
    for (int i=0;i<count;++i) if (keys[i]==value) selected=i;
    if (ImGui::Combo(label,&selected,labels,count)) value=keys[selected];
}
void logs(Logger& logger) {
    if (ImGui::BeginChild("LogEntries", ImVec2(0,170), true)) {
        const auto entries = logger.entries();
        const bool follow = ImGui::GetScrollY() >= ImGui::GetScrollMaxY()-2.0f;
        for (const auto& entry : entries) {
            const ImVec4 tint = entry.level==LogLevel::Error ? ImVec4(1,.35f,.35f,1)
                : entry.level==LogLevel::Warning ? ImVec4(1,.75f,.3f,1)
                : ImVec4(.72f,.79f,.86f,1);
            ImGui::PushStyleColor(ImGuiCol_Text,tint);
            ImGui::TextWrapped("[%s] %s",entry.time.c_str(),entry.message.c_str());
            ImGui::PopStyleColor();
        }
        if (follow) ImGui::SetScrollHereY(1.0f);
    }
    ImGui::EndChild();
}
}

void draw_menu(MenuState& menu, Settings& settings, MockGameDataProvider& provider,
               AutoChestMachine& machine, Logger& logger,
               const std::filesystem::path& config_path) {
    if (!menu.visible) return;
    ImGui::SetNextWindowPos(ImVec2(22,115),ImGuiCond_FirstUseEver);
    ImGui::SetNextWindowSize(ImVec2(450,640),ImGuiCond_FirstUseEver);
    if (!ImGui::Begin("External Lab | MOCK SIMULATOR",nullptr,
                      ImGuiWindowFlags_NoCollapse)) {
        ImGui::End();
        return;
    }
    ImGui::TextColored(ImVec4(.3f,.85f,1,1),"Data source: MockGameDataProvider");
    ImGui::TextWrapped("All entities and controls belong to this simulator. No live Fortnite connection.");
    ImGui::Separator();
    if (ImGui::BeginTabBar("MainTabs")) {
        if (ImGui::BeginTabItem("Visuals")) {
            auto& v=settings.visuals;
            ImGui::Checkbox("Enable ESP",&v.enabled);
            if (ImGui::CollapsingHeader("Player ESP",ImGuiTreeNodeFlags_DefaultOpen)) {
                ImGui::Checkbox("Player ESP",&v.players);
                ImGui::Checkbox("2D boxes",&v.boxes); ImGui::SameLine();
                ImGui::Checkbox("Skeleton",&v.skeleton);
                ImGui::Checkbox("Names",&v.names); ImGui::SameLine();
                ImGui::Checkbox("Distance",&v.distance);
                ImGui::Checkbox("Health bar",&v.health); ImGui::SameLine();
                ImGui::Checkbox("Shield bar",&v.shield);
                ImGui::Checkbox("Snaplines",&v.snaplines); ImGui::SameLine();
                ImGui::Checkbox("Head marker",&v.head_marker);
                ImGui::Checkbox("Player count",&v.player_count);
                ImGui::Checkbox("Visible / Hidden / Unknown",&v.visibility);
                ImGui::Checkbox("Team check (known teams only)",&v.team_check);
                ImGui::SliderFloat("Max player distance",&v.max_player_distance_m,50,1000,"%.0f m");
            }
            if (ImGui::CollapsingHeader("Chest ESP",ImGuiTreeNodeFlags_DefaultOpen)) {
                ImGui::Checkbox("Chest ESP",&v.chests);
                ImGui::TextDisabled("Closed Chests Only: enforced");
                ImGui::Checkbox("Chest distance",&v.chest_distance);
                ImGui::Checkbox("Chest marker",&v.chest_marker);
                ImGui::Checkbox("Nearest chest highlight",&v.nearest_highlight);
                ImGui::Checkbox("Chest counter",&v.chest_counter);
                ImGui::SliderFloat("Max chest distance",&v.max_chest_distance_m,50,1000,"%.0f m");
            }
            if (ImGui::CollapsingHeader("ESP colors")) {
                color("Players / visible",v.player_color); color("Hidden players",v.hidden_color);
                color("Chest",v.chest_color); color("Nearest chest",v.nearest_color);
                color("Skeleton",v.skeleton_color); color("Snaplines",v.snapline_color);
                color("Head marker",v.head_color); color("Health",v.health_color);
                color("Shield",v.shield_color);
            }
            ImGui::TextWrapped("Missing health, shields, bones, or names are omitted; unknown visibility stays unknown.");
            ImGui::EndTabItem();
        }
        if (ImGui::BeginTabItem("Auto Farm")) {
            auto& a=settings.automation;
            ImGui::Checkbox("Enable Auto Chest (simulator)",&a.enabled);
            ImGui::Checkbox("AFK mode: continue after each chest",&a.afk_mode);
            ImGui::Checkbox("Auto navigate",&a.auto_navigate);
            ImGui::Checkbox("Auto interact",&a.auto_interact);
            ImGui::TextDisabled("Target: nearest reachable confirmed-closed chest");
            ImGui::SliderFloat("Search distance",&a.max_distance_m,50,1000,"%.0f m");
            ImGui::SliderFloat("Movement speed",&a.speed_mps,1,20,"%.1f m/s");
            ImGui::SliderFloat("Interaction range",&a.interaction_distance_m,.5f,2,"%.1f m");
            if (ImGui::CollapsingHeader("Recovery settings")) {
                ImGui::SliderFloat("Stuck timeout",&a.stuck_timeout_s,.5f,10,"%.1f s");
                ImGui::SliderFloat("Interaction timeout",&a.interaction_timeout_s,.5f,10,"%.1f s");
                ImGui::SliderFloat("Verification timeout",&a.verification_timeout_s,.5f,10,"%.1f s");
                ImGui::SliderFloat("Progress threshold",&a.progress_epsilon_m,.01f,.5f,"%.2f m");
                ImGui::SliderInt("Retries per target",&a.max_retries,0,5);
            }
            ImGui::Separator();
            const std::string state(state_name(machine.state()));
            ImGui::Text("State: %s",state.c_str());
            if (const auto target=machine.target())
                ImGui::Text("Target ID: %llu",static_cast<unsigned long long>(*target));
            else ImGui::TextUnformatted("Target ID: none");
            ImGui::Text("Recovery attempts: %d",machine.attempts());
            ImGui::TextWrapped("%s",machine.status().c_str());
            ImGui::PushStyleColor(ImGuiCol_Button,ImVec4(.65f,.12f,.15f,1));
            if (ImGui::Button("EMERGENCY STOP",ImVec2(-1,35))) {
                machine.emergency_stop(provider);
                a.enabled=false;
                logger.warn("Emergency stop pressed in menu.");
            }
            ImGui::PopStyleColor();
            ImGui::EndTabItem();
        }
        if (ImGui::BeginTabItem("Settings")) {
            if (ImGui::CollapsingHeader("Hotkeys",ImGuiTreeNodeFlags_DefaultOpen)) {
                constexpr int menu_keys[]{0x2D,0x24,0x75,0x76};
                constexpr const char* menu_labels[]{"Insert","Home","F6","F7"};
                constexpr int stop_keys[]{0x77,0x78,0x79,0x7A};
                constexpr const char* stop_labels[]{"F8","F9","F10","F11"};
                choose_hotkey("Toggle menu",settings.overlay.menu_key,menu_keys,menu_labels,4);
                choose_hotkey("Emergency stop",settings.overlay.emergency_key,stop_keys,stop_labels,4);
                ImGui::TextWrapped("Hotkeys are registered globally. Any conflict is recorded in Debug Logs.");
            }
            if (ImGui::CollapsingHeader("Overlay settings",ImGuiTreeNodeFlags_DefaultOpen)) {
                ImGui::Checkbox("Transparent + topmost",&settings.overlay.transparent);
                ImGui::Checkbox("Click-through while menu is hidden",&settings.overlay.click_through);
                ImGui::TextDisabled("Click-through requires both global hotkeys to be available.");
                ImGui::TextWrapped("The menu hotkey restores mouse interaction. The window is a simulator, not attached to Fortnite.");
            }
            if (ImGui::CollapsingHeader("Performance",ImGuiTreeNodeFlags_DefaultOpen)) {
                ImGui::SliderInt("FPS limit",&settings.overlay.fps_limit,15,240);
                ImGui::Checkbox("Vertical sync",&settings.overlay.vsync);
                ImGui::Text("Frame rate: %.1f FPS",ImGui::GetIO().Framerate);
            }
            ImGui::Separator();
            if (ImGui::Button("Save configuration")) {
                std::string error;
                const bool ok=save_settings(config_path,settings,error);
                menu.config_status=ok ? "Configuration saved." : "Save failed: "+error;
                logger.log(ok ? LogLevel::Info : LogLevel::Error,menu.config_status);
            }
            ImGui::SameLine();
            if (ImGui::Button("Load configuration")) {
                std::string error;
                Settings loaded=settings;
                if (load_settings(config_path,loaded,error)) {
                    machine.emergency_stop(provider);
                    loaded.automation.enabled=false;
                    settings=loaded;
                    menu.config_status="Configuration loaded; automation is disabled.";
                    logger.info(menu.config_status);
                } else {
                    menu.config_status="Load failed: "+error;
                    logger.error(menu.config_status);
                }
            }
            ImGui::TextWrapped("%s",menu.config_status.c_str());
            ImGui::TextWrapped("Configuration: %s",config_path.string().c_str());
            ImGui::Separator();
            constexpr const char* scenarios[]{"Baseline","Unknown states","Blocked target","Stuck movement","Interaction timeout"};
            ImGui::Combo("Reproducible scenario",&menu.scenario,scenarios,5);
            if (ImGui::Button("Reset simulator")) {
                machine.emergency_stop(provider);
                settings.automation.enabled=false;
                provider.set_scenario(static_cast<MockScenario>(menu.scenario));
                logger.info(std::string("Scenario reset: ")+scenarios[menu.scenario]);
            }
            ImGui::Checkbox("Debug Logs",&menu.show_logs);
            if (menu.show_logs) logs(logger);
            ImGui::EndTabItem();
        }
        ImGui::EndTabBar();
    }
    ImGui::End();
}
} // namespace fe
