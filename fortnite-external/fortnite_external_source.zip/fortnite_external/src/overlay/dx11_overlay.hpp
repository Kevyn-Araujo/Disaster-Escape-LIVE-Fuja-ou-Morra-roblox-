#pragma once
#include <filesystem>
namespace fe {
struct Settings;
class MockGameDataProvider;
class AutoChestMachine;
class Logger;
class Dx11Overlay {
public:
    int run(Settings& settings, MockGameDataProvider& provider,
            AutoChestMachine& machine, Logger& logger,
            const std::filesystem::path& config_path);
};
} // namespace fe
