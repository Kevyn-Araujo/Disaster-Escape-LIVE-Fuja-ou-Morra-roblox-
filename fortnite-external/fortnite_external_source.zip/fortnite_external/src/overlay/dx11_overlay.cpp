#ifndef WIN32_LEAN_AND_MEAN
#define WIN32_LEAN_AND_MEAN
#endif
#ifndef NOMINMAX
#define NOMINMAX
#endif
#include "overlay/dx11_overlay.hpp"
#include "automation/auto_chest.hpp"
#include "config/settings.hpp"
#include "data/mock_game_data_provider.hpp"
#include "esp/esp_renderer.hpp"
#include "ui/menu.hpp"
#include "utils/logger.hpp"
#include <windows.h>
#include <d3d11.h>
#include <dxgi.h>
#include <dwmapi.h>
#include "imgui.h"
#include "backends/imgui_impl_dx11.h"
#include "backends/imgui_impl_win32.h"
#include <algorithm>
#include <chrono>
#include <iostream>
#include <string>
#include <thread>

// The backend intentionally keeps this declaration out of its public header.
extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND,UINT,WPARAM,LPARAM);

namespace fe {
namespace {
constexpr int menu_hotkey_id=1, stop_hotkey_id=2;
constexpr wchar_t window_class[]=L"ExternalLabMockWindow";

template<class T> void release(T*& object) {
    if (object) { object->Release(); object=nullptr; }
}
struct Graphics {
    ID3D11Device* device{};
    ID3D11DeviceContext* context{};
    IDXGISwapChain* swap_chain{};
    ID3D11RenderTargetView* target{};
    ~Graphics() {
        if (context) context->ClearState();
        release(target); release(swap_chain); release(context); release(device);
    }
    bool create_target() {
        ID3D11Texture2D* back_buffer{};
        HRESULT result=swap_chain->GetBuffer(0,__uuidof(ID3D11Texture2D),
                                             reinterpret_cast<void**>(&back_buffer));
        if (FAILED(result)) return false;
        result=device->CreateRenderTargetView(back_buffer,nullptr,&target);
        release(back_buffer);
        return SUCCEEDED(result);
    }
    bool initialize(HWND window,Logger& logger) {
        DXGI_SWAP_CHAIN_DESC description{};
        description.BufferCount=2;
        description.BufferDesc.Format=DXGI_FORMAT_R8G8B8A8_UNORM;
        description.BufferUsage=DXGI_USAGE_RENDER_TARGET_OUTPUT;
        description.OutputWindow=window;
        description.SampleDesc.Count=1;
        description.Windowed=TRUE;
        description.SwapEffect=DXGI_SWAP_EFFECT_DISCARD;
        constexpr D3D_FEATURE_LEVEL levels[]{D3D_FEATURE_LEVEL_11_0,D3D_FEATURE_LEVEL_10_0};
        D3D_FEATURE_LEVEL selected{};
        HRESULT result=D3D11CreateDeviceAndSwapChain(nullptr,D3D_DRIVER_TYPE_HARDWARE,
            nullptr,0,levels,2,D3D11_SDK_VERSION,&description,&swap_chain,&device,&selected,&context);
        if (FAILED(result)) {
            release(swap_chain); release(context); release(device);
            logger.warn("Hardware DirectX initialization failed; trying WARP software rendering.");
            result=D3D11CreateDeviceAndSwapChain(nullptr,D3D_DRIVER_TYPE_WARP,
                nullptr,0,levels,2,D3D11_SDK_VERSION,&description,&swap_chain,&device,&selected,&context);
        }
        return SUCCEEDED(result)&&create_target();
    }
    bool resize(UINT width,UINT height) {
        context->OMSetRenderTargets(0,nullptr,nullptr);
        release(target);
        if (FAILED(swap_chain->ResizeBuffers(0,width,height,DXGI_FORMAT_UNKNOWN,0))) return false;
        return create_target();
    }
};
struct WindowState {
    bool minimized{}, resize_pending{}, toggle_menu{}, emergency{};
    UINT width{1280},height{800};
    int menu_key{VK_INSERT},stop_key{VK_F8};
    bool menu_registered{},stop_registered{};
};
LRESULT CALLBACK window_proc(HWND window,UINT message,WPARAM wparam,LPARAM lparam) {
    auto* state=reinterpret_cast<WindowState*>(GetWindowLongPtrW(window,GWLP_USERDATA));
    if (message==WM_NCCREATE) {
        auto* creation=reinterpret_cast<CREATESTRUCTW*>(lparam);
        state=static_cast<WindowState*>(creation->lpCreateParams);
        SetWindowLongPtrW(window,GWLP_USERDATA,reinterpret_cast<LONG_PTR>(state));
    }
    // Handle hotkeys before ImGui, including when text input has keyboard focus.
    if (state&&message==WM_HOTKEY) {
        if (wparam==menu_hotkey_id) state->toggle_menu=true;
        if (wparam==stop_hotkey_id) state->emergency=true;
        return 0;
    }
    if (state&&message==WM_KEYDOWN&&(lparam&(1LL<<30))==0) {
        if (!state->menu_registered&&static_cast<int>(wparam)==state->menu_key)
            state->toggle_menu=true;
        if (!state->stop_registered&&static_cast<int>(wparam)==state->stop_key)
            state->emergency=true;
    }
    if (ImGui::GetCurrentContext()&&
        ImGui_ImplWin32_WndProcHandler(window,message,wparam,lparam)) return 1;
    switch (message) {
    case WM_SIZE:
        if (state) {
            state->minimized=wparam==SIZE_MINIMIZED;
            if (!state->minimized&&LOWORD(lparam)>0&&HIWORD(lparam)>0) {
                state->width=LOWORD(lparam); state->height=HIWORD(lparam);
                state->resize_pending=true;
            }
        }
        return 0;
    case WM_SYSCOMMAND:
        if ((wparam&0xFFF0)==SC_KEYMENU) return 0;
        break;
    case WM_DESTROY: PostQuitMessage(0); return 0;
    }
    return DefWindowProcW(window,message,wparam,lparam);
}
struct WindowOwner {
    HINSTANCE instance{GetModuleHandleW(nullptr)};
    HWND window{};
    bool registered{};
    ~WindowOwner() {
        if (window) {
            UnregisterHotKey(window,menu_hotkey_id);
            UnregisterHotKey(window,stop_hotkey_id);
            if (IsWindow(window)) DestroyWindow(window);
        }
        if (registered) UnregisterClassW(window_class,instance);
    }
    bool initialize(WindowState& state) {
        WNDCLASSEXW description{};
        description.cbSize=sizeof(description);
        description.style=CS_HREDRAW|CS_VREDRAW;
        description.lpfnWndProc=window_proc;
        description.hInstance=instance;
        description.hCursor=LoadCursorW(nullptr,MAKEINTRESOURCEW(32512));
        description.hbrBackground=static_cast<HBRUSH>(GetStockObject(BLACK_BRUSH));
        description.lpszClassName=window_class;
        registered=RegisterClassExW(&description)!=0;
        if (!registered) return false;
        RECT size{0,0,static_cast<LONG>(state.width),static_cast<LONG>(state.height)};
        AdjustWindowRectEx(&size,WS_OVERLAPPEDWINDOW,FALSE,0);
        window=CreateWindowExW(0,window_class,L"External Lab - MOCK Simulator (no Fortnite connection)",
            WS_OVERLAPPEDWINDOW,CW_USEDEFAULT,CW_USEDEFAULT,size.right-size.left,size.bottom-size.top,
            nullptr,nullptr,instance,&state);
        return window!=nullptr;
    }
};
struct ImGuiOwner {
    bool context{},win32{},dx11{};
    ~ImGuiOwner() {
        if (dx11) ImGui_ImplDX11_Shutdown();
        if (win32) ImGui_ImplWin32_Shutdown();
        if (context) ImGui::DestroyContext();
    }
    bool initialize(HWND window,Graphics& graphics) {
        IMGUI_CHECKVERSION();
        ImGui::CreateContext(); context=true;
        ImGui::GetIO().ConfigFlags|=ImGuiConfigFlags_NavEnableKeyboard;
        ImGui::StyleColorsDark();
        auto& style=ImGui::GetStyle();
        style.WindowRounding=8; style.FrameRounding=4; style.GrabRounding=4;
        style.WindowPadding={14,14}; style.ItemSpacing={8,7};
        style.Colors[ImGuiCol_WindowBg]={.045f,.06f,.08f,.98f};
        style.Colors[ImGuiCol_Header]={.08f,.21f,.29f,1};
        style.Colors[ImGuiCol_Button]={.08f,.24f,.32f,1};
        win32=ImGui_ImplWin32_Init(window);
        if (!win32) return false;
        dx11=ImGui_ImplDX11_Init(graphics.device,graphics.context);
        return dx11;
    }
};
void update_hotkeys(HWND window,WindowState& state,const OverlaySettings& settings,Logger& logger) {
    if (state.menu_key!=settings.menu_key||!state.menu_registered) {
        UnregisterHotKey(window,menu_hotkey_id);
        state.menu_key=settings.menu_key;
        state.menu_registered=RegisterHotKey(window,menu_hotkey_id,MOD_NOREPEAT,state.menu_key)!=0;
        if (!state.menu_registered)
            logger.warn("Menu global hotkey unavailable; focused-window fallback is active.");
    }
    if (state.stop_key!=settings.emergency_key||!state.stop_registered) {
        UnregisterHotKey(window,stop_hotkey_id);
        state.stop_key=settings.emergency_key;
        state.stop_registered=RegisterHotKey(window,stop_hotkey_id,MOD_NOREPEAT,state.stop_key)!=0;
        if (!state.stop_registered)
            logger.warn("Emergency global hotkey unavailable; focused-window fallback is active.");
    }
}
void update_window_style(HWND window,bool transparent,bool click_through) {
    LONG_PTR style=GetWindowLongPtrW(window,GWL_EXSTYLE);
    style&=~static_cast<LONG_PTR>(WS_EX_LAYERED|WS_EX_TRANSPARENT|WS_EX_NOACTIVATE);
    if (transparent||click_through) style|=WS_EX_LAYERED;
    if (click_through) style|=WS_EX_TRANSPARENT|WS_EX_NOACTIVATE;
    SetWindowLongPtrW(window,GWL_EXSTYLE,style);
    if (transparent) SetLayeredWindowAttributes(window,RGB(0,0,0),255,LWA_COLORKEY);
    else if (click_through) SetLayeredWindowAttributes(window,0,255,LWA_ALPHA);
    MARGINS margins{};
    if (transparent) margins={-1,-1,-1,-1};
    DwmExtendFrameIntoClientArea(window,&margins);
    SetWindowPos(window,transparent?HWND_TOPMOST:HWND_NOTOPMOST,0,0,0,0,
                 SWP_NOMOVE|SWP_NOSIZE|SWP_NOACTIVATE|SWP_FRAMECHANGED);
}
}

int Dx11Overlay::run(Settings& settings,MockGameDataProvider& provider,
                     AutoChestMachine& machine,Logger& logger,
                     const std::filesystem::path& config_path) {
    WindowState state;
    WindowOwner window;
    if (!window.initialize(state)) {
        logger.error("Win32 window creation failed.");
        std::cerr<<"Win32 window creation failed.\n";
        return 1;
    }
    Graphics graphics;
    if (!graphics.initialize(window.window,logger)) {
        logger.error("DirectX 11 initialization failed, including WARP fallback.");
        MessageBoxW(window.window,L"DirectX 11 initialization failed. See fortnite_external.log.",
                    L"External Lab",MB_OK|MB_ICONERROR);
        return 1;
    }
    ImGuiOwner imgui;
    if (!imgui.initialize(window.window,graphics)) {
        logger.error("ImGui backend initialization failed.");
        return 1;
    }
    MenuState menu;
    update_hotkeys(window.window,state,settings.overlay,logger);
    int registered_menu_key=settings.overlay.menu_key;
    int registered_stop_key=settings.overlay.emergency_key;
    bool applied_transparent=!settings.overlay.transparent;
    bool applied_click_through=true;
    bool click_through_warning=false;
    ShowWindow(window.window,SW_SHOWDEFAULT);
    UpdateWindow(window.window);
    auto previous=std::chrono::steady_clock::now();
    bool done=false;
    int result=0;
    while (!done) {
        const auto frame_start=std::chrono::steady_clock::now();
        MSG message{};
        while (PeekMessageW(&message,nullptr,0,0,PM_REMOVE)) {
            if (message.message==WM_QUIT) { done=true; break; }
            TranslateMessage(&message); DispatchMessageW(&message);
        }
        if (done) break;
        if (state.toggle_menu) {
            menu.visible=!menu.visible;
            state.toggle_menu=false;
            if (menu.visible) {
                update_window_style(window.window,settings.overlay.transparent,false);
                applied_transparent=settings.overlay.transparent;
                applied_click_through=false;
                ShowWindow(window.window,SW_RESTORE);
                SetForegroundWindow(window.window);
            }
        }
        if (state.emergency) {
            machine.emergency_stop(provider);
            settings.automation.enabled=false;
            logger.warn("Global/focused emergency hotkey pressed.");
            state.emergency=false;
        }
        if (registered_menu_key!=settings.overlay.menu_key||
            registered_stop_key!=settings.overlay.emergency_key) {
            update_hotkeys(window.window,state,settings.overlay,logger);
            registered_menu_key=settings.overlay.menu_key;
            registered_stop_key=settings.overlay.emergency_key;
        }
        if (!state.menu_registered&&!menu.visible) {
            menu.visible=true;
            logger.warn("Menu remains visible because its global recovery hotkey is unavailable.");
        }
        const bool hotkeys_ready=state.menu_registered&&state.stop_registered;
        const bool click_through=settings.overlay.click_through&&!menu.visible&&hotkeys_ready;
        if (settings.overlay.click_through&&!hotkeys_ready&&!click_through_warning) {
            logger.warn("Click-through disabled because both global hotkeys must be registered.");
            click_through_warning=true;
        }
        if (!settings.overlay.click_through||hotkeys_ready) click_through_warning=false;
        if (applied_transparent!=settings.overlay.transparent||applied_click_through!=click_through) {
            update_window_style(window.window,settings.overlay.transparent,click_through);
            applied_transparent=settings.overlay.transparent;
            applied_click_through=click_through;
        }
        if (state.resize_pending&&!state.minimized) {
            if (!graphics.resize(state.width,state.height)) {
                logger.error("Swap-chain resize failed; stopping simulator.");
                result=2; break;
            }
            state.resize_pending=false;
        }
        const double seconds=std::clamp(std::chrono::duration<double>(frame_start-previous).count(),0.0,.1);
        previous=frame_start;
        provider.set_aspect_ratio(static_cast<float>(state.width)/std::max(1u,state.height));
        provider.tick(seconds);
        auto snapshot=provider.snapshot();
        machine.update(snapshot,provider,settings.automation,seconds);
        snapshot=provider.snapshot();
        if (state.minimized) {
            std::this_thread::sleep_for(std::chrono::milliseconds(30));
            continue;
        }
        ImGui_ImplDX11_NewFrame();
        ImGui_ImplWin32_NewFrame();
        ImGui::NewFrame();
        draw_scene(snapshot,settings.visuals,machine.route(),
                   static_cast<float>(state.width),static_cast<float>(state.height));
        draw_menu(menu,settings,provider,machine,logger,config_path);
        ImGui::Render();
        const float normal[]{.025f,.035f,.05f,1};
        const float transparent[]{0,0,0,0};
        graphics.context->OMSetRenderTargets(1,&graphics.target,nullptr);
        graphics.context->ClearRenderTargetView(graphics.target,settings.overlay.transparent?transparent:normal);
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
        const HRESULT presented=graphics.swap_chain->Present(settings.overlay.vsync?1:0,0);
        if (FAILED(presented)) {
            logger.error("DirectX presentation failed; stopping simulator.");
            result=2; break;
        }
        if (presented==DXGI_STATUS_OCCLUDED)
            std::this_thread::sleep_for(std::chrono::milliseconds(30));
        const auto frame_duration=std::chrono::duration<double>(1.0/std::clamp(settings.overlay.fps_limit,15,240));
        std::this_thread::sleep_until(frame_start+
            std::chrono::duration_cast<std::chrono::steady_clock::duration>(frame_duration));
    }
    machine.emergency_stop(provider);
    logger.info("Simulator stopped; controls released.");
    return result;
}
} // namespace fe
