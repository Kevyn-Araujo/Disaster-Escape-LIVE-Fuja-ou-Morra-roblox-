#include "data/mock_game_data_provider.hpp"
#include <algorithm>
#include <cmath>
#include <limits>
#include <mutex>

namespace fe {
namespace {
bool cell_open(const NavigationGrid& grid, int x, int z) {
    return x >= 0 && z >= 0 && x < grid.width && z < grid.height &&
        grid.walkable[static_cast<std::size_t>(z) * grid.width + x] != 0;
}

// Supercover traversal includes both side cells when crossing a grid corner.
bool segment_open(const NavigationGrid& grid, Vec3 from, Vec3 to) {
    if (!grid.valid() || !finite(from) || !finite(to)) return false;
    const double sx = (static_cast<double>(from.x) - grid.origin.x) / grid.cell_size_m;
    const double sz = (static_cast<double>(from.z) - grid.origin.z) / grid.cell_size_m;
    const double ex = (static_cast<double>(to.x) - grid.origin.x) / grid.cell_size_m;
    const double ez = (static_cast<double>(to.z) - grid.origin.z) / grid.cell_size_m;
    if (sx < 0 || sz < 0 || ex < 0 || ez < 0 || sx >= grid.width || ex >= grid.width ||
        sz >= grid.height || ez >= grid.height) return false;
    int x = static_cast<int>(std::floor(sx)), z = static_cast<int>(std::floor(sz));
    const int end_x = static_cast<int>(std::floor(ex)), end_z = static_cast<int>(std::floor(ez));
    if (!cell_open(grid, x, z) || !cell_open(grid, end_x, end_z)) return false;
    const double dx = ex - sx, dz = ez - sz;
    const int step_x = (dx > 0) - (dx < 0), step_z = (dz > 0) - (dz < 0);
    const double infinity = std::numeric_limits<double>::infinity();
    const double delta_x = step_x ? std::abs(1.0 / dx) : infinity;
    const double delta_z = step_z ? std::abs(1.0 / dz) : infinity;
    double edge_x = step_x ? ((step_x > 0 ? x + 1.0 : x) - sx) / dx : infinity;
    double edge_z = step_z ? ((step_z > 0 ? z + 1.0 : z) - sz) / dz : infinity;
    const int maximum_steps = grid.width + grid.height + 2;
    for (int steps = 0; (x != end_x || z != end_z) && steps < maximum_steps; ++steps) {
        if (std::abs(edge_x - edge_z) < 1e-10) {
            if (!cell_open(grid, x + step_x, z) || !cell_open(grid, x, z + step_z)) return false;
            x += step_x; z += step_z;
            edge_x += delta_x; edge_z += delta_z;
        } else if (edge_x < edge_z) {
            x += step_x;
            edge_x += delta_x;
        } else {
            z += step_z;
            edge_z += delta_z;
        }
        if (!cell_open(grid, x, z)) return false;
    }
    return x == end_x && z == end_z;
}

void update_skeleton(Player& player) {
    if (!player.position) return;
    const Vec3 p = *player.position;
    player.head = p + Vec3{0, 1.75f, 0};
    const auto add = [&](Vec3 a, Vec3 b) { player.skeleton.push_back({p + a, p + b}); };
    player.skeleton.clear();
    add({0,1.75f,0}, {0,1.48f,0});
    add({0,1.48f,0}, {0,0.9f,0});
    add({-0.25f,1.45f,0}, {0.25f,1.45f,0});
    add({-0.25f,1.45f,0}, {-0.43f,1.15f,0});
    add({-0.43f,1.15f,0}, {-0.5f,0.9f,0});
    add({0.25f,1.45f,0}, {0.43f,1.15f,0});
    add({0.43f,1.15f,0}, {0.5f,0.9f,0});
    add({0,0.9f,0}, {-0.16f,0.85f,0});
    add({0,0.9f,0}, {0.16f,0.85f,0});
    add({-0.16f,0.85f,0}, {-0.16f,0.45f,0});
    add({-0.16f,0.45f,0}, {-0.16f,0.05f,0.1f});
    add({0.16f,0.85f,0}, {0.16f,0.45f,0});
    add({0.16f,0.45f,0}, {0.16f,0.05f,0.1f});
}
} // namespace

MockGameDataProvider::MockGameDataProvider(MockScenario scenario) { reset_unlocked(scenario); }

void MockGameDataProvider::reset_unlocked(MockScenario scenario) {
    const auto next_sequence = snapshot_.sequence + 1;
    snapshot_ = {};
    snapshot_.sequence = next_sequence;
    snapshot_.connected = true;
    snapshot_.local_position = Vec3{0,0,0};
    snapshot_.local_team = 1;
    scenario_ = scenario;
    pending_chest_.reset();
    opening_at_ = 0;
    snapshot_.chests = {
        {101,Vec3{6,0,12},ChestState::Closed,true},
        {102,Vec3{-10,0,24},ChestState::Closed,true},
        {103,Vec3{28,0,40},ChestState::Closed,true},
        {104,Vec3{-5,0,16},ChestState::Open,true},
        {105,Vec3{12,0,8},ChestState::Destroyed,true},
        {106,Vec3{4,0,20},ChestState::Unknown,true},
        {107,Vec3{10,0,14},ChestState::Closed,false},
        {108,Vec3{1100,0,20},ChestState::Closed,true},
        {109,std::nullopt,ChestState::Closed,true},
        {110,Vec3{14,0,20},ChestState::Unavailable,true}
    };
    if (scenario == MockScenario::UnknownStates)
        for (auto& chest : snapshot_.chests)
            if (chest.state == ChestState::Closed) chest.state = ChestState::Unknown;

    NavigationGrid grid;
    grid.width = 128; grid.height = 128;
    grid.cell_size_m = 2;
    grid.origin = {-128,0,-128};
    grid.walkable.assign(static_cast<std::size_t>(grid.width) * grid.height, 1);
    const auto block = [&](int x, int z) { grid.walkable[static_cast<std::size_t>(z)*grid.width+x] = 0; };
    for (int z = 68; z <= 78; ++z)
        for (int x = 70; x <= 71; ++x) block(x,z);
    if (scenario == MockScenario::Blocked) {
        for (int z = 69; z <= 71; ++z)
            for (int x = 66; x <= 68; ++x)
                if (x != 67 || z != 70) block(x,z);
    }
    snapshot_.navigation = std::move(grid);

    Player first;
    first.id=201; first.position=Vec3{-5,0,18}; first.name="Maya";
    first.health=80; first.max_health=100; first.shield=45; first.max_shield=100;
    first.team=2; first.visible=true; update_skeleton(first);
    Player second=first;
    second.id=202; second.position=Vec3{10,0,28}; second.name="Rafael";
    second.health=55; second.shield=10; second.team=3; second.visible=false; update_skeleton(second);
    Player teammate=first;
    teammate.id=203; teammate.position=Vec3{4,0,12}; teammate.name="Aiko";
    teammate.health=100; teammate.shield=100; teammate.team=1; update_skeleton(teammate);
    Player incomplete;
    incomplete.id=204; incomplete.position=Vec3{-12,0,35};
    Player unavailable=first;
    unavailable.id=205; unavailable.position=Vec3{3,0,10}; unavailable.available=false; update_skeleton(unavailable);
    Player absent;
    absent.id=206; absent.name="No position";
    snapshot_.players={std::move(first),std::move(second),std::move(teammate),std::move(incomplete),std::move(unavailable),std::move(absent)};
    update_camera_unlocked();
}

void MockGameDataProvider::update_camera_unlocked() {
    if (!snapshot_.local_position || !finite(*snapshot_.local_position)) {
        snapshot_.camera = {};
        return;
    }
    const Vec3 local = *snapshot_.local_position;
    snapshot_.camera = make_camera(local + Vec3{0,3,-7}, local + Vec3{0,1,25}, aspect_);
}

void MockGameDataProvider::tick(double seconds) {
    if (!std::isfinite(seconds) || seconds <= 0) return;
    std::unique_lock lock(mutex_);
    snapshot_.simulation_time += std::min(seconds, 0.25);
    const auto t = snapshot_.simulation_time;
    if (snapshot_.players.size() >= 3) {
        snapshot_.players[0].position=Vec3{-5+2*static_cast<float>(std::sin(t)),0,18};
        snapshot_.players[1].position=Vec3{10+3*static_cast<float>(std::sin(t*0.5)),0,28};
        for (std::size_t i=0; i<3; ++i) update_skeleton(snapshot_.players[i]);
    }
    if (pending_chest_ && t >= opening_at_) {
        auto found=std::find_if(snapshot_.chests.begin(),snapshot_.chests.end(),
            [&](const Chest& chest) { return chest.id == *pending_chest_; });
        if (found != snapshot_.chests.end() && found->available && found->state == ChestState::Closed)
            found->state = ChestState::Open;
        pending_chest_.reset();
    }
    update_camera_unlocked();
    ++snapshot_.sequence;
}

GameSnapshot MockGameDataProvider::snapshot() const {
    std::shared_lock lock(mutex_);
    return snapshot_;
}

bool MockGameDataProvider::move_towards(Vec3 waypoint, float speed_mps, double seconds) {
    if (!finite(waypoint) || !std::isfinite(speed_mps) || speed_mps <= 0 ||
        !std::isfinite(seconds) || seconds <= 0) return false;
    std::unique_lock lock(mutex_);
    if (!snapshot_.connected || !snapshot_.local_position || !snapshot_.navigation) return false;
    if (scenario_ == MockScenario::Stuck) return true;
    const Vec3 start = *snapshot_.local_position;
    waypoint.y = start.y;
    const Vec3 delta = waypoint - start;
    const float remaining = length(delta);
    if (!std::isfinite(remaining)) return false;
    if (remaining < 1e-5f) return true;
    const float step = static_cast<float>(std::min(seconds, 0.25)) * std::min(speed_mps, 100.0f);
    const Vec3 next = start + delta * (std::min(step, remaining) / remaining);
    if (!segment_open(*snapshot_.navigation, start, next)) return false;
    snapshot_.local_position = next;
    update_camera_unlocked();
    ++snapshot_.sequence;
    return true;
}

bool MockGameDataProvider::interact(EntityId chest_id) {
    std::unique_lock lock(mutex_);
    if (!snapshot_.connected || !snapshot_.local_position) return false;
    auto found=std::find_if(snapshot_.chests.begin(),snapshot_.chests.end(),
        [&](const Chest& chest) { return chest.id == chest_id; });
    if (found == snapshot_.chests.end() || !found->available || found->state != ChestState::Closed ||
        !found->position || !finite(*found->position) || distance(*snapshot_.local_position,*found->position)>2.2f)
        return false;
    if (!snapshot_.navigation || !segment_open(*snapshot_.navigation,*snapshot_.local_position,*found->position))
        return false;
    if (pending_chest_) return *pending_chest_ == chest_id;
    pending_chest_=chest_id;
    opening_at_=scenario_ == MockScenario::InteractionTimeout ? std::numeric_limits<double>::infinity() : snapshot_.simulation_time+0.45;
    ++snapshot_.sequence;
    return true;
}

void MockGameDataProvider::stop() noexcept {
    // Commands are discrete and synchronous; there is no held input to release.
}

void MockGameDataProvider::set_scenario(MockScenario scenario) {
    std::unique_lock lock(mutex_);
    reset_unlocked(scenario);
}

void MockGameDataProvider::set_aspect_ratio(float aspect) {
    if (!std::isfinite(aspect) || aspect <= 0) return;
    std::unique_lock lock(mutex_);
    aspect_=aspect;
    update_camera_unlocked();
    ++snapshot_.sequence;
}
} // namespace fe
