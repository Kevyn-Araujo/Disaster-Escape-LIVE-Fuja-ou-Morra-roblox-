// C++20 | main.cpp | Windows 10/11, Visual Studio 2022 or MinGW-w64.
#include "overlay/dx11_overlay.hpp"
#include "automation/auto_chest.hpp"
#include "config/settings.hpp"
#include "data/mock_game_data_provider.hpp"
#include "utils/logger.hpp"
#include <exception>
#include <filesystem>
#include <iostream>

int main(int argc, char** argv) {
    try {
        const std::filesystem::path config_path = argc > 1 ? argv[1] : "settings.ini";
        fe::Logger logger("fortnite_external.log");
        fe::Settings settings;
        std::string error;
        if (std::filesystem::exists(config_path)) {
            if (!fe::load_settings(config_path, settings, error))
                logger.warn("Configuration not loaded: " + error);
        }
        // A stored setting never starts autonomous movement without a fresh opt-in.
        settings.automation.enabled = false;
        fe::normalize_settings(settings);
        fe::MockGameDataProvider provider;
        fe::AutoChestMachine machine(logger);
        logger.info("Starting MOCK simulator; no Fortnite data source is connected.");
        fe::Dx11Overlay overlay;
        return overlay.run(settings, provider, machine, logger, config_path);
    } catch (const std::exception& error) {
        std::cerr << "Startup failure: " << error.what() << '\n';
        return 1;
    }
}
